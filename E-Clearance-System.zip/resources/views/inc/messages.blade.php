{{-- <div class="container">
    <div class="error">
        @if(count($errors) > 0)
            @foreach($errors->all() as $error)
                <div class="alert alert-danger">
                    {{$error}}
                </div>
            @endforeach
        @endif

        @if(session('success'))
            <div class="alert alert-success" style="margin-bottom: 0px; margin-left: 300px">
                {{session('success')}}
            </div>
        @endif

        @if(session('error'))
            <div class="alert alert-danger">
                {{session('error')}}
            </div>
        @endif
    </div>
</div> --}}