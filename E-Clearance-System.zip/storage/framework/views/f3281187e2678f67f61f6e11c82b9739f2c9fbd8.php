<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
  <meta charset="utf-8">

  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- CSRF Token -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <title><?php echo e(config('app.name', 'Laravel')); ?></title>

  <!-- Scripts -->
  <script src="<?php echo e(asset('js/app.js')); ?>"></script>
  <link rel="icon" type="image/png"  href="<?php echo e(url('/img/web_logo.png')); ?>">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

  <!-- Fonts -->
  <link rel="dns-prefetch" href="//fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Styles -->
  <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

 
</head>
<body>
  <style>
    body{
        position: static;
        background-image: url(/img/Picsart_22-12-06_10-22-15-215.jpg);
        background-repeat: no-repeat;
        background-size: cover;
        height: 100%;
        width: 100%;
        
      }
      @media  only screen and (max-width:768px){
      
        body{
        position: static;
        background-image: url(/img/20221206_104807.jpg);
        background-repeat: no-repeat;
        background-size: cover;
        height: 100%;
        width: 100%;
        
      }
      
      
      }
    </style>
    <main>
      <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
  </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\E-Clearance-System\resources\views/layouts/app.blade.php ENDPATH**/ ?>