
<style>
    .dept_view{
        padding-top: 39px;
    }
    .pagination{
        margin-left: 570px;
    }
    .page-item.active .page-link{
    z-index: 1;
}
</style>
<?php $__env->startSection('content'); ?>
    <div class="dept_view">
        <div class="card" style="width:100%; border: 2px solid black">
            <div class="card-header">
                <div class="container">
                    <div class="error">
                        <div class="container">
                            <div class="error">
                                <?php if(count($errors) > 0): ?>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="alert alert-danger" style="text-align: center">
                                            <?php echo e($error); ?>

                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                        
                                <?php if(session('success')): ?>
                                    <div class="alert alert-success" style="text-align: center">
                                        <?php echo e(session('success')); ?>

                                    </div>
                                <?php endif; ?>
                        
                                <?php if(session('error')): ?>
                                    <div class="alert alert-danger" style="text-align: center">
                                        <?php echo e(session('error')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <h4 style="text-align: center;font-weight: bold;">Department List</h4>
            </div>
            <div class="card-body">
                <table class="table table-bordered">
                    <thead>
                        <tr>  
                            <th>ID</th>
                            <th>Department Name</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody >
                        <?php $__currentLoopData = $department_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->id); ?></td>
                            <td><?php echo e($item->dept_name); ?></td>                               
                            <td>
                                <a href="<?php echo e(url ('admin/edit-department/'.$item->id)); ?>" ><img class="edit" src="<?php echo e(asset('/img/edit.png')); ?>" alt="Italian Trulli"></a>
                            </td>
                            <td>
                                <a onclick="document.getElementById(<?php echo e($item->id); ?>).style.display='block'" ><img class="edit" src="<?php echo e(asset('/img/delete.png')); ?>" alt="Italian Trulli"></a>
                            </td>
                        </tr>  
                        <div id="<?php echo e($item->id); ?>" class="w3-modal" >
                            <div class="w3-modal-content" style="width:30%;">
                                <header class="warning_header">
                                    <span onclick="document.getElementById(<?php echo e($item->id); ?>).style.display='none'"
                                    class="ekis_button w3-display-topright"><b> &times; </b></span>
                                    <h2 style="color: rgb(248, 50, 50)"><b>WARNING!</b></h2>
                                </header>
                                <div class="w3-container">
                                    <p style="text-align: left">
                                        Are you sure you want to delete<br>
                                        ID:<b><?php echo e($item->id); ?></b><br>
                                        department Name:<b><?php echo e($item->dept_name); ?></b><br>
                                        Created At:<b><?php echo e($item->created_at); ?></b><br>
                                        Updated At:<b><?php echo e($item->updated_at); ?> ?</b> 
                                    </p>
                                </div>
                                <footer class="footer_line">
                                    <p class="button_option">
                                        <b><a class="temporary_button" href="<?php echo e(url ('admin/delete-department/'.$item->id)); ?>" >Temporarily!</a>
                                        <a class="temporary_button" href="<?php echo e(url ('admin/permanent-delete-department/'.$item->id)); ?>" >Permanently!</a>
                                        <a class="no_button" style="cursor: pointer" onclick="document.getElementById(<?php echo e($item->id); ?>).style.display='none'">NO!</b></a>
                                    </p>       
                                </footer>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($department_table->links()); ?>

            </div>
        </div>       
    </div>
    <?php echo $__env->make('admin.user-activity', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Clearance-System\resources\views/admin/view-department.blade.php ENDPATH**/ ?>