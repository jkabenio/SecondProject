

<?php $__env->startSection('content'); ?>


<?php if(strcasecmp(Auth::user()->role_as, "Instructor") == 0): ?>

    <div class="clearance_body_signee">
        <div  class="card">
            <div class="card-header">
                <?php if(session('success')): ?>
                    <div style="text-align:center" class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div style="text-align:center" class="alert alert-danger"><?php echo e(session('error')); ?></div>
                <?php endif; ?>
                <h4 class="signee_view_title"><b>Student List</b></h4>
            </div>
            <div  class="card-body" >
                 <table id="students"  class="table table-bordered">
                    <thead >
                        <tr >
                            <form action="<?php echo e(route('signee.view-signee-pending-request')); ?>" method="GET">
                                <?php echo e(csrf_field()); ?>

                                <?php
                                    $result = "";
                                    $id_val = 0;
                                ?>
                                <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(Request::get('course') == $item->id): ?>
                                    <?php
                                    $result = $item->course_acronym;
                                    $id_val =  $item->id;
                                ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="row">
                                    <div class="col-md-1 col-3">
                                        <button type="submit" class="btn btn-primary filter_btn">Filter</button>
                                    </div>
                                    <div class="col-md-2 col-3 filtering_font">
                                        <select name="course" class="form-control">
                                            <?php if(Request::get('course') == null): ?>
                                                <option value="">All Course</option>
                                            <?php endif; ?>
                                            <?php if(Request::get('course') !== null): ?>
                                                <option value="<?php echo e($id_val); ?>" <?php echo e(Request::get('course')); ?>><?php echo e($result); ?></option>
                                            <?php endif; ?>
                                            <?php if(Request::get('course') !== null): ?>
                                            <option value="">All Course</option>
                                        <?php endif; ?>
                                            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($item->id !== $id_val): ?>
                                                    <option  value="<?php echo e($item->id); ?>" <?php echo e(Request::get('course') == 'course' ? 'selected':''); ?>><?php echo e($item->course_acronym); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-2 col-3">
                                        <select name="year_lvl"  class="form-control">
                                            <option value="">All Level</option>
                                            <option value="1st Year" <?php echo e(Request::get('year_lvl') == '1st Year' ? 'selected':''); ?>>1st Year</option>
                                            <option value="2nd Year" <?php echo e(Request::get('year_lvl') == '2nd Year' ? 'selected':''); ?>>2nd Year</option>
                                            <option value="3rd Year" <?php echo e(Request::get('year_lvl') == '3rd Year' ? 'selected':''); ?>>3rd Year</option>
                                            <option value="4th Year" <?php echo e(Request::get('year_lvl') == '4th Year' ? 'selected':''); ?>>4th Year</option>
                                        </select>
                                    </div>
                                    <div class="col-md-2 col-3">
                                        <input type="search" class="form-control"  name="search" id="instructor-search" placeholder="Search:"/>                                              
                                    </div>
                                </div>
                            </form>
                                <th >Name</th>
                                <th >Course</th>
                                <th >Year Level</th>                              
                                <th >Edit</th>
                        </tr>
                    </thead> 
                    <tbody id="Instructor-Content">
                        <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <?php
                                $stats_count = 0;
                                $total_stats = 0;
                                $total_approved = 0;
                                $passed_names = array();
                                $passed_status = array();
                                foreach ($item->student_signee_names as $signee_list)
                                {
                                    $value = $signee_list; 
                                    array_push($passed_names, $value);
                                }
                                foreach ($item->status as $status_list)
                                {
                                    $value = $status_list; 
                                    array_push($passed_status, $value);
                                }
                                foreach ($item->status as $loop => $status_list){
                                    
                                    if(Auth::user()->name == $passed_names[$loop])
                                    {
                                        if("APPROVED" == $passed_status[$loop])
                                        {
                                            $total_approved++;
                                        }
                                    }
                                    if(Auth::user()->name == $passed_names[$loop])
                                    {
                                        if(($passed_status[$loop] == "APPROVED") || ("IN-PROGRESS" == $passed_status[$loop]) || ("COMPLY" == $passed_status[$loop]) || ("REJECTED" == $passed_status[$loop]))
                                        {
                                            $total_stats++;
                                        }
                                    } 
                                }
                           ?>                            
                            <tr>
                                <?php if($total_approved !== $total_stats): ?> 
                                    
                                        <td><?php echo e($item->name); ?></td>
                                        <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($course_list->id == $item->course): ?>
                                                <td><?php echo e($course_list->course_acronym); ?></td>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <td><?php echo e($item->year_lvl); ?></td>
                                        <td>
                                            <a href="<?php echo e(url ('signee/edit-student/'.$item->id)); ?>" ><img class="edit"  src="<?php echo e(asset('/img/edit.png')); ?>" alt="Italian Trulli"></a>
                                        </td>
                                    
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>     
        </div>
    </div>    
<?php endif; ?> 
<?php if(strcasecmp(Auth::user()->role_as,'Guidance Counselor') == 0): ?>
    <div   class="clearance_body_signee">
        <div  class="card" >
            <div class="card-header">
                <?php if(session('success')): ?>
                    <div style="text-align:center"  class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div style="text-align:center"  class="alert alert-danger"><?php echo e(session('error')); ?></div>
                <?php endif; ?>
                <h4 class="signee_view_title"><b>Student List</b></h4>
            </div>
            <div  class="card-body">
                <table class="table table-bordered" style="border: 1px solid black">
                    <thead >
                        <tr >
                            <form action="<?php echo e(route('signee.view-signee-pending-request')); ?>" method="GET">
                                <?php echo e(csrf_field()); ?>

                                <?php
                                    $result = "";
                                    $id_val = 0;
                                ?>
                                <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(Request::get('course') == $item->id): ?>
                                    <?php
                                    $result = $item->course_acronym;
                                    $id_val =  $item->id;
                                ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="row">
                                    <div class="col-md-1 col-3">
                                        <button type="submit" class="btn btn-primary filter_btn">Filter</button>
                                    </div>
                                    <div class="col-md-2 col-3 filtering_font">
                                        <select name="course" class="form-control">
                                            <?php if(Request::get('course') == null): ?>
                                                <option value="">All Course</option>
                                            <?php endif; ?>
                                            <?php if(Request::get('course') !== null): ?>
                                                <option value="<?php echo e($id_val); ?>" <?php echo e(Request::get('course')); ?>><?php echo e($result); ?></option>
                                            <?php endif; ?>
                                            <?php if(Request::get('course') !== null): ?>
                                            <option value="">All Course</option>
                                        <?php endif; ?>
                                            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($item->id !== $id_val): ?>
                                                    <option  value="<?php echo e($item->id); ?>" <?php echo e(Request::get('course') == 'course' ? 'selected':''); ?>><?php echo e($item->course_acronym); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-2 col-3">
                                        <select name="year_lvl"  class="form-control">
                                            <option value="">All Level</option>
                                            <option value="1st Year" <?php echo e(Request::get('year_lvl') == '1st Year' ? 'selected':''); ?>>1st Year</option>
                                            <option value="2nd Year" <?php echo e(Request::get('year_lvl') == '2nd Year' ? 'selected':''); ?>>2nd Year</option>
                                            <option value="3rd Year" <?php echo e(Request::get('year_lvl') == '3rd Year' ? 'selected':''); ?>>3rd Year</option>
                                            <option value="4th Year" <?php echo e(Request::get('year_lvl') == '4th Year' ? 'selected':''); ?>>4th Year</option>
                                        </select>
                                    </div>
                                    <div class="col-md-2 col-3">
                                        <input type="search" class="form-control"  name="search" id="guidance-counselor-search" placeholder="Search:"/>                                              
                                    </div>
                                </div>
                            </form>
                            <th>Name</th>
                            <th>Course</th>
                            <th>Year Level</th>                              
                            <th>Edit</th>
                        </tr>
                    </thead> 
                    <tbody id="Guidance-Counselor-Content">
                        
                        <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item->guidance_councilor !== "APPROVED"): ?>    
                                <tr> 
                                    <td><?php echo e($item->name); ?></td>
                                    <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($course_list->id == $item->course): ?>
                                            <td><?php echo e($course_list->course_acronym); ?></td>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <td><?php echo e($item->year_lvl); ?></td>
                                        <td> 
                                            <a href="<?php echo e(url ('signee/edit-student/'.$item->id)); ?>" ><img class="edit" src="/img/edit.png" alt="Italian Trulli"></a>   
                                        </td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>     
        </div>
    </div>    
<?php endif; ?>

<?php if(strcasecmp(Auth::user()->role_as,'Student Org. Treasurer') == 0): ?>
    <div   class="clearance_body_signee">
        <div  class="card">
            <div class="card-header">
                <div class="card-header">
                    <?php if(session('success')): ?>
                        <div style="text-align:center"  class="alert alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                        <div style="text-align:center"  class="alert alert-danger"><?php echo e(session('error')); ?></div>
                    <?php endif; ?>
                    <h4 class="signee_view_title"><b>Student List</b></h4>
                </div>
            </div>
            <div  class="card-body">
                <table class="table table-bordered" style="border: 1px solid black">
                    <thead >
                        <tr>
                            <form action="<?php echo e(route('signee.view-signee-pending-request')); ?>" method="GET">
                                <?php echo e(csrf_field()); ?>

                                <?php
                                    $result = "";
                                    $id_val = 0;
                                ?>
                                <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(Request::get('course') == $item->id): ?>
                                    <?php
                                    $result = $item->course_acronym;
                                    $id_val =  $item->id;
                                ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="row">
                                    <div class="col-md-1 col-3">
                                        <button type="submit" class="btn btn-primary filter_btn">Filter</button>
                                    </div>
                                    <div class="col-md-2 col-3 filtering_font">
                                        <select name="course" class="form-control">
                                            <?php if(Request::get('course') == null): ?>
                                                <option value="">All Course</option>
                                            <?php endif; ?>
                                            <?php if(Request::get('course') !== null): ?>
                                                <option value="<?php echo e($id_val); ?>" <?php echo e(Request::get('course')); ?>><?php echo e($result); ?></option>
                                            <?php endif; ?>
                                            <?php if(Request::get('course') !== null): ?>
                                            <option value="">All Course</option>
                                        <?php endif; ?>
                                            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($item->id !== $id_val): ?>
                                                    <option  value="<?php echo e($item->id); ?>" <?php echo e(Request::get('course') == 'course' ? 'selected':''); ?>><?php echo e($item->course_acronym); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-2 col-3">
                                        <select name="year_lvl"  class="form-control">
                                            <option value="">All Level</option>
                                            <option value="1st Year" <?php echo e(Request::get('year_lvl') == '1st Year' ? 'selected':''); ?>>1st Year</option>
                                            <option value="2nd Year" <?php echo e(Request::get('year_lvl') == '2nd Year' ? 'selected':''); ?>>2nd Year</option>
                                            <option value="3rd Year" <?php echo e(Request::get('year_lvl') == '3rd Year' ? 'selected':''); ?>>3rd Year</option>
                                            <option value="4th Year" <?php echo e(Request::get('year_lvl') == '4th Year' ? 'selected':''); ?>>4th Year</option>
                                        </select>
                                    </div>
                                    <div class="col-md-2 col-3">
                                        <input type="search" class="form-control"  name="search" id="student-org-search" placeholder="Search by: Name or School ID"/>                                              
                                    </div>
                                </div>
                            </form>
                            <th>Name</th>
                            <th>Course</th>
                            <th>Year Level</th>                              
                            <th>Edit</th>
                        </tr>
                    </thead> 
                    <tbody id="Student-Org-Content">  
                        <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(Auth::user()->dept_id == $item->dept_id): ?>
                                <?php if($item->student_org_treasurer !== "APPROVED"): ?>
                                <tr> 
                                    <td><?php echo e($item->name); ?></td>
                                    <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($course_list->id == $item->course): ?>
                                            <td><?php echo e($course_list->course_acronym); ?></td>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <td><?php echo e($item->year_lvl); ?></td>
                                        <td> 
                                            <a href="<?php echo e(url ('signee/edit-student/'.$item->id)); ?>" ><img class="edit" src="/img/edit.png" alt="Italian Trulli"></a>
                                        </td>
                                <?php endif; ?> 
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>     
        </div>
    </div>    
<?php endif; ?>
<?php if(strcasecmp(Auth::user()->role_as,'Librarian') == 0): ?>
<div   class="clearance_body_signee">
    <div  class="card">
        <div class="card-header">
            <?php if(session('success')): ?>
            <div style="text-align:center"  class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div style="text-align:center"  class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>
            <h4 class="signee_view_title"><b>Student List</b></h4>
        </div>
        <div  class="card-body">
            <table class="table table-bordered" style="border: 1px solid black">
                <thead >
                    <tr >
                        <form action="<?php echo e(route('signee.view-signee-pending-request')); ?>" method="GET">
                            <?php echo e(csrf_field()); ?>

                            <?php
                                $result = "";
                                $id_val = 0;
                            ?>
                            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(Request::get('course') == $item->id): ?>
                                <?php
                                $result = $item->course_acronym;
                                $id_val =  $item->id;
                            ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="row">
                                <div class="col-md-1 col-3">
                                    <button type="submit" class="btn btn-primary filter_btn">Filter</button>
                                </div>
                                <div class="col-md-2 col-3 filtering_font">
                                    <select name="course" class="form-control">
                                        <?php if(Request::get('course') == null): ?>
                                            <option value="">All Course</option>
                                        <?php endif; ?>
                                        <?php if(Request::get('course') !== null): ?>
                                            <option value="<?php echo e($id_val); ?>" <?php echo e(Request::get('course')); ?>><?php echo e($result); ?></option>
                                        <?php endif; ?>
                                        <?php if(Request::get('course') !== null): ?>
                                        <option value="">All Course</option>
                                    <?php endif; ?>
                                        <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($item->id !== $id_val): ?>
                                                <option  value="<?php echo e($item->id); ?>" <?php echo e(Request::get('course') == 'course' ? 'selected':''); ?>><?php echo e($item->course_acronym); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-md-2 col-3">
                                    <select name="year_lvl"  class="form-control">
                                        <option value="">All Level</option>
                                        <option value="1st Year" <?php echo e(Request::get('year_lvl') == '1st Year' ? 'selected':''); ?>>1st Year</option>
                                        <option value="2nd Year" <?php echo e(Request::get('year_lvl') == '2nd Year' ? 'selected':''); ?>>2nd Year</option>
                                        <option value="3rd Year" <?php echo e(Request::get('year_lvl') == '3rd Year' ? 'selected':''); ?>>3rd Year</option>
                                        <option value="4th Year" <?php echo e(Request::get('year_lvl') == '4th Year' ? 'selected':''); ?>>4th Year</option>
                                    </select>
                                </div>
                                <div class="col-md-2 col-3">
                                    <input type="search" class="form-control"  name="search" id="librarian-search" placeholder="Search:"/>                                              
                                </div>
                            </div>
                        </form>
                        <th>Name</th>
                        <th>Course</th>
                        <th>Year Level</th>                              
                        <th>Edit</th>
                    </tr>
                </thead> 
                <tbody id="Librarian-Content">
                    
                    <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $approve_count = 0;
                                $approve_total = 0;
                             ?>
                            <?php $__currentLoopData = $item->status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status_count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($status_count == "APPROVED"): ?>
                                    <?php
                                        $approve_count++;
                                    ?>
                                <?php endif; ?>
                                <?php if($status_count !== "APPROVED" || $status_count == "APPROVED"): ?>
                                    <?php
                                        $approve_total++;
                                    ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $pass_total_value =  $approve_count;
                                $pass_status_value = $approve_total;
                            ?>
                            <?php if($pass_total_value == $pass_status_value): ?>
                                <?php if($item->student_org_treasurer == "APPROVED"  && $item->guidance_councilor == "APPROVED" && $item->librarian !== "APPROVED"): ?>
                                    <tr> 
                                        <td><?php echo e($item->name); ?></td>
                                        <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($course_list->id == $item->course): ?>
                                                <td><?php echo e($course_list->course_acronym); ?></td>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <td><?php echo e($item->year_lvl); ?></td>
                                        <td> 
                                            <a href="<?php echo e(url ('signee/edit-student/'.$item->id)); ?>" ><img class="edit" src="/img/edit.png" alt="Italian Trulli"></a>
                                        </td>
                                    </tr>
                                <?php endif; ?> 
                            <?php endif; ?>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>     
    </div>
</div>  
<?php endif; ?>
<?php if(strcasecmp(Auth::user()->role_as,'Dean of Student Affair') == 0): ?>
    <div   class="clearance_body_signee">
        <div  class="card">
            <div class="card-header">
                <?php if(session('success')): ?>
            <div style="text-align:center"  class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div style="text-align:center"  class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>
            <h4 class="signee_view_title"><b>Student List</b></h4>
            </div>
            <div  class="card-body">
                <table class="table table-bordered" style="border: 1px solid black">
                    <thead >
                        <tr >
                            <form action="<?php echo e(route('signee.view-signee-pending-request')); ?>" method="GET">
                                <?php echo e(csrf_field()); ?>

                                <?php
                                    $result = "";
                                    $id_val = 0;
                                ?>
                                <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(Request::get('course') == $item->id): ?>
                                    <?php
                                    $result = $item->course_acronym;
                                    $id_val =  $item->id;
                                ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="row">
                                    <div class="col-md-1 col-3">
                                        <button type="submit" class="btn btn-primary filter_btn">Filter</button>
                                    </div>
                                    <div class="col-md-2 col-3 filtering_font">
                                        <select name="course" class="form-control">
                                            <?php if(Request::get('course') == null): ?>
                                                <option value="">All Course</option>
                                            <?php endif; ?>
                                            <?php if(Request::get('course') !== null): ?>
                                                <option value="<?php echo e($id_val); ?>" <?php echo e(Request::get('course')); ?>><?php echo e($result); ?></option>
                                            <?php endif; ?>
                                            <?php if(Request::get('course') !== null): ?>
                                            <option value="">All Course</option>
                                        <?php endif; ?>
                                            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($item->id !== $id_val): ?>
                                                    <option  value="<?php echo e($item->id); ?>" <?php echo e(Request::get('course') == 'course' ? 'selected':''); ?>><?php echo e($item->course_acronym); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-2 col-3">
                                        <select name="year_lvl"  class="form-control">
                                            <option value="">All Level</option>
                                            <option value="1st Year" <?php echo e(Request::get('year_lvl') == '1st Year' ? 'selected':''); ?>>1st Year</option>
                                            <option value="2nd Year" <?php echo e(Request::get('year_lvl') == '2nd Year' ? 'selected':''); ?>>2nd Year</option>
                                            <option value="3rd Year" <?php echo e(Request::get('year_lvl') == '3rd Year' ? 'selected':''); ?>>3rd Year</option>
                                            <option value="4th Year" <?php echo e(Request::get('year_lvl') == '4th Year' ? 'selected':''); ?>>4th Year</option>
                                        </select>
                                    </div>
                                    <div class="col-md-2 col-3">
                                        <input type="search" class="form-control"  name="search" id="student-affair-search" placeholder="Search:"/>                                              
                                    </div>
                                </div>
                            </form>
                            <th>Name</th>
                            <th>Course</th>
                            <th>Year Level</th>                              
                            <th>Edit</th>
                        </tr>
                    </thead> 
                    <tbody id="Student-Affair-Content">
                        
                        <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $approve_count = 0;
                                    $approve_total = 0;
                                 ?>
                                <?php $__currentLoopData = $item->status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status_count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($status_count == "APPROVED"): ?>
                                        <?php
                                            $approve_count++;
                                        ?>
                                    <?php endif; ?>
                                    <?php if($status_count !== "APPROVED" || $status_count == "APPROVED"): ?>
                                        <?php
                                            $approve_total++;
                                        ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $pass_total_value =  $approve_count;
                                    $pass_status_value = $approve_total;
                                ?>
                                <?php if($pass_total_value == $pass_status_value): ?>
                                    <?php if($item->student_org_treasurer == "APPROVED" && $item->guidance_councilor == "APPROVED" && $item->librarian == "APPROVED" && $item->dean_of_student_affair !== "APPROVED"): ?>
                                        <tr> 
                                            <td><?php echo e($item->name); ?></td>
                                            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($course_list->id == $item->course): ?>
                                                    <td><?php echo e($course_list->course_acronym); ?></td>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <td><?php echo e($item->year_lvl); ?></td>
                                            <td> 
                                                <a href="<?php echo e(url ('signee/edit-student/'.$item->id)); ?>" ><img class="edit" src="/img/edit.png" alt="Italian Trulli"></a>
                                            </td>
                                        </tr>
                                    <?php endif; ?> 
                                 <?php endif; ?>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>     
        </div>
    </div>    
<?php endif; ?>
<?php if(strcasecmp(Auth::user()->role_as,'Dean Principal') == 0): ?>
    <div   class="clearance_body_signee">
        <div  class="card">
            <div class="card-header"> 
                <?php if(session('success')): ?>
                    <div style="text-align:center"  class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div style="text-align:center"  class="alert alert-danger"><?php echo e(session('error')); ?></div>
                <?php endif; ?>
                <h4 class="signee_view_title"><b>Student List</b></h4>
            </div>
            <div  class="card-body">
                <table class="table table-bordered" style="border: 1px solid black">
                    <thead >
                        <tr >
                            <form action="<?php echo e(route('signee.view-signee-pending-request')); ?>" method="GET">
                                <?php echo e(csrf_field()); ?>

                                <?php
                                    $result = "";
                                    $id_val = 0;
                                ?>
                                <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(Request::get('course') == $item->id): ?>
                                    <?php
                                    $result = $item->course_acronym;
                                    $id_val =  $item->id;
                                ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="row">
                                    <div class="col-md-1 col-3">
                                        <button type="submit" class="btn btn-primary filter_btn">Filter</button>
                                    </div>
                                    <div class="col-md-2 col-3 filtering_font">
                                        <select name="course" class="form-control">
                                            <?php if(Request::get('course') == null): ?>
                                                <option value="">All Course</option>
                                            <?php endif; ?>
                                            <?php if(Request::get('course') !== null): ?>
                                                <option value="<?php echo e($id_val); ?>" <?php echo e(Request::get('course')); ?>><?php echo e($result); ?></option>
                                            <?php endif; ?>
                                            <?php if(Request::get('course') !== null): ?>
                                            <option value="">All Course</option>
                                        <?php endif; ?>
                                            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($item->id !== $id_val): ?>
                                                    <option  value="<?php echo e($item->id); ?>" <?php echo e(Request::get('course') == 'course' ? 'selected':''); ?>><?php echo e($item->course_acronym); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-2 col-3">
                                        <select name="year_lvl"  class="form-control">
                                            <option value="">All Level</option>
                                            <option value="1st Year" <?php echo e(Request::get('year_lvl') == '1st Year' ? 'selected':''); ?>>1st Year</option>
                                            <option value="2nd Year" <?php echo e(Request::get('year_lvl') == '2nd Year' ? 'selected':''); ?>>2nd Year</option>
                                            <option value="3rd Year" <?php echo e(Request::get('year_lvl') == '3rd Year' ? 'selected':''); ?>>3rd Year</option>
                                            <option value="4th Year" <?php echo e(Request::get('year_lvl') == '4th Year' ? 'selected':''); ?>>4th Year</option>
                                        </select>
                                    </div>
                                    <div class="col-md-2 col-3">
                                        <input type="search" class="form-control"  name="search" id="dean-principal-search" placeholder="Search:"/>                                              
                                    </div>
                                </div>
                            </form> 
                            <th>Name</th>
                            <th>Course</th>
                            <th>Year Level</th>                              
                            <th>Edit</th>
                        </tr>
                    </thead> 
                    <tbody id="Dean-Principal-Content">
                        
                        <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(Auth::user()->dept_id == $item->dept_id): ?>
                                <?php
                                    $approve_count = 0;
                                    $approve_total = 0;
                                 ?>
                                <?php $__currentLoopData = $item->status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status_count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($status_count == "APPROVED"): ?>
                                        <?php
                                            $approve_count++;
                                        ?>
                                    <?php endif; ?>
                                    <?php if($status_count !== "APPROVED" || $status_count == "APPROVED"): ?>
                                        <?php
                                            $approve_total++;
                                        ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $pass_total_value =  $approve_count;
                                    $pass_status_value = $approve_total;
                                ?>
                                <?php if($pass_total_value == $pass_status_value): ?>
                                        <?php if($item->student_org_treasurer == "APPROVED" && $item->dean_principal !== "APPROVED" && $item->librarian == "APPROVED" && $item->guidance_councilor == "APPROVED" && $item->dean_of_student_affair == "APPROVED"): ?>
                                        <tr> 
                                            <td><?php echo e($item->name); ?></td>
                                            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($course_list->id == $item->course): ?>
                                                    <td><?php echo e($course_list->course_acronym); ?></td>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <td><?php echo e($item->year_lvl); ?></td>
                                                <td> 
                                                    <a href="<?php echo e(url ('signee/edit-student/'.$item->id)); ?>" ><img class="edit" src="/img/edit.png" alt="Italian Trulli"></a>
                                                </td>
                                        <?php endif; ?> 
                                        </tr>
                                    <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>     
        </div>
    </div>    
<?php endif; ?>
<?php if(strcasecmp(Auth::user()->role_as,'Registrar') == 0): ?>
    <div   class="clearance_body_signee">
        <div  class="card">
            <?php if(session('success')): ?>
                <div style="text-align:center"  class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div style="text-align:center"  class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>
            <div class="card-header">
                <h4 class="signee_view_title"><b>Student List</b></h4>
            </div>
            <div  class="card-body">
                <table class="table table-bordered" style="border: 1px solid black">
                    <thead >
                        <tr >
                            <form action="<?php echo e(route('signee.view-signee-pending-request')); ?>" method="GET">
                                <?php echo e(csrf_field()); ?>

                                <?php
                                    $result = "";
                                    $id_val = 0;
                                ?>
                                <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(Request::get('course') == $item->id): ?>
                                    <?php
                                    $result = $item->course_acronym;
                                    $id_val =  $item->id;
                                ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="row">
                                    <div class="col-md-1 col-3">
                                        <button type="submit" class="btn btn-primary filter_btn">Filter</button>
                                    </div>
                                    <div class="col-md-2 col-3 filtering_font">
                                        <select name="course" class="form-control">
                                            <?php if(Request::get('course') == null): ?>
                                                <option value="">All Course</option>
                                            <?php endif; ?>
                                            <?php if(Request::get('course') !== null): ?>
                                                <option value="<?php echo e($id_val); ?>" <?php echo e(Request::get('course')); ?>><?php echo e($result); ?></option>
                                            <?php endif; ?>
                                            <?php if(Request::get('course') !== null): ?>
                                            <option value="">All Course</option>
                                        <?php endif; ?>
                                            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($item->id !== $id_val): ?>
                                                    <option  value="<?php echo e($item->id); ?>" <?php echo e(Request::get('course') == 'course' ? 'selected':''); ?>><?php echo e($item->course_acronym); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-2 col-3">
                                        <select name="year_lvl"  class="form-control">
                                            <option value="">All Level</option>
                                            <option value="1st Year" <?php echo e(Request::get('year_lvl') == '1st Year' ? 'selected':''); ?>>1st Year</option>
                                            <option value="2nd Year" <?php echo e(Request::get('year_lvl') == '2nd Year' ? 'selected':''); ?>>2nd Year</option>
                                            <option value="3rd Year" <?php echo e(Request::get('year_lvl') == '3rd Year' ? 'selected':''); ?>>3rd Year</option>
                                            <option value="4th Year" <?php echo e(Request::get('year_lvl') == '4th Year' ? 'selected':''); ?>>4th Year</option>
                                        </select>
                                    </div>
                                    <div class="col-md-2 col-3">
                                        <input type="search" class="form-control"  name="search" id="registrar-search" placeholder="Search:"/>                                              
                                    </div>
                                </div>
                            </form>
                            <th>Name</th>
                            <th>Course</th>
                            <th>Year Level</th>                              
                            <th>Edit</th>
                        </tr>
                    </thead> 
                    <tbody id="Registrar-Content">
                        
                        <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $approve_count = 0;
                                    $approve_total = 0;
                                 ?>
                                <?php $__currentLoopData = $item->status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status_count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($status_count == "APPROVED"): ?>
                                        <?php
                                            $approve_count++;
                                        ?>
                                    <?php endif; ?>
                                    <?php if($status_count !== "APPROVED" || $status_count == "APPROVED"): ?>
                                        <?php
                                            $approve_total++;
                                        ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $pass_total_value =  $approve_count;
                                    $pass_status_value = $approve_total;
                                ?>
                                <?php if($pass_total_value == $pass_status_value): ?>
                                    <?php if($item->student_org_treasurer == "APPROVED" && $item->dean_principal == "APPROVED" && $item->guidance_councilor == "APPROVED" && $item->librarian == "APPROVED" && $item->dean_of_student_affair == "APPROVED" && $item->registrar !== "APPROVED"): ?>
                                        <tr> 
                                            <td><?php echo e($item->name); ?></td>
                                            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($course_list->id == $item->course): ?>
                                                    <td><?php echo e($course_list->course_acronym); ?></td>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <td><?php echo e($item->year_lvl); ?></td>
                                            <td> 
                                                <a href="<?php echo e(url ('signee/edit-student/'.$item->id)); ?>" ><img class="edit" src="/img/edit.png" alt="Italian Trulli"></a>
                                            </td>
                                        </tr>
                                    <?php endif; ?> 
                                 <?php endif; ?>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>     
        </div>
    </div>    
<?php endif; ?>
<?php if(strcasecmp(Auth::user()->role_as,'Accounting Assessment') == 0): ?>
    <div   class="clearance_body_signee">
        <div  class="card">
            <div class="card-header">
                <?php if(session('success')): ?>
                    <div style="text-align:center"  class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div style="text-align:center"  class="alert alert-danger"><?php echo e(session('error')); ?></div>
                <?php endif; ?>
                <h4 class="signee_view_title"><b>Student List</b></h4>
            </div>
            <div  class="card-body">
                <table class="table table-bordered" style="border: 1px solid black">
                    <thead >
                        <tr >
                            <form action="<?php echo e(route('signee.view-signee-pending-request')); ?>" method="GET">
                                <?php echo e(csrf_field()); ?>

                                <?php
                                    $result = "";
                                    $id_val = 0;
                                ?>
                                <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(Request::get('course') == $item->id): ?>
                                    <?php
                                    $result = $item->course_acronym;
                                    $id_val =  $item->id;
                                ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="row">
                                    <div class="col-md-1 col-3">
                                        <button type="submit" class="btn btn-primary filter_btn">Filter</button>
                                    </div>
                                    <div class="col-md-2 col-3 filtering_font">
                                        <select name="course" class="form-control">
                                            <?php if(Request::get('course') == null): ?>
                                                <option value="">All Course</option>
                                            <?php endif; ?>
                                            <?php if(Request::get('course') !== null): ?>
                                                <option value="<?php echo e($id_val); ?>" <?php echo e(Request::get('course')); ?>><?php echo e($result); ?></option>
                                            <?php endif; ?>
                                            <?php if(Request::get('course') !== null): ?>
                                            <option value="">All Course</option>
                                        <?php endif; ?>
                                            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($item->id !== $id_val): ?>
                                                    <option  value="<?php echo e($item->id); ?>" <?php echo e(Request::get('course') == 'course' ? 'selected':''); ?>><?php echo e($item->course_acronym); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-2 col-3">
                                        <select name="year_lvl"  class="form-control">
                                            <option value="">All Level</option>
                                            <option value="1st Year" <?php echo e(Request::get('year_lvl') == '1st Year' ? 'selected':''); ?>>1st Year</option>
                                            <option value="2nd Year" <?php echo e(Request::get('year_lvl') == '2nd Year' ? 'selected':''); ?>>2nd Year</option>
                                            <option value="3rd Year" <?php echo e(Request::get('year_lvl') == '3rd Year' ? 'selected':''); ?>>3rd Year</option>
                                            <option value="4th Year" <?php echo e(Request::get('year_lvl') == '4th Year' ? 'selected':''); ?>>4th Year</option>
                                        </select>
                                    </div>
                                    <div class="col-md-2 col-3">
                                        <input type="search" class="form-control"  name="search" id="assessment-search" placeholder="Search:"/>                                              
                                    </div>
                                </div>
                            </form>
                            <th>Name</th>
                            <th>Course</th>
                            <th>Year Level</th>                              
                            <th>Edit</th>
                        </tr>
                    </thead> 
                    <tbody id="Assessment-Content">
                        
                        <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $approve_count = 0;
                                    $approve_total = 0;
                                 ?>
                                <?php $__currentLoopData = $item->status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status_count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($status_count == "APPROVED"): ?>
                                        <?php
                                            $approve_count++;
                                        ?>
                                    <?php endif; ?>
                                    <?php if($status_count !== "APPROVED" || $status_count == "APPROVED"): ?>
                                        <?php
                                            $approve_total++;
                                        ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $pass_total_value =  $approve_count;
                                    $pass_status_value = $approve_total;
                                ?>
                                <?php if($pass_total_value == $pass_status_value): ?>
                                    <?php if($item->student_org_treasurer == "APPROVED" && $item->dean_principal == "APPROVED" && $item->guidance_councilor == "APPROVED" && $item->librarian == "APPROVED" && $item->dean_of_student_affair == "APPROVED" && $item->registrar == "APPROVED" && $item->accounting_assessment !== "APPROVED"): ?>
                                        <tr> 
                                            <td><?php echo e($item->name); ?></td>
                                            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($course_list->id == $item->course): ?>
                                                    <td><?php echo e($course_list->course_acronym); ?></td>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <td><?php echo e($item->year_lvl); ?></td>
                                            <td> 
                                                <a href="<?php echo e(url ('signee/edit-student/'.$item->id)); ?>" ><img class="edit" src="/img/edit.png" alt="Italian Trulli"></a>
                                            </td>
                                        </tr>
                                    <?php endif; ?> 
                                 <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>     
        </div>
    </div>
<?php endif; ?>
<?php echo $__env->make('signee.user-activity', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.signee-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Clearance-System\resources\views/signee/view-signee-pending-request.blade.php ENDPATH**/ ?>