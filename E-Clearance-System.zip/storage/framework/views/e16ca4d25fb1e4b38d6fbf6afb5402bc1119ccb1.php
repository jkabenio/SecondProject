
<?php $__env->startSection('content'); ?>
<style>
    td{
      white-space:nowrap;
      text-overflow:ellipsis; 
      overflow:hidden;     
    }
</style> 
        <div class="clearance_body_admin">
            <div class="card" style="width:99%; border: 2px solid black">
                <div class="card-header">
                    <h4>Change Student Password</h4>
                </div>
                <div class="card-body">
                    <table class="table table-bordered" style="width:900px; border: 1px solid black">
                        <thead >
                            <tr >
                                <th>No.</th>
                                <th>name</th>
                                <th>email</th>
                                <th>School ID</th>
                                
                                <th>Role</th>
                                <th>Edit</th>
                            </tr>
                        </thead> 
                        <tbody>
                            <?php $__currentLoopData = $student_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count_data => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr> 
                                    <td ><?php echo e($count_data + 1); ?></td>
                                    <td><?php echo e($item->name); ?></td>
                                    <td><?php echo e($item->email); ?></td>
                                    <td><?php echo e($item->school_id); ?></td>
                                    <td>
                                        <?php echo e($item->role_as == '0' ? 'Student' : ''); ?>                                        
                                        <?php echo e($item->role_as == '1' ? 'Admin':''); ?>

                                        <?php echo e($item->role_as == '2' ? 'Instructor' : ''); ?>

                                    </td>                            
                                    <td>
                                        <a class="w3-button w3-green"  href="<?php echo e(url ('admin/edit-student-password/'.$item->id)); ?>" >Change Password</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                    <?php echo e($student_table->links()); ?>

                </div>
            </div>       
      
            <div class="clearance_body_admin">
                <div class="card" style="width:99%; border: 2px solid black">
                    <div class="card-header">
                        <h4>Change Signee Password</h4>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered" style="width:900px; border: 1px solid black">
                            <thead >
                                <tr >
                                    <th>No.</th>
                                    <th>name</th>
                                    <th>email</th>
                                    <th>School ID</th>
                                    
                                    <th>Role</th>
                                    <th>Edit</th>
                                </tr>
                            </thead> 
                            <tbody>
                                <?php $__currentLoopData = $signee_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count_data => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr> 
                                        <td ><?php echo e($count_data + 1); ?></td>
                                        <td><?php echo e($item->name); ?></td>
                                        <td><?php echo e($item->email); ?></td>
                                        <td><?php echo e($item->school_id); ?></td>
                                        <td>
                                            <?php echo e($item->role_as == '0' ? 'Student' : ''); ?>                                        
                                            <?php echo e($item->role_as == '1' ? 'Admin':''); ?>

                                            <?php echo e($item->role_as == '2' ? 'Instructor' : ''); ?>

                                        </td>                            
                                        <td>
                                            <a class="w3-button w3-green"  href="<?php echo e(url ('admin/edit-student/'.$item->id)); ?>" >Change Password</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                        <?php echo e($signee_table->links()); ?>

                    </div>
                </div> 
    <?php echo $__env->make('admin.user-activity', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Clearance-System\resources\views/admin/change-user-password.blade.php ENDPATH**/ ?>