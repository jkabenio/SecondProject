
<?php $__env->startSection('content'); ?>
<style>
    td{
      white-space:nowrap;
      text-overflow:ellipsis; 
      overflow:hidden;     
    }
    .change_pass_signee-view{
        padding-top: 39px;
    }
    .page-item.active .page-link{
    z-index: 1;
}
</style>          
            <div class="change_pass_signee-view">
                <div class="card" style=" border: 2px solid black">
                    <div class="card-header">
                        <h4 style="text-align: center; font-weight: bold">Change Signee Password</h4>
                        <div class="container">
                            <div class="error">
                                <?php if(count($errors) > 0): ?>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="alert alert-danger" style="text-align: center">
                                            <?php echo e($error); ?>

                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                        
                                <?php if(session('success')): ?>
                                    <div class="alert alert-success" style="text-align: center">
                                        <?php echo e(session('success')); ?>

                                    </div>
                                <?php endif; ?>
                        
                                <?php if(session('error')): ?>
                                    <div class="alert alert-danger" style="text-align: center">
                                        <?php echo e(session('error')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered" style="border: 1px solid black">
                            <thead >
                                <tr >
                                    <th>No.</th>
                                    <th>name</th>
                                    <th>email</th>
                                    <th>School ID</th>
                                    <th>Role</th>
                                    <th>Edit</th>
                                </tr>
                            </thead> 
                            <tbody>
                                <?php $__currentLoopData = $signee_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count_data => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr> 
                                        <td ><?php echo e($count_data + 1); ?></td>
                                        <td><?php echo e($item->name); ?></td>
                                        <td><?php echo e($item->email); ?></td>
                                        <td><?php echo e($item->school_id); ?></td>
                                        <td> <?php echo e($item->role_as); ?></td>                            
                                        <td>
                                            <a class="btn btn-danger"  href="<?php echo e(url ('admin/edit-signee-password/'.$item->id)); ?>" >Change Password</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                        <?php echo e($signee_table->links()); ?>

                    </div>
                </div> 
    <?php echo $__env->make('admin.user-activity', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Clearance-System\resources\views/admin/change-signee-password.blade.php ENDPATH**/ ?>