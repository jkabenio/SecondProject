

<?php $__env->startSection('content'); ?>
 <style>
.edit-signee_view{
    padding-top: 39px;
    }
.edit_signee_column{
    width: 50%;
    float: left;
    padding-right: 10px;
}
.signee_update_btn{
    margin-left: 555px;
}
.signee_edit_label{
    margin-left: 250px;
    font-weight: bold;
}
.form-control{
 background-color: #e9ecef;
}
</style>
<div class="edit-signee_view">
    <div class="card" style=" border: 2px solid black">
        <div class="card-header">
            <div class="container">
                <div class="error">
                    <?php if(count($errors) > 0): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-danger" style="text-align: center">
                                <?php echo e($error); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
            
                    <?php if(session('success')): ?>
                        <div class="alert alert-success" style="text-align: center">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
            
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger" style="text-align: center">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <h4 style="text-align: center"> <b> Edit User </b>
                <a href="<?php echo e(url('/admin/view-signee-user')); ?>" class="btn btn-danger float-end">BACK</a>
            </h4>
        </div>
        <?php echo Form::open(['action' => ['App\Http\Controllers\Admin\AdminController@update_signee',$signee_id->id],'enctype' => 'multipart/form-data']); ?>

        <div class="card-body">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
           <div class="edit_signee_row">
                <div class="edit_signee_column">
                    <label class="signee_edit_label">Signee Name <span style="font-weight: normal; font-size: 10px">(Editable)</span></label>
                    <input style="text-align: center" type="text" name="name" value="<?php echo e($signee_id->name); ?>" class="form-control">
                </div>
                <div class="edit_signee_column">
                    <label class="signee_edit_label">Role <span style="font-weight: normal; font-size: 10px">(Editable)</span></label>                   
                        <select style="text-align: center" name="role_as" class="form-control">
                            <option value="<?php echo e($signee_id->role_as); ?>"><?php echo e($signee_id->role_as); ?></option>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item->role_name !== $signee_id->role_as &&  strcasecmp($item->role_name,'Student') !== 0): ?>
                                    <option value="<?php echo e($item->role_name); ?>"><?php echo e($item->role_name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                      
                        </select>
                </div>

                <div class="edit_signee_column">
                    <label class="signee_edit_label">Department <span style="font-weight: normal; font-size: 10px">(Editable)</span></label>                   
                    <select style="text-align: center" name="dept_id" class="form-control">
                        <?php $__currentLoopData = $dept_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($signee_id->dept_id == $list->id): ?>
                                <option value="<?php echo e($signee_id->dept_id); ?>"><?php echo e($list->dept_name); ?></option> 
                            <?php endif; ?>
                            <?php if($signee_id->dept_id == 0): ?>
                                <option value="0">Not Applicable</option>
                                <?php break; ?>
                            <?php endif; ?>
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($signee_id->dept_id !== 0): ?>
                        <option value="0">Not Applicable</option>
                    <?php endif; ?>   
                        <?php $__currentLoopData = $dept_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($signee_id->dept_id !== $list->id): ?>
                                <option value="<?php echo e($list->id); ?>"><?php echo e($list->dept_name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    </select>
                </div>
                <div class="edit_signee_column">
                    <label class="signee_edit_label">Signee Email <span style="font-weight: normal; font-size: 10px">(Editable)</span></label>
                    <input style="text-align: center" type="text" name="email" value="<?php echo e($signee_id->email); ?>" class="form-control">
                </div>

                <div class="edit_signee_column">
                    <label class="signee_edit_label">Signee School ID <span style="font-weight: normal; font-size: 10px">(Editable)</span></label>
                    <input style="text-align: center" name="school_id" type="text" value="<?php echo e($signee_id->school_id); ?>" class="form-control">
                </div>
                
                <div class="edit_signee_column">
                    <label class="signee_edit_label">Created At</label>
                    <p style="text-align: center" class="form-control">
                        <?php echo e(date('M,d,D,Y,g:i A',strtotime($signee_id->created_at))); ?></p>
                </div>
                <div class="edit_signee_column">
                    <label class="signee_edit_label">Updated At</label>
                    <p style="text-align: center" class="form-control">
                        <?php echo e(date('M,d,D,Y,g:i A',strtotime($signee_id->updated_at))); ?></p>
                </div>
                <div class="edit_signee_column">
                    <label class="signee_edit_label">Deleted At</label>
                    <p style="text-align: center" class="form-control">
                        <?php echo e(date('M,d,D,Y,g:i A',strtotime($signee_id->deleted_at))); ?></p>
                </div>
    
    
            

                

                    <div class="signee_update_btn">
                        <button type="submit" class="btn btn-primary">Update User</button>
                    </div>
                </div>       
            <?php echo Form::close(); ?>

        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Clearance-System\resources\views/admin/edit-signee.blade.php ENDPATH**/ ?>