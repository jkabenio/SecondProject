

<?php $__env->startSection('content'); ?>
 <style>
* {
    box-sizing: border-box;
}

/* Create three equal columns that floats next to each other */
.column {
    float: left;
    width: 20%;
}
.column_info {
    float: left;
    width: 50%;
    
}
.column_label{
    font-size: 15px;
}


/* Clear floats after the columns */
.clearance_row:after {
    content: "";
    display: table;
    clear: both;
}
.clearance_row{
    float:right;
    margin-right: 1px;

}
.clearance_row{
    border: 2px solid;
    height: auto;
    width: 100%; 
}

/* .table_content_select{
    white-space: nowrap; 
    width: 100%; 
    overflow: hidden;
    text-overflow: clip;
    cursor: pointer;
    font-size: 16px;
    text-align: center; 
} */

.signee_close_btn{
 float: right;
 background-color: red;
 color: white;
}
.signee-description-form-popup {
        display: none;
        position: fixed;
        bottom: 50%;
        right:25%;
        left: 25%;
       
        z-index: 9;
       
        width: 50%;
        height: 20%;
        margin-bottom: auto;
      }
  .signee_description_info{
    border: 3px solid #0800ff;
        height: 100%;
        width: 100%;
        background-color: rgb(212, 212, 212);
      }

  select[readonly]
{
    pointer-events: none;
}
/* irrelevent styling */
*[readonly]
{

}
</style>

<script> 
    var expanded = false;
    function showCheckboxes() {
      var checkboxes = document.getElementById("checkboxes");
      if (!expanded) {
        checkboxes.style.display = "block";
        expanded = true;
      } else {
        checkboxes.style.display = "none"; 
        expanded = false;
      }
      
    }
</script>

<script> 
    var expanded = false;
    function showselectedCheckboxes() {
      var selectedcheckboxes = document.getElementById("selectedcheckboxes");
      if (!expanded) {
        selectedcheckboxes.style.display = "block";
        expanded = true;
      } else {
        selectedcheckboxes.style.display = "none"; 
        expanded = false;
      }
      
    }
    </script>

<?php
    $passed_names = array();
    foreach ($student_id->student_signee_names as $signee_list){
       
        $value = $signee_list; 
        array_push($passed_names, $value);

        // $passed_names[] =  $value;
        // echo $passed_names['text'];
        
    }
    // print_r ($passed_names);
    // print_r ($passed_names);
    // $arrayLength = count($passed_names);
    // $i = 0;
    //     while ($i < $arrayLength)
    //     {
    //         echo $passed_names[$i] ."<br />";
    //         $i++;
    //     }
     
?> 

<div class="clearance_body_signee">
    <div class="card" style="width:100%; border: 2px solid black; margin-left: 0.3px;">
        <div class="card-header">
            <h4 class="signee_view_title"> <b>Change Status</b>
                <a href="<?php echo e(url('/signee/view-signee-pending-request')); ?>" class="btn btn-danger float-end">BACK</a>
            </h4>
        </div>
        <?php echo Form::open(['action' => ['App\Http\Controllers\Signee\SigneeController@update_student',$student_id->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

        <div class="card-body">
            <?php echo csrf_field(); ?> 
            <?php echo method_field('PUT'); ?>
            <div class="clearance_row">
                <div class="column_info">
                    <label class="column_label"><b>Student Name</b></label>
                    <input type="text" readonly value="<?php echo e($student_id->name); ?>" class="form-control">
                </div>
                <div class="column_info">
                    <label class="column_label"><b>Student Email</b></label>
                
                        <input type="text" readonly value="<?php echo e($student_id->email); ?>" class="form-control">
                    
                     </div>
                <div class="column_info">
                    <label class="column_label"><b>Student Department</b></label>
                    <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($list->id == $student_id->dept_id): ?>
                            <input type="text" readonly value="<?php echo e($list->dept_name); ?>" class="form-control">
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>  
                <div class="column_info">
                    <label class="column_label"><b>Student Course</b></label>
                    <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($list->id == $student_id->course): ?>
                            <input type="text" readonly value="<?php echo e($list->course_name); ?> (<?php echo e($list->course_acronym); ?>)" class="form-control">
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>       
            </div>
            <div class="clearance_row">
                    <div class="column">
                        <h5 class="table_content_header"  style="border: 1px solid black; text-align:center">Instructor</h5>
                        
                        <?php $__currentLoopData = $student_id->student_signee_names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count_data => $signee_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                            
                                <p class="table_content" style="border: 1px solid black"><?php echo e($signee_list); ?></p>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="column" >
                        <h5 class="table_content_header"  style="border: 1px solid black; text-align:center">Subject</h5>
                        <?php $__currentLoopData = $student_id->subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                    
                                <p class="table_content" title="<?php echo e($subject_list); ?>" style="border: 1px solid black"><?php echo e($subject_list); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="column" >
                        <h5 class="table_content_header"  style="border: 1px solid black;text-align:center">Section</h5>
                        <?php $__currentLoopData = $student_id->student_section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                            <p class="table_content" style="border: 1px solid black;"><?php echo e($section_list); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="column" >
                        <h5 class="table_content_header"  style="border: 1px solid black; text-align:center">Status</h5>
                        <?php $__currentLoopData = $student_id->status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count_data => $status_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                            <p class="table_content" style="border: 1px solid black;">
                                <?php if($status_list == "IN-PROGRESS" &&  Auth::user()->name == $passed_names[$count_data]): ?>
                                    <select class="table_content_select"  name="status[]" style="color:blue">
                                <?php endif; ?>
                                <?php if($status_list == "COMPLY" &&  Auth::user()->name == $passed_names[$count_data]): ?>
                                    <select class="table_content_select"  name="status[]" style="color:orange">
                                <?php endif; ?>
                                <?php if($status_list == "REJECTED" &&  Auth::user()->name == $passed_names[$count_data]): ?>
                                    <select class="table_content_select"  name="status[]" style="color:red">
                                <?php endif; ?>
                                <?php if($status_list == "APPROVED" &&  Auth::user()->name == $passed_names[$count_data]): ?> 
                                    <select class="table_content_select" name="status[]" style="color:green">
                                <?php endif; ?>

                                <?php if($status_list == "IN-PROGRESS" &&  Auth::user()->name !== $passed_names[$count_data]): ?>
                                    <select class="table_content_select"  name="status[]" style="color:blue" readonly tabindex="-1">
                                <?php endif; ?>
                                <?php if($status_list == "COMPLY" &&  Auth::user()->name !== $passed_names[$count_data]): ?>
                                    <select class="table_content_select" name="status[]" style="color:orange" readonly tabindex="-1">
                                <?php endif; ?>
                                <?php if($status_list == "REJECTED" &&  Auth::user()->name !== $passed_names[$count_data]): ?>
                                    <select class="table_content_select"  name="status[]" style="color:red" readonly tabindex="-1">
                                <?php endif; ?>
                                <?php if($status_list == "APPROVED" &&  Auth::user()->name !== $passed_names[$count_data]): ?> 
                                    <select class="table_content_select"  name="status[]" style="color:green" readonly tabindex="-1">
                                <?php endif; ?>
                                <option style="border: 1px solid black; text-align:center" value="<?php echo e($status_list); ?>"><?php echo e($status_list); ?></option>
                            

                                <?php if($status_list !== "IN-PROGRESS"): ?>
                                <option style="border: 1px solid black; text-align:center; color: blue"value="IN-PROGRESS">IN-PROGRESS</option>
                                <?php endif; ?>
                                <?php if($status_list !== "COMPLY"): ?>
                                <option style="border: 1px solid black; text-align:center; color: orange"value="COMPLY">COMPLY</option>
                                <?php endif; ?>
                                <?php if($status_list !== "APPROVED"): ?>
                                <option style="border: 1px solid black; text-align:center; color:green;"value="APPROVED">APPROVED</option>
                                <?php endif; ?>
                                <?php if($status_list !== "REJECTED"): ?>
                                <option style="border: 1px solid black; text-align:center; color:red"value="REJECTED">REJECTED</option>
                                <?php endif; ?>
                                </select>
                            </p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div> 
                    <div class="column"> 
                        <h5 class="table_content_header"  style="border: 1px solid black; text-align:center">Description</h5>
                        <?php $__currentLoopData = $student_id->description; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count_data => $description_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(Auth::user()->name !== $passed_names[$count_data]): ?>
                            <p class="table_content" style="border: 1px solid black; text-align:center;"><a style="color:red">Restricted!</a></p>
                            <?php endif; ?>
                            <?php if((Auth::user()->name == $passed_names[$count_data]) && ($description_list == null)): ?>
                            <p class="table_content" style="border: 1px solid black; text-align:center;"><a onclick="open_edit_signeeForm(<?php echo e($count_data); ?>)">Add Detail</a></p>
                            <?php endif; ?>
                            <?php if((Auth::user()->name == $passed_names[$count_data]) && ($description_list !== null)): ?>
                            <p class="table_content" style="border: 1px solid black; text-align:center;"><a onclick="open_edit_signeeForm(<?php echo e($count_data); ?>)">View Detail</a></p>
                            <?php endif; ?>
                            <div class="signee-description-form-popup" id="edit_signeeForm<?php echo e($count_data); ?>">
                                <textarea class="signee_description_info" name="description[]" value="<?php echo e($description_list); ?>"><?php echo e($description_list); ?></textarea>
                                <button type="button" class="btn cancel signee_close_btn" onclick="close_edit_signeeForm(<?php echo e($count_data); ?>)">Close</button>  
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="clearance_row">
    
                    <div class="column" >
                        <h5 class="table_content_header"  style="border: 1px solid black; text-align:center">Guidance Councilor</h5>
                            <p class="table_content_select" style="border: 1px solid black; text-align:center">
                                <?php if($student_id->guidance_councilor == "IN-PROGRESS" && strcasecmp(Auth::user()->role_as,'Guidance Counselor') == 0): ?>
                                <select class="table_content_select" name="guidance_councilor" style="color:blue">
                                <?php endif; ?>
                                <?php if($student_id->guidance_councilor == "COMPLY" && strcasecmp(Auth::user()->role_as,'Guidance Counselor') == 0): ?>
                                <select class="table_content_select" name="guidance_councilor" style="color:orange">
                                <?php endif; ?>
                                <?php if($student_id->guidance_councilor == "REJECTED" && strcasecmp(Auth::user()->role_as,'Guidance Counselor') == 0): ?>
                                <select class="table_content_select" name="guidance_councilor" style="color:red">
                                <?php endif; ?>
                                <?php if($student_id->guidance_councilor == "APPROVED" && strcasecmp(Auth::user()->role_as,'Guidance Counselor') == 0): ?>
                                <select class="table_content_select" name="guidance_councilor" style="color:green">
                                <?php endif; ?>

                                <?php if($student_id->guidance_councilor == "IN-PROGRESS" && strcasecmp(Auth::user()->role_as,'Guidance Counselor') !== 0): ?>
                                <select class="table_content_select" name="guidance_councilor" style="color:blue" readonly tabindex="-1">
                                <?php endif; ?>
                                <?php if($student_id->guidance_councilor == "COMPLY" && strcasecmp(Auth::user()->role_as,'Guidance Counselor') !== 0): ?>
                                <select name="guidance_councilor" style="color:orange" readonly tabindex="-1">
                                <?php endif; ?>
                                <?php if($student_id->guidance_councilor == "REJECTED" && strcasecmp(Auth::user()->role_as,'Guidance Counselor') !== 0): ?>
                                <select class="table_content_select" name="guidance_councilor" style="color:red" readonly tabindex="-1">
                                <?php endif; ?>
                                <?php if($student_id->guidance_councilor == "APPROVED" && strcasecmp(Auth::user()->role_as,'Guidance Counselor') !== 0): ?>
                                <select class="table_content_select" name="guidance_councilor" style="color:green" readonly tabindex="-1">
                                <?php endif; ?>

                                <option style="border: 1px solid black; text-align:center" value="<?php echo e($student_id->guidance_councilor); ?>"><?php echo e($student_id->guidance_councilor); ?></option>
                                
                                <?php if($student_id->guidance_councilor !== "IN-PROGRESS"): ?>
                                <option style="border: 1px solid black; text-align:center; color: blue"value="IN-PROGRESS">IN-PROGRESS</option>
                                <?php endif; ?>
                                <?php if($student_id->guidance_councilor !== "COMPLY"): ?>
                                <option style="border: 1px solid black; text-align:center; color: orange"value="COMPLY">COMPLY</option>
                                <?php endif; ?>
                                <?php if($student_id->guidance_councilor !== "APPROVED"): ?>
                                <option style="border: 1px solid black; text-align:center; color:green;"value="APPROVED">APPROVED</option>
                                <?php endif; ?>
                                <?php if($student_id->guidance_councilor !== "REJECTED"): ?>
                                <option style="border: 1px solid black; text-align:center; color:red"value="REJECTED">REJECTED</option>
                                <?php endif; ?>
                                </select>
                            </p> 
                            <?php if((strcasecmp(Auth::user()->role_as,'Guidance Counselor') == 0) && ($student_id->guidance_councilor == "REJECTED" || $student_id->guidance_councilor == "COMPLY") && ($student_id->guidance_councilor_description !== null || $student_id->guidance_councilor_description == null)): ?>  
                                <p class="table_content" style="border: 1px solid black; text-align:center;"><a onclick="open_edit_guidance_councilor_Form()">View Detail</a></p>
                            <?php endif; ?>
                            <?php if((strcasecmp(Auth::user()->role_as,'Guidance Counselor') == 0) && ($student_id->guidance_councilor_description == null || $student_id->guidance_councilor_description !== null) && ($student_id->guidance_councilor == "IN-PROGRESS")): ?>  
                                <p class="table_content" style="border: 1px solid black; text-align:center;"><a onclick="open_edit_guidance_councilor_Form()">Add Detail</a></p>
                            <?php endif; ?>
                            <div class="signee-description-form-popup" id="edit_guidance_councilor_form">
                                <textarea class="signee_description_info" name="guidance_councilor_description" value="<?php echo e($student_id->guidance_councilor_description); ?>"><?php echo e($student_id->guidance_councilor_description); ?></textarea>
                                <button type="button" class="btn cancel signee_close_btn" onclick="close_edit_guidance_councilor_Form()">Close</button>  
                            </div>
                    </div>
                    
            <div class="column" >
                <h5 class="table_content_header"  style="border: 1px solid black; text-align:center">Student Org. Treasurer</h5>
                    <p class="table_content_select" style="border: 1px solid black; text-align:center">
                        <?php if($student_id->student_org_treasurer == "IN-PROGRESS" && strcasecmp(Auth::user()->role_as,'Student Org. Treasurer') == 0): ?>
                        <select class="table_content_select" name="student_org_treasurer" style="color:blue">
                        <?php endif; ?>
                        <?php if($student_id->student_org_treasurer == "COMPLY" && strcasecmp(Auth::user()->role_as,'Student Org. Treasurer') == 0): ?>
                            <select class="table_content_select" name="student_org_treasurer" style="color:orange">
                        <?php endif; ?>
                        <?php if($student_id->student_org_treasurer == "REJECTED" && strcasecmp(Auth::user()->role_as,'Student Org. Treasurer') == 0): ?>
                            <select class="table_content_select" name="student_org_treasurer" style="color:red">
                        <?php endif; ?>
                        <?php if($student_id->student_org_treasurer == "APPROVED" && strcasecmp(Auth::user()->role_as,'Student Org. Treasurer') == 0): ?>
                            <select class="table_content_select" name="student_org_treasurer" style="color:green">
                        <?php endif; ?>

                        <?php if($student_id->student_org_treasurer == "IN-PROGRESS" && strcasecmp(Auth::user()->role_as,'Student Org. Treasurer') !== 0): ?>
                        <select class="table_content_select" name="student_org_treasurer" style="color:blue" readonly tabindex="-1">
                        <?php endif; ?>
                        <?php if($student_id->student_org_treasurer == "COMPLY" && strcasecmp(Auth::user()->role_as,'Student Org. Treasurer') !== 0): ?>
                            <select class="table_content_select" name="student_org_treasurer" style="color:orange" readonly tabindex="-1">
                        <?php endif; ?>
                        <?php if($student_id->student_org_treasurer == "REJECTED" && strcasecmp(Auth::user()->role_as,'Student Org. Treasurer') !== 0): ?>
                            <select class="table_content_select" name="student_org_treasurer" style="color:red" readonly tabindex="-1">
                        <?php endif; ?>
                        <?php if($student_id->student_org_treasurer == "APPROVED" && strcasecmp(Auth::user()->role_as,'Student Org. Treasurer') !== 0): ?>
                            <select class="table_content_select" name="student_org_treasurer" style="color:green" readonly tabindex="-1">
                        <?php endif; ?>
    
    
                            <option style="border: 1px solid black; text-align:center" value="<?php echo e($student_id->student_org_treasurer); ?>"><?php echo e($student_id->student_org_treasurer); ?></option>
    
    
                        <?php if($student_id->student_org_treasurer !== "IN-PROGRESS"): ?>
                            <option style="border: 1px solid black; text-align:center; color: blue"value="IN-PROGRESS">IN-PROGRESS</option>
                        <?php endif; ?>
                        <?php if($student_id->student_org_treasurer !== "COMPLY"): ?>
                            <option style="border: 1px solid black; text-align:center; color: orange"value="COMPLY">COMPLY</option>
                        <?php endif; ?>
                        <?php if($student_id->student_org_treasurer !== "APPROVED"): ?>
                            <option style="border: 1px solid black; text-align:center; color:green;"value="APPROVED">APPROVED</option>
                        <?php endif; ?>
                        <?php if($student_id->student_org_treasurer !== "REJECTED"): ?>
                            <option style="border: 1px solid black; text-align:center; color:red"value="REJECTED">REJECTED</option>
                        <?php endif; ?>
                        </select>
                    </p>
                    <?php if((strcasecmp(Auth::user()->role_as,'Student Org. Treasurer') == 0) && ($student_id->student_org_treasurer == "REJECTED" || $student_id->student_org_treasurer == "COMPLY") && ($student_id->student_org_description == null || $student_id->student_org_description !== null)): ?>  
                        <p class="table_content" style="border: 1px solid black; text-align:center;"><a onclick="open_edit_treasurer_Form()">View Detail</a></p>
                    <?php endif; ?>
                    <?php if((strcasecmp(Auth::user()->role_as,'Student Org. Treasurer') == 0) && ($student_id->student_org_description == null || $student_id->student_org_description !== null) && ($student_id->student_org_treasurer == "IN-PROGRESS")): ?>  
                        <p class="table_content" style="border: 1px solid black; text-align:center;"><a onclick="open_edit_treasurer_Form()">Add Detail</a></p>
                    <?php endif; ?>
                    <div class="signee-description-form-popup" id="edit_student_org">
                            <textarea class="signee_description_info" name="student_org_description" value="<?php echo e($student_id->student_org_description); ?>"><?php echo e($student_id->student_org_description); ?></textarea>
                          <button type="button" class="btn cancel signee_close_btn" onclick="close_edit_treasurer_Form()">Close</button>
                        
                      </div>
            </div>
            
            <div class="column" >
                <h5 class="table_content_header"  style="border: 1px solid black; text-align:center">Librarian</h5>
                    <p class="table_content_select" style="border: 1px solid black; text-align:center">
                        <?php if($student_id->librarian == "IN-PROGRESS" && strcasecmp(Auth::user()->role_as,'Librarian') == 0): ?>
                            <select class="table_content_select" name="librarian" style="color:blue" >
                        <?php endif; ?>
                        <?php if($student_id->librarian == "COMPLY" && strcasecmp(Auth::user()->role_as,'Librarian') == 0): ?>
                            <select class="table_content_select" name="librarian" style="color:orange">
                        <?php endif; ?>
                        <?php if($student_id->librarian == "REJECTED" && strcasecmp(Auth::user()->role_as,'Librarian') == 0): ?>
                            <select class="table_content_select" name="librarian" style="color:red">
                        <?php endif; ?>
                        <?php if($student_id->librarian == "APPROVED" && strcasecmp(Auth::user()->role_as,'Librarian') == 0): ?>
                            <select class="table_content_select" name="librarian" style="color:green">
                        <?php endif; ?>
                        
                        <?php if($student_id->librarian == "IN-PROGRESS" && strcasecmp(Auth::user()->role_as,'Librarian') !== 0): ?>
                            <select class="table_content_select" name="librarian" style="color:blue" readonly tabindex="-1">
                        <?php endif; ?>
                        <?php if($student_id->librarian == "COMPLY" && strcasecmp(Auth::user()->role_as,'Librarian') !== 0): ?>
                            <select class="table_content_select" name="librarian" style="color:orange" readonly tabindex="-1">
                        <?php endif; ?>
                        <?php if($student_id->librarian == "REJECTED" && strcasecmp(Auth::user()->role_as,'Librarian') !== 0): ?>
                            <select class="table_content_select" name="librarian" style="color:red" readonly tabindex="-1">
                        <?php endif; ?>
                        <?php if($student_id->librarian == "APPROVED" && strcasecmp(Auth::user()->role_as,'Librarian') !== 0): ?>
                            <select class="table_content_select" name="librarian" style="color:green" readonly tabindex="-1">
                        <?php endif; ?> 
                        
    
                            <option style="border: 1px solid black; text-align:center" value="<?php echo e($student_id->librarian); ?>"><?php echo e($student_id->librarian); ?></option>
    
    
                        <?php if($student_id->librarian !== "IN-PROGRESS"): ?>
                            <option style="border: 1px solid black; text-align:center; color: blue"value="IN-PROGRESS">IN-PROGRESS</option>
                        <?php endif; ?>
                        <?php if($student_id->librarian !== "COMPLY"): ?>
                            <option style="border: 1px solid black; text-align:center; color: orange"value="COMPLY">COMPLY</option>
                        <?php endif; ?>
                        <?php if($student_id->librarian !== "APPROVED"): ?>
                            <option style="border: 1px solid black; text-align:center; color:green;"value="APPROVED">APPROVED</option>
                        <?php endif; ?>
                        <?php if($student_id->librarian !== "REJECTED"): ?>
                            <option style="border: 1px solid black; text-align:center; color:red"value="REJECTED">REJECTED</option>
                        <?php endif; ?>
                    </select>
                    </p>
                    <?php if((strcasecmp(Auth::user()->role_as,'Librarian') == 0) && ($student_id->librarian == "REJECTED" || $student_id->librarian == "COMPLY") && ($student_id->librarian_description !== null || $student_id->librarian_description == null)): ?>  
                        <p class="table_content" style="border: 1px solid black; text-align:center;"><a onclick="open_edit_librarian_Form()">View Detail</a></p>
                    <?php endif; ?>
                    <?php if((strcasecmp(Auth::user()->role_as,'Librarian') == 0) && ($student_id->librarian_description == null || $student_id->librarian_description !== null) && ($student_id->librarian == "IN-PROGRESS")): ?>  
                        <p class="table_content" style="border: 1px solid black; text-align:center;"><a onclick="open_edit_librarian_Form()">Add Detail</a></p>
                    <?php endif; ?>
                    <div class="signee-description-form-popup" id="edit_librarian_form">
                        <textarea class="signee_description_info" name="librarian_description" value="<?php echo e($student_id->librarian_description); ?>"><?php echo e($student_id->librarian_description); ?></textarea>
                        <button type="button" class="btn cancel signee_close_btn" onclick="close_edit_librarian_Form()">Close</button>  
                    </div>
            </div>
            <div class="column" >
                <h5 class="table_content_header"  style="border: 1px solid black; text-align:center">Dean of Student Affair</h5>
                    <p class="table_content_select" style="border: 1px solid black; text-align:center">
                        <?php if($student_id->dean_of_student_affair == "IN-PROGRESS" && strcasecmp(Auth::user()->role_as,'Dean of Student Affair') == 0): ?>
                            <select class="table_content_select" name="dean_of_student_affair" style="color:blue">
                        <?php endif; ?>
                        <?php if($student_id->dean_of_student_affair == "COMPLY" && strcasecmp(Auth::user()->role_as,'Dean of Student Affair') == 0): ?>
                            <select class="table_content_select" name="dean_of_student_affair" style="color:orange">
                        <?php endif; ?>
                        <?php if($student_id->dean_of_student_affair == "REJECTED" && strcasecmp(Auth::user()->role_as,'Dean of Student Affair') == 0): ?>
                            <select class="table_content_select" name="dean_of_student_affair" style="color:red">
                        <?php endif; ?>
                        <?php if($student_id->dean_of_student_affair == "APPROVED" && strcasecmp(Auth::user()->role_as,'Dean of Student Affair') == 0): ?>
                            <select class="table_content_select" name="dean_of_student_affair" style="color:green">
                        <?php endif; ?>

                        <?php if($student_id->dean_of_student_affair == "IN-PROGRESS" && strcasecmp(Auth::user()->role_as,'Dean of Student Affair') !== 0): ?>
                            <select class="table_content_select" name="dean_of_student_affair" style="color:blue" readonly tabindex="-1">
                        <?php endif; ?>
                        <?php if($student_id->dean_of_student_affair == "COMPLY" && strcasecmp(Auth::user()->role_as,'Dean of Student Affair') !== 0): ?>
                            <select class="table_content_select" name="dean_of_student_affair" style="color:orange" readonly tabindex="-1">
                        <?php endif; ?>
                        <?php if($student_id->dean_of_student_affair == "REJECTED" && strcasecmp(Auth::user()->role_as,'Dean of Student Affair') !== 0): ?>
                            <select class="table_content_select" name="dean_of_student_affair" style="color:red" readonly tabindex="-1">
                        <?php endif; ?>
                        <?php if($student_id->dean_of_student_affair == "APPROVED" && strcasecmp(Auth::user()->role_as,'Dean of Student Affair') !== 0): ?>
                            <select class="table_content_select" name="dean_of_student_affair" style="color:green" readonly tabindex="-1">
                        <?php endif; ?>
                        <option style="border: 1px solid black; text-align:center" value="<?php echo e($student_id->dean_of_student_affair); ?>"><?php echo e($student_id->dean_of_student_affair); ?></option>
                       
                        
                        <?php if($student_id->dean_of_student_affair !== "IN-PROGRESS"): ?>
                        <option style="border: 1px solid black; text-align:center; color: blue"value="IN-PROGRESS">IN-PROGRESS</option>
                        <?php endif; ?>
                        <?php if($student_id->dean_of_student_affair !== "COMPLY"): ?>
                        <option style="border: 1px solid black; text-align:center; color: orange"value="COMPLY">COMPLY</option>
                        <?php endif; ?>
                        <?php if($student_id->dean_of_student_affair !== "APPROVED"): ?>
                        <option style="border: 1px solid black; text-align:center; color:green;"value="APPROVED">APPROVED</option>
                        <?php endif; ?>
                        <?php if($student_id->dean_of_student_affair !== "REJECTED"): ?>
                        <option style="border: 1px solid black; text-align:center; color:red"value="REJECTED">REJECTED</option>
                        <?php endif; ?>
                        </select>
                    </p>
                    <?php if(( strcasecmp(Auth::user()->role_as,'Dean of Student Affair') == 0) && ($student_id->dean_of_student_affair == "REJECTED" || $student_id->dean_of_student_affair == "COMPLY") && ($student_id->dean_of_student_affair_description !== null || $student_id->dean_of_student_affair_description == null)): ?> 
                        <p class="table_content" style="border: 1px solid black; text-align:center;"><a onclick="open_edit_studentaffair_Form()">View Detail</a></p>
                    <?php endif; ?>
                    <?php if(( strcasecmp(Auth::user()->role_as,'Dean of Student Affair') == 0) && ($student_id->dean_of_student_affair_description == null || $student_id->dean_of_student_affair_description !== null) && ($student_id->dean_of_student_affair == "IN-PROGRESS")): ?>  
                        <p class="table_content" style="border: 1px solid black; text-align:center;"><a onclick="open_edit_studentaffair_Form()">Add Detail</a></p>
                    <?php endif; ?>
                        <div class="signee-description-form-popup" id="edit_studentaffair_form">
                        <textarea class="signee_description_info" name="dean_of_student_affair_description" value="<?php echo e($student_id->dean_of_student_affair_description); ?>"><?php echo e($student_id->dean_of_student_affair_description); ?></textarea>
                        <button type="button" class="btn cancel signee_close_btn" onclick="close_edit_studentaffair_Form()">Close</button>  
                    </div>
            </div>
            <div class="column" >
                <h5 class="table_content_header"  style="border: 1px solid black; text-align:center">Dean Principal</h5>
                    <p class="table_content_select" style="border: 1px solid black; text-align:center">
                        <?php if($student_id->dean_principal == "IN-PROGRESS" && strcasecmp(Auth::user()->role_as,'Dean Principal') == 0): ?>
                        <select class="table_content_select" name="dean_principal" style="color:blue">
                        <?php endif; ?>
                        <?php if($student_id->dean_principal == "COMPLY" && strcasecmp(Auth::user()->role_as,'Dean Principal') == 0): ?>
                        <select class="table_content_select" name="dean_principal" style="color:orange">
                        <?php endif; ?>
                        <?php if($student_id->dean_principal == "REJECTED" && strcasecmp(Auth::user()->role_as,'Dean Principal') == 0): ?>
                        <select class="table_content_select" name="dean_principal" style="color:red">
                        <?php endif; ?>
                        <?php if($student_id->dean_principal == "APPROVED" && strcasecmp(Auth::user()->role_as,'Dean Principal') == 0): ?>
                        <select class="table_content_select" name="dean_principal" style="color:green">
                        <?php endif; ?>

                        <?php if($student_id->dean_principal == "IN-PROGRESS" && strcasecmp(Auth::user()->role_as,'Dean Principal') !== 0): ?>
                        <select class="table_content_select" name="dean_principal" style="color:blue" readonly tabindex="-1">
                        <?php endif; ?>
                        <?php if($student_id->dean_principal == "COMPLY" && strcasecmp(Auth::user()->role_as,'Dean Principal') !== 0): ?>
                        <select class="table_content_select" name="dean_principal" style="color:orange" readonly tabindex="-1">
                        <?php endif; ?>
                        <?php if($student_id->dean_principal == "REJECTED" && strcasecmp(Auth::user()->role_as,'Dean Principal') !== 0): ?>
                        <select class="table_content_select" name="dean_principal" style="color:red" readonly tabindex="-1">
                        <?php endif; ?>
                        <?php if($student_id->dean_principal == "APPROVED" && strcasecmp(Auth::user()->role_as,'Dean Principal') !== 0): ?>
                        <select class="table_content_select" name="dean_principal" style="color:green" readonly tabindex="-1">
                        <?php endif; ?>
                        <option style="border: 1px solid black; text-align:center" value="<?php echo e($student_id->dean_principal); ?>"><?php echo e($student_id->dean_principal); ?></option>
                       
                        
                        <?php if($student_id->dean_principal !== "IN-PROGRESS"): ?>
                        <option style="border: 1px solid black; text-align:center; color: blue"value="IN-PROGRESS">IN-PROGRESS</option>
                        <?php endif; ?>
                        <?php if($student_id->dean_principal !== "COMPLY"): ?>
                        <option style="border: 1px solid black; text-align:center; color: orange"value="COMPLY">COMPLY</option>
                        <?php endif; ?>
                        <?php if($student_id->dean_principal !== "APPROVED"): ?>
                        <option style="border: 1px solid black; text-align:center; color:green;"value="APPROVED">APPROVED</option>
                        <?php endif; ?>
                        <?php if($student_id->dean_principal !== "REJECTED"): ?>
                        <option style="border: 1px solid black; text-align:center; color:red"value="REJECTED">REJECTED</option>
                        <?php endif; ?>
                        </select> 
                    </p>
                    <?php if((strcasecmp(Auth::user()->role_as,'Dean Principal') == 0) && ($student_id->dean_principal == "REJECTED" || $student_id->dean_principal == "COMPLY") && ($student_id->dean_principal_description !== null || $student_id->dean_principal_description == null)): ?> 
                    <p class="table_content" style="border: 1px solid black; text-align:center;"><a onclick="open_edit_deanprincipal_Form()">View Detail</a></p>
                    <?php endif; ?>
                    <?php if(( strcasecmp(Auth::user()->role_as,'Dean Principal') == 0) && ($student_id->dean_principal_description == null || $student_id->dean_principal_description !== null) && ($student_id->dean_principal == "IN-PROGRESS")): ?>  
                        <p class="table_content" style="border: 1px solid black; text-align:center;"><a onclick="open_edit_deanprincipal_Form()">Add Detail</a></p>
                    <?php endif; ?>
                    <div class="signee-description-form-popup" id="edit_deanprincipal_form">
                    <textarea class="signee_description_info" name="dean_principal_description" value="<?php echo e($student_id->dean_principal_description); ?>"><?php echo e($student_id->dean_principal_description); ?></textarea>
                    <button type="button" class="btn cancel signee_close_btn" onclick="close_edit_deanprincipal_Form()">Close</button>  
                </div>
            </div>
            <div class="column" >
                <h5 class="table_content_header"  style="border: 1px solid black; text-align:center">Registrar</h5>
                    <p class="table_content_select" style="border: 1px solid black; text-align:center">
                        <?php if($student_id->registrar == "IN-PROGRESS" && strcasecmp(Auth::user()->role_as,'Registrar') == 0): ?>
                            <select class="table_content_select" name="registrar" style="color:blue">
                        <?php endif; ?>
                        <?php if($student_id->registrar == "COMPLY" && strcasecmp(Auth::user()->role_as,'Registrar') == 0): ?>
                            <select class="table_content_select" name="registrar" style="color:orange">
                        <?php endif; ?>
                        <?php if($student_id->registrar == "REJECTED" && strcasecmp(Auth::user()->role_as,'Registrar') == 0): ?>
                            <select class="table_content_select" name="registrar" style="color:red">
                        <?php endif; ?>
                        <?php if($student_id->registrar == "APPROVED" && strcasecmp(Auth::user()->role_as,'Registrar') == 0): ?>
                            <select class="table_content_select" name="registrar" style="color:green">
                        <?php endif; ?>

                        <?php if($student_id->registrar == "IN-PROGRESS" && strcasecmp(Auth::user()->role_as,'Registrar') !== 0): ?>
                            <select class="table_content_select" name="registrar" style="color:blue" readonly tabindex="-1">
                        <?php endif; ?>
                        <?php if($student_id->registrar == "COMPLY" && strcasecmp(Auth::user()->role_as,'Registrar') !== 0): ?>
                            <select class="table_content_select" name="registrar" style="color:orange" readonly tabindex="-1">
                        <?php endif; ?>
                        <?php if($student_id->registrar == "REJECTED" && strcasecmp(Auth::user()->role_as,'Registrar') !== 0): ?>
                            <select class="table_content_select" name="registrar" style="color:red" readonly tabindex="-1">
                        <?php endif; ?>
                        <?php if($student_id->registrar == "APPROVED" && strcasecmp(Auth::user()->role_as,'Registrar') !== 0): ?>
                            <select class="table_content_select" name="registrar" style="color:green" readonly tabindex="-1">
                        <?php endif; ?>
                        <option style="border: 1px solid black; text-align:center" value="<?php echo e($student_id->registrar); ?>"><?php echo e($student_id->registrar); ?></option>
                       
                        
                        <?php if($student_id->registrar !== "IN-PROGRESS"): ?>
                        <option style="border: 1px solid black; text-align:center; color: blue"value="IN-PROGRESS">IN-PROGRESS</option>
                        <?php endif; ?>
                        <?php if($student_id->registrar !== "COMPLY"): ?>
                        <option style="border: 1px solid black; text-align:center; color: orange"value="COMPLY">COMPLY</option>
                        <?php endif; ?>
                        <?php if($student_id->registrar !== "APPROVED"): ?>
                        <option style="border: 1px solid black; text-align:center; color:green;"value="APPROVED">APPROVED</option>
                        <?php endif; ?>
                        <?php if($student_id->registrar !== "REJECTED"): ?>
                        <option style="border: 1px solid black; text-align:center; color:red"value="REJECTED">REJECTED</option>
                        <?php endif; ?>
                        </select>
                    </p>
                    <?php if((strcasecmp(Auth::user()->role_as,'Registrar') == 0) && ($student_id->registrar == "REJECTED" || $student_id->registrar == "COMPLY") && ($student_id->registrar_description !== null || $student_id->registrar_description == null)): ?> 
                        <p class="table_content" style="border: 1px solid black; text-align:center;"><a onclick="open_edit_registrar_Form()">View Detail</a></p>
                    <?php endif; ?>
                    <?php if((strcasecmp(Auth::user()->role_as,'Registrar') == 0) && ($student_id->registrar_description == null || $student_id->registrar_description !== null) && ($student_id->registrar == "IN-PROGRESS")): ?>  
                        <p class="table_content" style="border: 1px solid black; text-align:center;"><a onclick="open_edit_registrar_Form()">Add Detail</a></p>
                    <?php endif; ?>
                    <div class="signee-description-form-popup" id="edit_registrar_form">
                        <textarea class="signee_description_info" name="registrar_description" value="<?php echo e($student_id->registrar_description); ?>"><?php echo e($student_id->registrar_description); ?></textarea>
                        <button type="button" class="btn cancel signee_close_btn" onclick="close_edit_registrar_Form()">Close</button>  
                    </div>
            </div>
            <div class="column" >
                <h5 class="table_content_header"  style="border: 1px solid black; text-align:center">Accounting Assessment</h5>
                    <p class="table_content_select" style="border: 1px solid black; text-align:center">
                        <?php if($student_id->accounting_assessment == "IN-PROGRESS" && strcasecmp(Auth::user()->role_as,'Accounting Assessment') == 0): ?>
                            <select class="table_content_select" name="accounting_assessment" style="color:blue">
                        <?php endif; ?>
                        <?php if($student_id->accounting_assessment == "COMPLY" && strcasecmp(Auth::user()->role_as,'Accounting Assessment') == 0): ?>
                            <select class="table_content_select" name="accounting_assessment" style="color:orange">
                        <?php endif; ?>
                        <?php if($student_id->accounting_assessment == "REJECTED" && strcasecmp(Auth::user()->role_as,'Accounting Assessment') == 0): ?>
                            <select class="table_content_select" name="accounting_assessment" style="color:red">
                        <?php endif; ?>
                        <?php if($student_id->accounting_assessment == "APPROVED" && strcasecmp(Auth::user()->role_as,'Accounting Assessment') == 0): ?>
                            <select class="table_content_select" name="accounting_assessment" style="color:green">
                        <?php endif; ?>

                        <?php if($student_id->accounting_assessment == "IN-PROGRESS" && strcasecmp(Auth::user()->role_as,'Accounting Assessment') !== 0): ?>
                            <select class="table_content_select" name="accounting_assessment" style="color:blue" readonly tabindex="-1">
                        <?php endif; ?>
                        <?php if($student_id->accounting_assessment == "COMPLY" && strcasecmp(Auth::user()->role_as,'Accounting Assessment') !== 0): ?>
                            <select class="table_content_select" name="accounting_assessment" style="color:orange" readonly tabindex="-1">
                        <?php endif; ?>
                        <?php if($student_id->accounting_assessment == "REJECTED" && strcasecmp(Auth::user()->role_as,'Accounting Assessment') !== 0): ?>
                            <select class="table_content_select" name="accounting_assessment" style="color:red" readonly tabindex="-1">
                        <?php endif; ?>
                        <?php if($student_id->accounting_assessment == "APPROVED" && strcasecmp(Auth::user()->role_as,'Accounting Assessment') !== 0): ?>
                            <select class="table_content_select" name="accounting_assessment" style="color:green" readonly tabindex="-1">
                        <?php endif; ?>
                        <option style="border: 1px solid black; text-align:center" value="<?php echo e($student_id->accounting_assessment); ?>"><?php echo e($student_id->accounting_assessment); ?></option>
                       
                        
                        <?php if($student_id->accounting_assessment !== "IN-PROGRESS"): ?>
                        <option style="border: 1px solid black; text-align:center; color: blue"value="IN-PROGRESS">IN-PROGRESS</option>
                        <?php endif; ?>
                        <?php if($student_id->accounting_assessment !== "COMPLY"): ?>
                        <option style="border: 1px solid black; text-align:center; color: orange"value="COMPLY">COMPLY</option>
                        <?php endif; ?>
                        <?php if($student_id->accounting_assessment !== "APPROVED"): ?>
                        <option style="border: 1px solid black; text-align:center; color:green;"value="APPROVED">APPROVED</option>
                        <?php endif; ?>
                        <?php if($student_id->accounting_assessment !== "REJECTED"): ?>
                        <option style="border: 1px solid black; text-align:center; color:red"value="REJECTED">REJECTED</option>
                        <?php endif; ?>
                        </select>
                    </p>
                        <?php if((strcasecmp(Auth::user()->role_as,'Accounting Assessment') == 0) && ($student_id->accounting_assessment == "REJECTED" || $student_id->accounting_assessment == "COMPLY") && ($student_id->accounting_assessment_description !== null || $student_id->accounting_assessment_description == null)): ?>  
                            <p class="table_content" style="border: 1px solid black; text-align:center;"><a onclick="open_edit_assessment_Form()">View Detail</a></p>
                        <?php endif; ?>
                        <?php if(( strcasecmp(Auth::user()->role_as,'Accounting Assessment') == 0) && ($student_id->accounting_assessment_description == null || $student_id->accounting_assessment_description !== null) && ($student_id->accounting_assessment == "IN-PROGRESS")): ?>  
                            <p class="table_content" style="border: 1px solid black; text-align:center;"><a onclick="open_edit_assessment_Form()">Add Detail</a></p>
                        <?php endif; ?>
                        <div class="signee-description-form-popup" id="edit_assessment_form">
                            <textarea class="signee_description_info" name="accounting_assessment_description" value="<?php echo e($student_id->accounting_assessment_description); ?>"><?php echo e($student_id->accounting_assessment_description); ?></textarea>
                            <button type="button" class="btn cancel signee_close_btn" onclick="close_edit_assessment_Form()">Close</button>  
                        </div>
            </div>
        </div>
        </div>
            <button type="submit" style="border-radius: 2px" class="btn_update_signee btn-primary">Update User</button>
    <?php echo Form::close(); ?>

    </div>
    

</div>    
               
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.signee-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Clearance-System\resources\views/signee/edit-student.blade.php ENDPATH**/ ?>