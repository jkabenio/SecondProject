

<?php $__env->startSection('content'); ?>

    
    
        <div class="clearance_body_admin">
            <div class="card" style="width:100%; border: 2px solid black">
                <div class="card-header">
                    <h4> View Users</h4>
                </div>
                <div class="card-body">
        
                    <?php if(session('success')): ?>
                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>
                    
                    <table class="table table-bordered" style="width:900px; border: 1px solid black">
                        <thead >
                            <tr >
        
                                <th>ID</th>
                                <th>name</th>
                                <th>email</th>
                                <th>School ID</th>
                                
                                <th>Role</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody >
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr >
                                <?php if($item->role_as == '0'): ?>
                                <td><?php echo e($item->id); ?></td>
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->email); ?></td>
                                <td><?php echo e($item->school_id); ?></td>
                                
                                <td>
                                    
                                    <?php echo e($item->role_as == '0' ? 'Student' : ''); ?>

                                    
                                    <?php echo e($item->role_as == '1' ? 'Admin':''); ?>

                                    <?php echo e($item->role_as == '2' ? 'Instructor' : ''); ?>


                                </td>
                                
                                <td>
                                    <a href="<?php echo e(url ('admin/'.$item->id)); ?>" class="btn btn-success">Edit</a>
                                </td>
                                <td>
                                    <a href="<?php echo e(url('admin/delete-user/'.$item->id)); ?>" class="btn btn-danger">Delete</a>
                                </td>
                            </tr>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
         
                    </table>
                    
                    <?php echo e($users_count->links()); ?> 
                </div>
            </div>
        
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Clearance-System\resources\views/admin/view-users.blade.php ENDPATH**/ ?>