

<?php $__env->startSection('content'); ?>

<style>
    td{
      white-space:nowrap;
      text-overflow:ellipsis; 
      overflow:hidden;
      
    }
</style> 
        <div class="clearance_body_admin">
            <div class="card" style="width:99%; border: 2px solid black">
                <div class="card-header">
                    <h4>Student List</h4>
                </div>
                <div class="card-body">
                    <table class="table table-bordered" style="width:900px; border: 1px solid black">
                        <thead >
                            <tr >
                                <?php echo Form::open(['action' => 'App\Http\Controllers\Admin\SearchController@index', 'method' => 'GET', 'enctype' => 'multipart/form-data']); ?>

                                <?php echo e(csrf_field()); ?>

                                <div class="col-md-4" style="padding-left: 0px">
                                    <input type="text" class="form-control" value="" name="query" id="query"  placeholder="Search by: Name or School ID"/>
                                </div>
                                <?php echo Form::close(); ?>

                                
                                <th>No.</th>
                                <th>name</th>
                                <th>email</th>
                                <th>School ID</th>
                                
                                <th>Role</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                        </thead> 
                        <tbody >
                            <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count_data => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                      
                            <tr> 
                                <td ><?php echo e($count_data + 1); ?></td>
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->email); ?></td>
                                <td><?php echo e($item->school_id); ?></td>
                                
                                
                                <td>
                                    <?php echo e($item->role_as == '0' ? 'Student' : ''); ?>

                                    
                                    <?php echo e($item->role_as == '1' ? 'Admin':''); ?>

                                    <?php echo e($item->role_as == '2' ? 'Instructor' : ''); ?>

                                </td>                                
                                <td>
                                    <a class="w3-button w3-green"  href="<?php echo e(url ('admin/edit-student/'.$item->id)); ?>" ><i class="material-icons">&#xe22b;</i></a>
                                </td>
                                <td>
                                    <button onclick="document.getElementById(<?php echo e($item->id); ?>).style.display='block'" class="w3-button w3-red"><i style="font-size:24px" class="fa">&#xf014;</i></button>
                                    
                                    
                                </td>
                            </tr>
                            
                        </div>
                        <div id="<?php echo e($item->id); ?>" class="w3-modal" >
                            <div class="w3-modal-content" style="width:30%;">
                          
                              <header class="w3-container w3-blue">
                                <span onclick="document.getElementById(<?php echo e($item->id); ?>).style.display='none'"
                                class="w3-button w3-display-topright">&times;</span>
                                <b><h2 style="color: rgb(248, 50, 50)">WARNING!</h2>
                              </header>
                          
                              <div class="w3-container">
                                <p>Are you sure you want to delete<br>ID:<?php echo e($item->id); ?><br>Student Name:<?php echo e($item->name); ?> ?</p>

                                
                              </div>
                          
                              <footer class="w3-container w3-blue">
                                <p><a style="background-color: red" href="<?php echo e(url ('admin/delete-student/'.$item->id)); ?>" >YES</a> <a style="background-color: green" href="<?php echo e(url ('/admin/view-student-user')); ?>" >NO </b></a></p>
                              
                              </footer>
                          
                            </div>
                          </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody> 
            
                    </table>
                    <?php echo e($student->links()); ?>

                    
                </div>
            </div>       

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Clearance-System\resources\views/admin/search.blade.php ENDPATH**/ ?>