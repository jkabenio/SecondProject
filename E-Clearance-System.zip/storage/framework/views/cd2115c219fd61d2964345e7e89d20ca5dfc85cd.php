
<style> 
    body {font-family: Arial, Helvetica, sans-serif;}
    * {box-sizing: border-box;}
    
    /* Button used to open the contact form - fixed at the bottom of the page */
    .open-button {
      background-color: #555;
      color: white;
      padding: 16px 20px;
      border: none;
      cursor: pointer;
      opacity: 0.8;
      position: fixed;
      bottom: 23px;
      right: 28px;
      width: 150px;
      
    }
    
    /* The popup form - hidden by default */
    .form-popup {
      display: none;
      position: fixed;
      bottom: 0;
      right: 15px;
      border: 3px solid #f1f1f1;
      z-index: 9;
    }
    
    /* Add styles to the form container */
    .form-container {
      
      margin: auto !important;
    width: 300px !important;
    height: 300px !important;
    overflow: auto !important;
    /* way to prevent an element from scrolling its parent. */
    overscroll-behavior: contain;
    }
    
    /* Full-width input fields
    .form-container input[type=text], .form-container input[type=password] {
      width: 100%;
      padding: 15px;
      margin: 5px 0 22px 0;
      border: none;
      background: #f1f1f1;
    } */
    
    /* When the inputs get focus, do something
    .form-container input[type=text]:focus, .form-container input[type=password]:focus {
      background-color: #ddd;
      outline: none;
    } */
    
    /* Set a style for the submit/login button */
    .form-container .btn {
      background-color: #04AA6D;
      color: white;
      padding: 16px 20px;
      border: none;
      cursor: pointer;
      width: 100%;
      margin-bottom:10px;
      opacity: 0.8;
    }
    
    /* Add a red background color to the cancel button */
    .form-container .cancel {
      background-color: red;
      width: 50px;
      font-size: 12px;
      height: 24px;
      padding-top: 2px;
      margin-top: 0px;
      margin-bottom: 0px;
      border-radius: 0px;
      margin-left: 235px;
      /* position: fixed; */
    }
    
    /* Add some hover effects to buttons */
    .form-container .btn:hover, .open-button:hover {
      opacity: 1;
    } 
     /* Remove scrollbar space */
      /* Optional: just make scrollbar invisible */
    /* ::-webkit-scrollbar {
    width: 0; 
    background: transparent; 
    } */
    .cancel_bg{
      background-color:rgb(1, 1, 100);
      width: 275px;
      height: 24px;
      position: fixed;
    }
    </style> 

<button class="open-button" onclick="openForm()">Active Users</button>

<div class="form-popup" id="myForm"  >
  <form  class="form-container" style="background-color: rgb(1, 1, 100); ">
    <table class="table" style=" font-size: 10px; background-color: rgb(1, 1, 100); color: white;">
      <thead >
          <tr >
            <button type="button" class="btn cancel" onclick="closeForm()">&times;</button>
              
          </tr>
      </thead>
      <tbody >
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr >
              <td><?php echo e($item_activity->name); ?></td>
              <td>
                  <?php echo e(Carbon\Carbon::parse($item_activity->last_seen)->diffForHumans()); ?>

              </td>

              <td>
                  <?php if(Cache::has('user-is-online-' . $item_activity->id)): ?>
                  <span class="text-success">Online</span>
                  
                  <?php else: ?>
                  <span class="text-secondary">Offline</span>
                  <?php endif; ?>
                  
              </td>
          </tr>
          
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>

  </table>
  
    
  </form>
</div>

<?php /**PATH C:\xampp\htdocs\E-Clearance-System\resources\views/inc/user_list_activity.blade.php ENDPATH**/ ?>