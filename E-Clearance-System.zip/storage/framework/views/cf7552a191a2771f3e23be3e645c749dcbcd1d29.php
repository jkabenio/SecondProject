<?php $__env->startSection('content'); ?>
<div class="clearance_body_student">        
    <div class="card-header-dashboard">
        <img src="/img/logo.png" alt="Italian Trulli">
        <h2 style="text-align: center"><b> Our Lady of Lourdes College Foundation</h2>
        <h5 style="text-align: center">Daet, Camarines Norte</h5>
        <h4 style="text-align: center">E-CLEARANCE</b>
        </h4>
        <p  style="text-align: center;font-size: 12px"> 
            AY 2021-2022<br>
            2nd Semester
        </p>
        <div class="two_column ">
            <div class="form-control" style="font-size: 12px">
                <?php if(auth()->guard()->guest()): ?>
                    <?php if(Route::has('login')): ?>
                            <button class="login_style"><a  href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a></button>
                    <?php endif; ?>
                    <br>
                    <?php if(Route::has('register')): ?>
                            <button class="login_style"><a  href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a></button>
                    <?php endif; ?>
                    <?php else: ?>
                    <a>
                        <a id="navbarDropdown" class="nav-link_name dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <b><?php echo e(Auth::user()->name); ?></b>
                        </a>
                    </a>
                    
                    <div  class="dropdown-menu dropdown-menu-center" aria-labelledby="navbarDropdown" >
                        <a  class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?>   
                        </a>
                        <form  id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                    </a>
                <?php endif; ?>
            </div>
        </div>
        <div class="two_column ">
            <p class="form-control">
                <b> BSIT-4</b>
            </p>
        </div>
        
        
    </div>
    <div class="card-body">
        <div class="first_row">
            
        </div>
        <div class="second_row">
            <div class="four_column">
                <label><b>SUBJECTS</b></label>
                <p class="form-control">
                    Ethics
                </p>
                
                <p class="form-control">
                    Panitikang Panlipunan
                </p>

                <p class="form-control">
                    Social Issues and Professional Practices(Ethics 2)
                </p>

                <p class="form-control">
                    Advance Database System
                </p>

                <p class="form-control">
                    Computer Arch. and Organization(Assembly Language)
                </p>

                <p class="form-control">
                    Modeling Simulation & Microcontroller(Robotics 1)
                </p>

                <p class="form-control">
                    Web Development 2
                </p>

                <p class="form-control">
                    IT Elective 3 (Event- Driven Programming)
                </p>

                <p class="form-control">
                    System Integration & Architecture
                </p>
            </div>
        
            <div class="four_column">
                <label><b>INSTRUCTOR</b></label>
                <p class="form-control">
                    Seven P. Martinez
                </p>

                <p class="form-control">
                    Michelle Baay
                </p>

                <p class="form-control">
                    Christine Ponayo
                </p>

                <p class="form-control">
                    Darwin Pajarillo
                </p>

                <p class="form-control">
                    David William Egar 
                </p>

                <p class="form-control">
                    Darwin Pajarillo
                </p>

                <p class="form-control">
                    Michelle Baay
                </p>

                <p class="form-control">
                    Seven P. Martinez
                </p>

                <p class="form-control">
                    Christine Ponayo
                </p>
            </div>
            <div class="four_column">
                <label><b>STATUS</b></label>
                <p class="form-control"  style="color: orange;">
                    <b>COMPLY</b>
                </p>

                <p class="form-control" style="color: red;">
                    <b>REJECTED</b>
                </p>

                <p class="form-control" style="color: green;">
                    <b>APPROVED</b>
                </p>

                <p class="form-control" style="color: blue;">
                    <b>IN-PROGRESS</b>
                </p>

                <p class="form-control" style="color: blue; ">
                    <b>IN-PROGRESS</b>
                </p>

                <p class="form-control" style="color: blue;">
                    <b>IN-PROGRESS</b>
                </p>

                <p class="form-control" style="color: blue;">
                    <b>IN-PROGRESS</b>
                </p>

                <p class="form-control" style="color: blue;">
                    <b>IN-PROGRESS</b>
                </p>

                <p class="form-control" style="color: blue;">
                    <b>IN-PROGRESS</b>
                </p>
            </div>
            <div class="four_column">
                <label><b>DESCRIPTION</b></label>
                <p class="form-control">
                    <a href="#"><b>view details</b></a>
                </p>

                <p class="form-control">
                    <a href="#"><b>view details</b> </a>
                </p>

                <p class="form-control">
                </p>

                <p class="form-control">
                </p>

                <p class="form-control">
                </p>

                <p class="form-control">
                </p>

                <p class="form-control">
                </p>

                <p class="form-control">
                </p>

                <p class="form-control">
                </p>
                
            </div>
            
            <div class="four_column">
                <br> <br>
                <label><b>Student</b></label>
                <p class="form-control" style="color: blue;">
                    <b>INPROGRESS</b>
                </p>
            </div>
            <div class="four_column">
                <br> <br>
                <label><b>Student Org. Treasurer</b></label>
                <p class="form-control" style="color: blue;">
                    <b>IN-PROGRESS</b>
                </p>
            </div>
            <div class="four_column">
                <br> <br>
                <label><b>Librarian</b></label>
                <p class="form-control" style="color: blue;">
                    <b>IN-PROGRESS</b>
                </p>
            </div>
            <div class="four_column">
                <br> <br> 
                <label><b>Dean of Student affair</b></label>
                <p class="form-control" style="color: blue;">
                    <b>IN-PROGRESS</b>
                </p>
            </div>
            <div class="four_column">
                <label><b>Dean Principal</b></label>
                <p class="form-control" style="color: blue;">
                    <b>IN-PROGRESS</b>
                </p>
            </div>
            <div class="four_column">
                <label><b>Guidance Councilor</b></label>
                <p class="form-control" style="color: blue;">
                    <b>IN-PROGRESS</b>
                </p>
            </div>
            <div class="four_column">
                <label><b>Registrar</b></label>
                <p class="form-control" style="color: blue;">
                    <b>IN-PROGRESS</b>
                </p> 
            </div>
            <div class="four_column">
                <label><b>Accounting-Assessment</b></label>
                <p class="form-control" style="color: blue;">
                    <b>IN-PROGRESS</b>
                </p>
            </div>
            
        </div>  
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.student-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Clearance-System\resources\views/pages/student/studentdashboard.blade.php ENDPATH**/ ?>