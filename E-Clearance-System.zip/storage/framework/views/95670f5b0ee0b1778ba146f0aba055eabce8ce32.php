

<?php $__env->startSection('content'); ?>
<div class="clearance_body_admin">
    <div class="card" style="width:100%; border: 2px solid black; ">      
        <div class="card-header" style="background-color: white">
            
        
            <div class="first_row">
                <div class="two_column" style="background-color:rgb(204, 201, 201); "> 
                    <h3 style="color:blue;">Add New Student</h3>
                    <div class="card-body" style="padding: 0px; margin: 0px; font-size: 12px" >
                        <?php echo Form::open(['action' => 'App\Http\Controllers\Admin\AdminController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                            <?php echo e(csrf_field()); ?>

                            <div class="row mb-3">
                                <label for="name" class="col-md-4 col-form-label text-md-end" style="color: black"><?php echo e(__('Name')); ?> </label>
                                <div class="col-md-6">
                                    <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label for="school_id" class="col-md-4 col-form-label text-md-end" style="color: black">
                                    <?php echo e(__('User_ID')); ?>

                                </label>                   
                                <div class="col-md-6">
                                    <input id="school_id" type="text"
                                        class="form-control<?php echo e($errors->has('school_id') ? ' is-invalid' : ''); ?>"
                                        name="school_id" value="<?php echo e(old('school_id')); ?>" required>
                            
                                    <?php if($errors->has('username')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('username')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label for="email" class="col-md-4 col-form-label text-md-end" style="color: black"><?php echo e(__('Email Address')); ?></label>
                                <div class="col-md-6">
                                    <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label for="password" class="col-md-4 col-form-label text-md-end" style="color: black"><?php echo e(__('Password')); ?></label>

                                <div class="col-md-6">
                                    <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password">

                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label for="password-confirm" class="col-md-4 col-form-label text-md-end" style="color: black"><?php echo e(__('Confirm Password')); ?></label>

                                <div class="col-md-6">
                                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                                </div>
                            </div>
                            
                            <div class="row mb-3">
                                <label for="role_as" class="col-md-4 col-form-label text-md-end" style="color: black"><?php echo e(__('Role')); ?></label>

                                <div class="col-md-6">

                                    <select class="form-control" name="role_as">
                                        <option value="0" >student</option>
                                        <option value="2" >instructor</option>
                                        
                                        </select>
                                
                                </div>
                            </div>
                            

                            <div class="form-group">
                                <input type="submit" class="btn btn-primary"/>
                            </div>
                        
                        <?php echo Form::close(); ?>

                    </div>
                </div>
                
                <div class="two_column" style="background-color:rgb(224, 224, 225);">
                    <h3 style="color:blue">Activity Logs</h3>
                    <table class="table table-bordered" style=" border: 1px solid black; font-size: 12px;">
                        <thead >
                            <tr > 
                                <th>Name</th>
                                <th>Email</th>
                                <th>Date Created</th>
                            </tr>
                        </thead>
                        <tbody >
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr  >
                                
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->email); ?></td>
                                <td><?php echo e(date('M,D,Y,g:i A',strtotime($item->created_at))); ?></td>
                                
                            </tr>
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>        
                    </table>                   
                    <?php echo e($users->links()); ?> 
                </div>
                
             </div>
             
         </div> 
         
    </div>
    
</div>











<style> 
    body {font-family: Arial, Helvetica, sans-serif;}
    * {box-sizing: border-box;}
    
    /* Button used to open the contact form - fixed at the bottom of the page */
    .open-button {
      background-color: #555;
      color: white;
      padding: 16px 20px;
      border: none;
      cursor: pointer;
      opacity: 0.8;
      position: fixed;
      bottom: 23px;
      right: 28px;
      width: 150px;
      
    }
    
    /* The popup form - hidden by default */
    .form-popup {
      display: none;
      position: fixed;
      bottom: 0;
      right: 15px;
      border: 3px solid #f1f1f1;
      z-index: 9;
    }
    
    /* Add styles to the form container */
    .form-container {
      
      margin: auto !important;
    width: 300px !important;
    height: 300px !important;
    overflow: auto !important;
    /* way to prevent an element from scrolling its parent. */
    overscroll-behavior: contain;
    }
    
    /* Full-width input fields
    .form-container input[type=text], .form-container input[type=password] {
      width: 100%;
      padding: 15px;
      margin: 5px 0 22px 0;
      border: none;
      background: #f1f1f1;
    } */
    
    /* When the inputs get focus, do something
    .form-container input[type=text]:focus, .form-container input[type=password]:focus {
      background-color: #ddd;
      outline: none;
    } */
    
    /* Set a style for the submit/login button */
    .form-container .btn {
      background-color: #04AA6D;
      color: white;
      padding: 16px 20px;
      border: none;
      cursor: pointer;
      width: 100%;
      margin-bottom:10px;
      opacity: 0.8;
    }
    
    /* Add a red background color to the cancel button */
    .form-container .cancel {
      background-color: red;
      width: 50px;
      font-size: 12px;
      height: 24px;
      padding-top: 2px;
      margin-top: 0px;
      margin-bottom: 0px;
      border-radius: 0px;
      margin-left: 235px;
      /* position: fixed; */
    }
    
    /* Add some hover effects to buttons */
    .form-container .btn:hover, .open-button:hover {
      opacity: 1;
    } 
     /* Remove scrollbar space */
      /* Optional: just make scrollbar invisible */
    /* ::-webkit-scrollbar {
    width: 0; 
    background: transparent; 
    } */
    .cancel_bg{
      background-color:rgb(1, 1, 100);
      width: 275px;
      height: 24px;
      position: fixed;
    }
    </style> 

<button class="open-button" onclick="openForm()">Active Users</button>

<div class="form-popup" id="myForm"  >
  <form  class="form-container" style="background-color: rgb(1, 1, 100); ">
    <table class="table" style=" font-size: 10px; background-color: rgb(1, 1, 100); color: white;">
      <thead >
          <tr >
            <button type="button" class="btn cancel" onclick="closeForm()">&times;</button>
              
          </tr>
      </thead>
      <tbody >
          <?php $__currentLoopData = $student_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr >
              <td><?php echo e($item_activity->name); ?></td>
              <td>
                  <?php echo e(Carbon\Carbon::parse($item_activity->last_seen)->diffForHumans()); ?>

              </td>

              <td>
                  <?php if(Cache::has('user-is-online-' . $item_activity->id)): ?>
                  <span class="text-success">Online</span>
                  
                  <?php else: ?>
                  <span class="text-secondary">Offline</span>
                  <?php endif; ?>
                  
              </td>
          </tr>
          
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <?php $__currentLoopData = $admin_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr >
              <td><?php echo e($item_activity->name); ?></td>
              <td>
                  <?php echo e(Carbon\Carbon::parse($item_activity->last_seen)->diffForHumans()); ?>

              </td>

              <td>
                  <?php if(Cache::has('admin-is-online-' . $item_activity->id)): ?>
                  <span class="text-success">Online</span>
                  
                  <?php else: ?>
                  <span class="text-secondary">Offline</span>
                  <?php endif; ?>
                  
              </td>
          </tr>
          
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>

  </table>
  
    
  </form>
</div>
<?php $__env->stopSection(); ?>








<?php echo $__env->make('layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Clearance-System\resources\views/admin/create-user.blade.php ENDPATH**/ ?>