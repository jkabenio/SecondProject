

<?php $__env->startSection('content'); ?>

<div class="clearance_body_admin">
    <div class="card" style="width:100%; border: 2px solid black">
        <div class="card-header">
            <h4> <b> Edit User </b>
                <a href="<?php echo e(url('/view-users')); ?>" class="btn btn-danger float-end">BACK</a>
            </h4>
        </div>
        <div class="card-body">

            <div class="mb-3">
                <label>Full Name</label>
                <p class="form-control">
                <?php echo e($user->name ?? 'None'); ?></p>
             </div>
               
             <div class="mb-3">
                <label>Email</label>
                <p class="form-control">
                <?php echo e($user->email ?? 'None'); ?></p>
            </div>

            <div class="mb-3">
                <label>School ID</label>
                <p class="form-control">
                <?php echo e($user->school_id ?? 'None'); ?></p>
            </div>
            
            <div class="mb-3">
                <label>Created At</label>
                <p class="form-control">
                <?php echo e($user->created_at ?? 'None'); ?></p>
            </div>

           
 
            

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Clearance-System\resources\views/admin/edit-user.blade.php ENDPATH**/ ?>