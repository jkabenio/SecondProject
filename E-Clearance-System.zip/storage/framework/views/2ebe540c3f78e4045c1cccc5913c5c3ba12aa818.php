

<?php $__env->startSection('content'); ?>
<style>
.restore:hover{
width: 36px;
height: 32px;
}
/* img{
width: 34px;
height: 34px; 
} */
.btn{
    width: 140px;
    color: white;
    text-align: left;
}
.no_button:hover {
    
    text-decoration: none;
    background-color: rgb(0, 216, 0);
}
.no_button{
    
    background-color: green;
}
.temporary_button:hover {
    color:#fff !important;
    text-decoration: none;
    background-color: rgb(255, 46, 46);
}
.temporary_button{
    margin-right: 10px;
    background-color: rgb(178, 1, 1);
}
.trash_view{
    padding-top: 39px;
}
</style>
    <div class="trash_view">
        <div class="card" style="width:100%; border: 2px solid black">
            <div class="card-header">
                <h4 style="text-align:center; font-weight: bold">Trashed List</h4>
            </div>
            <div class="card-body">
                <div class="container">
                    <div class="error">
                        <?php if(count($errors) > 0): ?>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="alert alert-danger" style="text-align: center">
                                    <?php echo e($error); ?>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                
                        <?php if(session('success')): ?>
                            <div class="alert alert-success" style="text-align: center">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>
                
                        <?php if(session('error')): ?>
                            <div class="alert alert-danger" style="text-align: center">
                                <?php echo e(session('error')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <table class="table table-bordered" style=" border: 1px solid black">
                    <div class="restore_all" align="left">
                    <a class="btn btn-primary" href="/admin/restore-all-department"><img src="<?php echo e(asset('/img/file.png')); ?>" alt="Italian Trulli">Restore all</a>
                    </div>
                   <thead >
                        <tr >   
                            <th>ID</th>
                            <th>Department Name</th>
                            <th>Created At</th>
                            <th>Updated At</th>
                            <th>Restore</th>
                            <th>Delete</th>
                        </tr>
                    </thead> 
                    <tbody >
                        <?php $__currentLoopData = $trashed_department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->id); ?></td>
                            <td><?php echo e($item->dept_name); ?></td>
                            <td><?php echo e($item->created_at); ?></td>
                            <td><?php echo e($item->updated_at); ?></td>                                 
                            <td>
                                <a href="<?php echo e(url ('admin/restore-department/'.$item->id)); ?>" ><img class="restore"  src="<?php echo e(asset('/img/recycle.png')); ?>" alt="Italian Trulli"></a>
                            </td>
                            <td>
                                <a href="<?php echo e(url ('admin/permanent-delete-department-from-trash/'.$item->id)); ?>" ><img class="edit" src="<?php echo e(asset('/img/delete.png')); ?>" alt="Italian Trulli"></a>
                            </td>
                             </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                
                <table class="table table-bordered" style="; border: 1px solid black">
                    <div class="restore_all" align="left">
                    <a class="btn btn-primary" href="/admin/restore-all-course"><img src="<?php echo e(asset('/img/file.png')); ?>" alt="Italian Trulli">Restore all</a>
                    </div>
                   <thead >
                    
                        <tr >  
                            <th>ID</th>
                            <th>Course Name</th>
                            <th>Created At</th>
                            <th>Updated At</th>
                            <th>Restore</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody >
                        <?php $__currentLoopData = $trashed_course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delete_course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($delete_course->id); ?></td>
                            <td><?php echo e($delete_course->course_name); ?></td>
                            <td><?php echo e($delete_course->created_at); ?></td>
                            <td><?php echo e($delete_course->updated_at); ?></td>                                
                            <td>
                                <a href="<?php echo e(url ('admin/restore-course/'.$delete_course->id)); ?>" ><img class="restore"  src="<?php echo e(asset('/img/recycle.png')); ?>" alt="Italian Trulli"></a>
                            </td>
                            <td>
                                <a href="<?php echo e(url ('admin/permanent-delete-course-from-trash/'.$delete_course->id)); ?>" ><img class="edit" src="<?php echo e(asset('/img/delete.png')); ?>" alt="Italian Trulli"></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                
                <table class="table table-bordered" style="border: 1px solid black">
                    <div class="restore_all" align="left">
                    <a class="btn btn-primary" href="/admin/restore-all-subject"><img src="<?php echo e(asset('/img/file.png')); ?>" alt="Italian Trulli">Restore all</a>
                    </div>
                   <thead >
                    
                        <tr >  
                            <th>ID</th>
                            <th>Subject Name</th>
                            <th>Created At</th>
                            <th>Updated At</th>
                            <th>Restore</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody >
                        <?php $__currentLoopData = $trashed_subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delete_subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($delete_subject->id); ?></td>
                            <td><?php echo e($delete_subject->subj_name); ?></td>
                            <td><?php echo e($delete_subject->created_at); ?></td>
                            <td><?php echo e($delete_subject->updated_at); ?></td>                                
                            <td>
                                <a href="<?php echo e(url ('admin/restore-subject/'.$delete_subject->id)); ?>" ><img class="restore"  src="<?php echo e(asset('/img/recycle.png')); ?>" alt="Italian Trulli"></a>
                            </td>
                            <td>
                                <a href="<?php echo e(url ('admin/permanent-delete-subject-from-trash/'.$delete_subject->id)); ?>" ><img class="edit" src="<?php echo e(asset('/img/delete.png')); ?>" alt="Italian Trulli"></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                
                <table class="table table-bordered" style=" border: 1px solid black">
                    <div class="restore_all" align="left">
                    <a class="btn btn-primary" href="/admin/restore-all-student"><img src="<?php echo e(asset('/img/file.png')); ?>" alt="Italian Trulli">Restore all</a>
                    </div>
                   <thead >
                    
                        <tr >  
                            <th>ID</th>
                            <th>Student Name</th>
                            <th>Created At</th>
                            <th>Updated At</th>
                            <th>Restore</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody >
                        <?php $__currentLoopData = $trashed_student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delete_student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($delete_student->id); ?></td>
                            <td><?php echo e($delete_student->name); ?></td> 
                            <td><?php echo e($delete_student->created_at); ?></td>
                            <td><?php echo e($delete_student->updated_at); ?></td>                               
                            <td>
                                <a href="<?php echo e(url ('admin/restore-student/'.$delete_student->id)); ?>" ><img class="restore"  src="<?php echo e(asset('/img/recycle.png')); ?>" alt="Italian Trulli"></a>
                            </td>
                            <td>
                                <a href="<?php echo e(url ('admin/permanent-delete-student-from-trash/'.$delete_student->id)); ?>" ><img class="edit" src="<?php echo e(asset('/img/delete.png')); ?>" alt="Italian Trulli"></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                
                <table class="table table-bordered" style=" border: 1px solid black">
                    <div class="restore_all" align="left">
                    <a class="btn btn-primary" href="/admin/restore-all-role"><img src="<?php echo e(asset('/img/file.png')); ?>" alt="Italian Trulli">Restore all</a>
                    </div>
                   <thead >
                    
                        <tr >  
                            <th>ID</th>
                            <th>Role</th>
                            <th>Created At</th>
                            <th>Updated At</th>
                            <th>Restore</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody >
                        <?php $__currentLoopData = $trashed_role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delete_role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($delete_role->id); ?></td>
                            <td><?php echo e($delete_role->role_name); ?></td>
                            <td><?php echo e($delete_role->created_at); ?></td>
                            <td><?php echo e($delete_role->updated_at); ?></td>                              
                            <td>
                                <a href="<?php echo e(url ('admin/restore-role/'.$delete_role->id)); ?>" ><img class="restore"  src="<?php echo e(asset('/img/recycle.png')); ?>" alt="Italian Trulli"></a>
                            </td>
                            <td>
                                <a href="<?php echo e(url ('admin/permanent-delete-role-from-trash/'.$delete_role->id)); ?>" ><img class="edit" src="<?php echo e(asset('/img/delete.png')); ?>" alt="Italian Trulli"></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                
                <table class="table table-bordered" style=" border: 1px solid black">
                    <div class="restore_all" align="left">
                    <a class="btn btn-primary" href="/admin/restore-all-signee"><img src="<?php echo e(asset('/img/file.png')); ?>" alt="Italian Trulli">Restore all</a>
                    </div>
                   <thead >
                    
                        <tr >  
                            <th>ID</th>
                            <th>Signee Name</th>
                            <th>Created At</th>
                            <th>Updated At</th>
                            <th>Restore</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody >
                        <?php $__currentLoopData = $trashed_signee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delete_signee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($delete_signee->id); ?></td>
                            <td><?php echo e($delete_signee->name); ?></td>
                            <td><?php echo e($delete_signee->created_at); ?></td>
                            <td><?php echo e($delete_signee->updated_at); ?></td>                               
                            <td>
                                <a href="<?php echo e(url ('admin/restore-signee/'.$delete_signee->id)); ?>" ><img class="restore" src="<?php echo e(asset('/img/recycle.png')); ?>" alt="Italian Trulli"></a>
                            </td>
                            <td>
                                <a href="<?php echo e(url ('admin/permanent-delete-signee-from-trash/'.$delete_signee->id)); ?>" ><img class="edit" src="<?php echo e(asset('/img/delete.png')); ?>" alt="Italian Trulli"></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>       
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Clearance-System\resources\views/admin/trash.blade.php ENDPATH**/ ?>