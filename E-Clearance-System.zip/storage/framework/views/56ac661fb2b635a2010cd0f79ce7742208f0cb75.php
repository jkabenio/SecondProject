<form <?php echo e($attributes->merge(['class'=>'card shadow'])); ?>>
    <div class="card-header p-1 bg-primary"></div>
    <div class="card-body">
        <?php echo e($slot); ?>

    </div>
</form><?php /**PATH C:\xampp\htdocs\E-Clearance-System\resources\views/components/form-card.blade.php ENDPATH**/ ?>