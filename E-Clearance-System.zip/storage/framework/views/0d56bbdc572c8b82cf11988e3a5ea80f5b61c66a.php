

<?php $__env->startSection('content'); ?>

<style>
.add_role_view{
padding-top: 39px;
}
.add_role_column{
    width:100%;
}
.input_role{
    margin-left: 300px;
    text-align: center; 
   }
.add_role_btn{
    margin-left: 570px;
    padding-top: 10px;
    padding-bottom: 10px;
   }
   .page-item.active .page-link{
    z-index: 1;
}
.form-control{
 background-color: #e9ecef;
}
</style>

<div class="add_role_view">
    <div class="card" style=" border: 2px solid black; ">      
        <div class="card-header" style="background-color: white">
                <div class="container">
                    <div class="error">
                        <?php if(count($errors) > 0): ?>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="alert alert-danger" style="text-align: center">
                                    <?php echo e($error); ?>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                
                        <?php if(session('success')): ?>
                            <div class="alert alert-success" style="text-align: center">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>
                
                        <?php if(session('error')): ?>
                            <div class="alert alert-danger" style="text-align: center">
                                <?php echo e(session('error')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>
<div class="add_role_row">
    <div class="add_role_column" style=" border: 3px solid black ">
        <h3 style="color:blue; text-align: center; font-weight: bold">Add New Role</h3>
        <div class="card-body" style="padding: 0px; margin: 0px; font-size: 12px" >
            <?php echo Form::open(['action' => 'App\Http\Controllers\Admin\AdminController@store_role', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                <?php echo e(csrf_field()); ?>


                    <label style="color: black;margin-left: 570px;">Role Name</label>
                    <div class="col-md-6">
                        <input  type="text" class="form-control input_role <?php $__errorArgs = ['role_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="role_name" value="<?php echo e(old('role_name')); ?>" required>
                        <?php $__errorArgs = ['role_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                <div class="add_role_btn">
                    <input type="submit" class="btn btn-primary"/>
                </div>
            
            <?php echo Form::close(); ?>

                </div>
        </div>
    </div>

    <div class="add_role_column" style="background-color:rgb(224, 224, 225);">
        <h3 style="color:blue; text-align: center">Activity Logs</h3>
        <table class="table table-bordered" style=" border: 1px solid black; font-size: 12px;">
            <thead >
                <tr > 
                    <th>Role Name</th>
                    <th>Date Created</th>
                    <th>Date Updated</th>
                    <th>Date Deleted</th>
                </tr>
            </thead>
            <tbody >
                <?php $__currentLoopData = $role_log; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr  >
                    
                    <td><?php echo e($item->role_name); ?></td>
                    <td><?php echo e(date('M,d,D,Y,g:i A',strtotime($item->created_at))); ?></td>
                    <td><?php echo e(date('M,d,D,Y,g:i A',strtotime($item->updated_at))); ?></td>
                    <td><?php echo e(date('M,d,D,Y,g:i A',strtotime($item->deleted_at))); ?></td>
                    
                </tr>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>        
        </table>                   
        <?php echo e($role_log->links()); ?> 
    </div>
</div>
</div>
</div>
<?php echo $__env->make('admin.user-activity', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Clearance-System\resources\views/admin/add-role.blade.php ENDPATH**/ ?>