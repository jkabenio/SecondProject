





<?php if(Auth::user()->role_as!='0'): ?>
<div class="w3-sidebar w3-bar-block w3-card w3-animate-left" style="display:block" id="leftMenu">
  <button onclick="closeLeftMenu()" class="w3-bar-item w3-button w3-large">Close Menu &nbsp;&times;</button>
  <hr>
 <!-- Authentication Links -->
  <?php if(auth()->guard()->guest()): ?>
    <?php if(Route::has('login')): ?>
      <button class="login_style"><a  href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a></button>
    <?php endif; ?>
    <br>
    <?php if(Route::has('register')): ?>
      <button class="login_style"><a  href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a></button>
    <?php endif; ?>
    <?php else: ?>
      <a>
        <a id="navbarDropdown" class="nav-link w3-bar-item w3-button dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
          <?php echo e(Auth::user()->name); ?>

        </a>

        <div class="dropdown-menu  dropdown-menu-end" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
            onclick="event.preventDefault();
            document.getElementById('logout-form').submit();">
            <?php echo e(__('Logout')); ?>

          </a>

          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
            <?php echo csrf_field(); ?>
          </form>
        </div>
      </a>
  <?php endif; ?>
  
  <?php if(Auth::user()->role_as=='1'): ?>
    <a href="/admindashboard" class="w3-bar-item w3-button">DashBoard</a>
  <?php endif; ?>
  <?php if(Auth::user()->role_as=='2'): ?>
    <a href="/instructordashboard" class="w3-bar-item w3-button">Instructor Clearance Form</a>
  <?php endif; ?>

  <a href="#" class="w3-bar-item w3-button">Request</a>
  <a href="#" class="w3-bar-item w3-button">Student List</a>
  <button class="dropdown-btn w3-bar-item w3-button">Departments
    <i class="fa fa-caret-down"></i>
  </button>
  <div class="dropdown-container ">
    <a class="a_link" href="#">BSIT</a>
    <a class="a_link" href="#">Link 2</a>
    <a class="a_link" href="#">Link 3</a>
  </div>
  <button class="dropdown-btn w3-bar-item w3-button">Courses
    <i class="fa fa-caret-down"></i>
  </button>
  <div class="dropdown-container">
    <a class="a_link" href="#">BSCS</a>
    <a class="a_link" href="#">Link 2</a>
    <a class="a_link" href="#">Link 3</a>
  </div>

  <?php if(Auth::user()->role_as=='1'): ?>
    
      <a href="/view-users" class="w3-bar-item w3-button">Users</a>
      <a href="/create-users" class="w3-bar-item w3-button">Create Users</a>
  <?php endif; ?>
</div>

<div>
  <button class="w3-button w3-darkblue w3-xlarge w3-left" onclick="openLeftMenu()">&#9776;</button>

</div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\E-Clearance-System\resources\views/inc/sidebar.blade.php ENDPATH**/ ?>