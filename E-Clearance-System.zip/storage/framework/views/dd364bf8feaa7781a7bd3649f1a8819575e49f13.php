

<?php $__env->startSection('content'); ?>
 <style>
* {
    box-sizing: border-box;
}

/* Create three equal columns that floats next to each other */
.column {
    float: left !important;
    width: 20%;
}

/* Clear floats after the columns */
.clearance_row:after {
    content: "";
    display: table;
    clear: both;
}
.clearance_row{
    width:100%;
    

}
.clearance_row{
    border: 1px solid;
    width:100%;
}
.table_content{
    white-space: nowrap; 
    width: 100%; 
    overflow: hidden;
    text-overflow: clip; 
}
.edit_student_view{
    padding-top: 39px;
}
</style>

<script> 
    var expanded = false;
    function showCheckboxes() {
      var checkboxes = document.getElementById("checkboxes");
      if (!expanded) {
        checkboxes.style.display = "block";
        expanded = true;
      } else {
        checkboxes.style.display = "none"; 
        expanded = false;
      }
      
    }
</script>

<script> 
    var expanded = false;
    function showselectedCheckboxes() {
      var selectedcheckboxes = document.getElementById("selectedcheckboxes");
      if (!expanded) {
        selectedcheckboxes.style.display = "block";
        expanded = true;
      } else {
        selectedcheckboxes.style.display = "none"; 
        expanded = false;
      }
      
    }
    </script>

<script type="text/javascript">
    $(document).ready(function(){
        
        $(document).on('change','.courselist',function(){
            // console.log("hmm nag bago na");

            var course_id=$(this).val();
            // console.log(course_id);
            var div=$(this).parent();
            var op=" ";
            $.ajax({
                type:'get',
                url:'<?php echo URL::to('/admin/FindSubjectName'); ?>',
                data:{'id':course_id},
                success:function(data){
                    // console.log('success');

                    // console.log(data);

                    // console.log(data.length);
                    op+='<label><option  value="0" selected disabled>Select subjects</option></label>';
                    for(var i=0;i<data.length;i++){
                        op+='<label><input type="checkbox" name="subjects[]" value="'+data[i].subj_name+'"><b>'+data[i].subj_name+'</b><br><input type="text" readonly="readonly" name="student_section[]" value="'+data[i].section+'"><input type="text" readonly="readonly" name="student_signee_names[]" value="'+data[i].signee_names+'"><input type="text" readonly="readonly" name="description[]" value="None"><input type="text" readonly="readonly" name="status[]" value="In-progress"></label>';
                    }
                    div.find('.subjectlist').html("");
                    div.find('.subjectlist').append(op);
                },
                error:function(){

                }
            });
        });
    });
</script>
<style>
.form-popup {
    display: none;
    position: fixed;
    bottom: 300px;
    right: 250px;
    border: 3px solid #0800ff;
    z-index: 9;
    background-color: rgb(212, 212, 212);
    width: 500px;
    margin-bottom: auto;
  }
  
  /* Add styles to the form container */
  .form-container-activity { 
margin: auto !important;
width: 300px !important;
height: 300px !important;
overflow: auto !important;
  /* way to prevent an element from scrolling its parent. */
overscroll-behavior: contain;
  }
  
  /* Set a style for the submit/login button */
  .form-container-activity .btn_cancel {
    background-color: #04AA6D;
    color: white;
    padding: 16px 20px;
    border: none;
    cursor: pointer;
    width: 100%;
    margin-bottom:10px;
    opacity: 0.8;
  }
  
  /* Add a red background color to the cancel button */
  .form-container-activity .cancel {
    background-color: red;
    width: 50px;
    font-size: 12px;
    height: 24px;
    padding-top: 2px;
    margin-top: 0px;
    margin-bottom: 0px;
    border-radius: 0px;
    margin-left: 250px;
    /* position: fixed; */
  }
  
  /* Add some hover effects to buttons */
  .form-container-activity .btn_cancel:hover, .open-button:hover {
    opacity: 1;
  } 
   /* Remove scrollbar space */
    /* Optional: just make scrollbar invisible */
  ::-webkit-scrollbar {
  width: 0; 
  background: transparent; 
  }
  .btn.cancel{
   
    background-color: red;
    color: white;

  }
  .description_info{
    height: 155px;
    width: 490px;
  }

  select[readonly]
{
    pointer-events: none;
}
/* irrelevent styling */
*[readonly]
{

}

.edit_student_column{
    width: 50%;
    float: left;
    padding: 5px;
}
.form-control{
 background-color: #e9ecef;
}
.edit_user_label{
font-weight: bold;
margin-left: 250px;
}
.edit_student_column_header{
    font-weight: bold;
}
</style>

<?php
$total_count = 0;
$status_count = 0;
foreach ($student_id->status as $status_list) { 
    if($status_list !== "APPROVED"){
        $status_count--;
    }
    if($status_list == "APPROVED"){
        $status_count++;
    }
    $total_count++;
}

?>
<div class="edit_student_view">
    <div class="card" style="width:100%; border: 2px solid black;">
        <div class="card-header">
            <div class="error">
                <?php if(count($errors) > 0): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger" style="text-align: center;">
                            <?php echo e($error); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
        
                <?php if(session('success')): ?>
                    <div class="alert alert-success" style="text-align: center;">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
        
                <?php if(session('error')): ?>
                    <div class="alert alert-danger" style="text-align: center;">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <h4 style="text-align:center;font-weight: bold;"> <b> Edit User </b>
                <a href="<?php echo e(url('/admin/view-student-user')); ?>" class="btn btn-danger float-end">BACK</a>
            </h4>
        </div>
        
        <?php echo Form::open(['action' => ['App\Http\Controllers\Admin\AdminController@update_student',$student_id->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

        <div class="card-body">
            <?php echo csrf_field(); ?> 
            <?php echo method_field('PUT'); ?>
           
            <div class="edit_student_column">
                <label  class="edit_user_label">Student Name <span style="font-weight: normal; font-size: 10px">(Editable)</span></label>
                <input style="text-align: center" type="text" name="name" value="<?php echo e($student_id->name); ?>" class="form-control">
            </div>
            <div class="edit_student_column">
                <label class="edit_user_label">Student Email<span style="font-weight: normal; font-size: 10px">(Editable) </span></label>
                <input style="text-align: center" type="text" name="email" value="<?php echo e($student_id->email); ?>" class="form-control">
            </div>

            <div class="edit_student_column">
                <label class="edit_user_label">Student School ID<span style="font-weight: normal; font-size: 10px">(Editable) </span></label>
                <input style="text-align: center" name="school_id" type="text" value="<?php echo e($student_id->school_id); ?>" class="form-control">
            </div> 

            <div class="edit_student_column">
                <label class="edit_user_label">Department <span style="font-weight: normal; font-size: 10px">(Editable) </span></label>
                <select style="text-align: center" name="dept_id" class="form-control">
                    <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($student_id->dept_id == $list->id): ?>
                            <option value=<?php echo e($student_id->dept_id); ?>><?php echo e($list->dept_name); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($student_id->dept_id !== $list->id): ?>
                        <option value="<?php echo e($list->id); ?>"><?php echo e($list->dept_name); ?></option>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>  
            </div>


            <div class="edit_student_column">
                <label class="edit_user_label">Course <span style="font-weight: normal; font-size: 10px">(Editable) </span></label>
                <select style="text-align: center" name="course" class="form-control">
                    <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($list->id == $student_id->course): ?>
                            <option value="<?php echo e($list->id); ?>"><?php echo e($list->course_name); ?></option>
                        <?php endif; ?>
                        <?php if($list->id !== $student_id->course): ?>
                            <option  value="<?php echo e($list->id); ?>"><?php echo e($list->course_name); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            

            <div class="edit_student_column">
                <label class="edit_user_label">Year Level <span style="font-weight: normal; font-size: 10px">(Editable) </span></label>
                <select style="text-align: center" name="year_lvl" class="form-control">
                    <option value="<?php echo e($student_id->year_lvl); ?>"><?php echo e($student_id->year_lvl); ?></option>
                    <?php if($student_id->year_lvl !== "1st Year"): ?>
                        <option value="1st Year">1st Year</option>
                    <?php endif; ?>
                    <?php if($student_id->year_lvl !== "2nd Year Year"): ?>
                        <option value="2nd Year">2nd Year</option>
                    <?php endif; ?>
                    <?php if($student_id->year_lvl !== "3rd Year"): ?>
                        <option value="3rd Year">3rd Year</option>
                    <?php endif; ?>
                    <?php if($student_id->year_lvl !== "4th Year"): ?>
                        <option value="4th Year">4th Year</option>
                    <?php endif; ?>
                </select> 
            </div>

            <div class="edit_student_column">
                <label class="edit_user_label">Semester <span style="font-weight: normal; font-size: 10px">(Editable) </span></label>
                <select style="text-align: center" name="semester" class="form-control">
                    <option value="<?php echo e($student_id->semester); ?>"><?php echo e($student_id->semester); ?></option>
                    <?php if($student_id->semester !== "1st semester"): ?>
                        <option value="1st semester">1st semester</option>
                    <?php endif; ?>
                    <?php if($student_id->semester !== "2nd semester"): ?>
                        <option value="2nd semester">2nd semester</option>
                    <?php endif; ?>
                    <?php if($student_id->semester !== "summer class"): ?>
                        <option value="summer class">summer class</option>
                    <?php endif; ?>
                </select>
            </div>

            
            
            <div class="edit_student_column">
                <label class="edit_user_label">Enrolled Subjects</label>
                
                    
                    <?php $__currentLoopData = $student_id->subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                    <input style="text-align: center; width: 50%; float: left" type="text" readonly class="form-control" value="<?php echo e($subject_list); ?>"/>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
        <div class="clearance_row">
            <div class="column">
                <h5 class="edit_student_column_header" style="border: 1px solid black; text-align:center; height:50px">Instructor</h5>
                <?php $__currentLoopData = $student_id->student_signee_names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $signee_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                    <p class="table_content" style="border: 1px solid black"><?php echo e($signee_list); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="column" >
                <h5 class="edit_student_column_header" style="border: 1px solid black; text-align:center; height:50px">Subject</h5>
                <?php $__currentLoopData = $student_id->subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                    <p class="table_content" style="border: 1px solid black"><?php echo e($subject_list); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="column" >
                <h5 class="edit_student_column_header" style="border: 1px solid black; text-align:center; height:50px">Section</h5>
                <?php $__currentLoopData = $student_id->student_section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                    <p class="table_content" style="border: 1px solid black; text-align:center;"><?php echo e($section_list); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="column" >
                <h5 class="edit_student_column_header" style="border: 1px solid black; text-align:center; height:50px">Status</h5>
                <?php $__currentLoopData = $student_id->status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                    <p class="table_content" style="border: 1px solid black; text-align:center;">
                        <?php if($status_list == "IN-PROGRESS"): ?>
                        <select  readonly tabindex="-1" style="color:blue; padding: 0px; margin: 0px;font-size: 14px;">
                        <?php endif; ?>
                        <?php if($status_list == "COMPLY"): ?>
                        <select  readonly tabindex="-1" style="color:orange; padding: 0px; margin: 0px;font-size: 14px;">
                        <?php endif; ?>
                        <?php if($status_list == "REJECTED"): ?>
                        <select readonly tabindex="-1" style="color:red; padding: 0px; margin: 0px;font-size: 14px;">
                        <?php endif; ?>
                        <?php if($status_list == "APPROVED"): ?>
                        <select  readonly tabindex="-1" style="color:green; padding: 0px; margin: 0px;font-size: 14px;">
                        <?php endif; ?>
                        <option style="border: 1px solid black; text-align:center" value="<?php echo e($status_list); ?>"><?php echo e($status_list); ?></option>
                        

                        <?php if($status_list !== "IN-PROGRESS"): ?>
                        <option style="border: 1px solid black; text-align:center; color: blue"value="IN-PROGRESS">IN-PROGRESS</option>
                        <?php endif; ?>
                        <?php if($status_list !== "COMPLY"): ?>
                        <option style="border: 1px solid black; text-align:center; color: orange"value="COMPLY">COMPLY</option>
                        <?php endif; ?>
                        <?php if($status_list !== "APPROVED"): ?>
                        <option style="border: 1px solid black; text-align:center; color:green;"value="APPROVED">APPROVED</option>
                        <?php endif; ?>
                        <?php if($status_list !== "REJECTED"): ?>
                        <option style="border: 1px solid black; text-align:center; color:red"value="REJECTED">REJECTED</option>
                        <?php endif; ?>
                        </select>
                    </p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="column" > 
                <h5 class="edit_student_column_header" style="border:1px solid black; text-align:center; height:50px">Description</h5>
                <?php $__currentLoopData = $student_id->description; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $description_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($description_list !== null): ?>  
                        <p class="table_content" style="border: 1px solid black; text-align:center;"><a onclick="opensigneeForm(<?php echo e($index); ?>)">View Detail</a></p>
                    <?php endif; ?>
                    <?php if($description_list == null): ?>  
                    <p class="table_content" style="border: 1px solid black; text-align:center;"><a value="<?php echo e($description_list); ?>" onclick="opensigneeForm(<?php echo e($index); ?>)">Add Detail</a></p>
                    <?php endif; ?>
                    <div class="form-popup" id="signeeForm<?php echo e($index); ?>">
                            <textarea class="description_info" value="<?php echo e($description_list); ?>"><?php echo e($description_list); ?></textarea>
                          <button type="button" class="btn cancel" onclick="closesigneeForm(<?php echo e($index); ?>)">Close</button>
                      </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="clearance_row">
            <div class="column">
                <h5 class="edit_student_column_header" style="border: 1px solid black; text-align:center; height:50px">Guidance Councilor</h5>
                    <p class="table_content" style="border: 1px solid black; text-align:center">
                        <?php if($student_id->guidance_councilor == "IN-PROGRESS"): ?>
                        <select readonly tabindex="-1" name="guidance_councilor" style="color:blue">
                        <?php endif; ?>
                        <?php if($student_id->guidance_councilor == "COMPLY"): ?>
                        <select readonly tabindex="-1" name="guidance_councilor" style="color:orange">
                        <?php endif; ?>
                        <?php if($student_id->guidance_councilor == "REJECTED"): ?>
                        <select readonly tabindex="-1" name="guidance_councilor" style="color:red">
                        <?php endif; ?>
                        <?php if($student_id->guidance_councilor == "APPROVED"): ?>
                        <select readonly tabindex="-1" name="guidance_councilor" style="color:green">
                        <?php endif; ?>
                        <option style="border: 1px solid black; text-align:center" value="<?php echo e($student_id->guidance_councilor); ?>"><?php echo e($student_id->guidance_councilor); ?></option>
                        
                        
                        <?php if($student_id->guidance_councilor !== "IN-PROGRESS"): ?>
                        <option style="border: 1px solid black; text-align:center; color: blue"value="IN-PROGRESS">IN-PROGRESS</option>
                        <?php endif; ?>
                        <?php if($student_id->guidance_councilor !== "COMPLY"): ?>
                        <option style="border: 1px solid black; text-align:center; color: orange"value="COMPLY">COMPLY</option>
                        <?php endif; ?>
                        <?php if($student_id->guidance_councilor !== "APPROVED"): ?>
                        <option style="border: 1px solid black; text-align:center; color:green;"value="APPROVED">APPROVED</option>
                        <?php endif; ?>
                        <?php if($student_id->guidance_councilor !== "REJECTED"): ?>
                        <option style="border: 1px solid black; text-align:center; color:red"value="REJECTED">REJECTED</option>
                        <?php endif; ?>
                        </select>
                    </p>
                    <?php if(($student_id->guidance_councilor == "REJECTED" || $student_id->guidance_councilor == "COMPLY") && ($student_id->guidance_councilor_description !== null || $student_id->guidance_councilor_description == null)): ?>  
                        <p class="table_content" style="border: 1px solid black; text-align:center;"><a onclick="open_guidance_councilor_Form()">View Detail</a></p>
                    <?php endif; ?>
                    <?php if(($student_id->guidance_councilor_description == null || $student_id->guidance_councilor_description !== null) && ($student_id->guidance_councilor == "IN-PROGRESS")): ?>  
                        <p class="table_content" style="border: 1px solid black; text-align:center;"><a onclick="open_guidance_councilor_Form()">Add Detail</a></p>
                    <?php endif; ?>
                    <div class="form-popup" id="guidance_councilor_form">
                        <textarea class="description_info" name="guidance_councilor_description" value="<?php echo e($student_id->guidance_councilor_description); ?>"><?php echo e($student_id->guidance_councilor_description); ?></textarea>
                        <button type="button" class="btn cancel" onclick="close_guidance_councilor_Form()">Close</button>  
                    </div>
            </div>
                
            <div class="column" >
                <h5 class="edit_student_column_header" style="border: 1px solid black; text-align:center; height:50px">Student Org. Treasurer</h5>
                    <p class="table_content" style="border: 1px solid black; text-align:center">
                        <?php if($student_id->student_org_treasurer == "IN-PROGRESS"): ?>
                        <select readonly tabindex="-1" name="student_org_treasurer" style="color:blue">
                        <?php endif; ?>
                        <?php if($student_id->student_org_treasurer == "COMPLY"): ?>
                            <select readonly tabindex="-1" name="student_org_treasurer" style="color:orange">
                        <?php endif; ?>
                        <?php if($student_id->student_org_treasurer == "REJECTED"): ?>
                            <select readonly tabindex="-1" name="student_org_treasurer" style="color:red">
                        <?php endif; ?>
                        <?php if($student_id->student_org_treasurer == "APPROVED"): ?>
                            <select readonly tabindex="-1" name="student_org_treasurer" style="color:green">
                        <?php endif; ?>


                            <option style="border: 1px solid black; text-align:center" value="<?php echo e($student_id->student_org_treasurer); ?>"><?php echo e($student_id->student_org_treasurer); ?></option>


                        <?php if($student_id->student_org_treasurer !== "IN-PROGRESS"): ?>
                            <option style="border: 1px solid black; text-align:center; color: blue"value="IN-PROGRESS">IN-PROGRESS</option>
                        <?php endif; ?>
                        <?php if($student_id->student_org_treasurer !== "COMPLY"): ?>
                            <option style="border: 1px solid black; text-align:center; color: orange"value="COMPLY">COMPLY</option>
                        <?php endif; ?>
                        <?php if($student_id->student_org_treasurer !== "APPROVED"): ?>
                            <option style="border: 1px solid black; text-align:center; color:green;"value="APPROVED">APPROVED</option>
                        <?php endif; ?>
                        <?php if($student_id->student_org_treasurer !== "REJECTED"): ?>
                            <option style="border: 1px solid black; text-align:center; color:red"value="REJECTED">REJECTED</option>
                        <?php endif; ?>
                        </select>
                    </p>
                    <?php if(($student_id->student_org_treasurer == "REJECTED" || $student_id->student_org_treasurer == "COMPLY") && ($student_id->student_org_description == null || $student_id->student_org_description !== null)): ?>  
                        <p class="table_content" style="border: 1px solid black; text-align:center;"><a onclick="open_treasurer_Form()">View Detail</a></p>
                    <?php endif; ?>
                    <?php if(($student_id->student_org_description == null || $student_id->student_org_description !== null) && ($student_id->student_org_treasurer == "IN-PROGRESS")): ?>  
                        <p class="table_content" style="border: 1px solid black; text-align:center;"><a onclick="open_treasurer_Form()">Add Detail</a></p>
                    <?php endif; ?>
                    <div class="form-popup" id="student_org">
                            <textarea class="description_info" name="student_org_description" value="<?php echo e($student_id->student_org_description); ?>"><?php echo e($student_id->student_org_description); ?></textarea>
                            <button type="button" class="btn cancel" onclick="close_treasurer_Form()">Close</button>
                    </div>
            </div>
        
            <div class="column" >
                <h5 class="edit_student_column_header" style="border: 1px solid black; text-align:center; height:50px">Librarian</h5>
                    <p class="table_content" style="border: 1px solid black; text-align:center">
                        <?php if($student_id->librarian == "IN-PROGRESS"): ?>
                            <select readonly tabindex="-1" name="librarian" style="color:blue" >
                        <?php endif; ?>
                        <?php if($student_id->librarian == "COMPLY"): ?>
                            <select readonly tabindex="-1" name="librarian" style="color:orange">
                        <?php endif; ?>
                        <?php if($student_id->librarian == "REJECTED"): ?>
                            <select readonly tabindex="-1" name="librarian" style="color:red">
                        <?php endif; ?>
                        <?php if($student_id->librarian == "APPROVED"): ?>
                            <select readonly tabindex="-1" name="librarian" style="color:green">
                        <?php endif; ?> 
                        

                            <option style="border: 1px solid black; text-align:center" value="<?php echo e($student_id->librarian); ?>"><?php echo e($student_id->librarian); ?></option>


                        <?php if($student_id->librarian !== "IN-PROGRESS"): ?>
                            <option style="border: 1px solid black; text-align:center; color: blue"value="IN-PROGRESS">IN-PROGRESS</option>
                        <?php endif; ?>
                        <?php if($student_id->librarian !== "COMPLY"): ?>
                            <option style="border: 1px solid black; text-align:center; color: orange"value="COMPLY">COMPLY</option>
                        <?php endif; ?>
                        <?php if($student_id->librarian !== "APPROVED"): ?>
                            <option style="border: 1px solid black; text-align:center; color:green;"value="APPROVED">APPROVED</option>
                        <?php endif; ?>
                        <?php if($student_id->librarian !== "REJECTED"): ?>
                            <option style="border: 1px solid black; text-align:center; color:red"value="REJECTED">REJECTED</option>
                        <?php endif; ?>
                    </select>
                    </p>
                    <?php if(($student_id->librarian == "REJECTED" || $student_id->librarian == "COMPLY") && ($student_id->librarian_description !== null || $student_id->librarian_description == null)): ?>  
                        <p class="table_content" style="border: 1px solid black; text-align:center;"><a onclick="open_librarian_Form()">View Detail</a></p>
                    <?php endif; ?>
                    <?php if(($student_id->librarian_description == null || $student_id->librarian_description !== null) && ($student_id->librarian == "IN-PROGRESS")): ?>  
                        <p class="table_content" style="border: 1px solid black; text-align:center;"><a onclick="open_librarian_Form()">Add Detail</a></p>
                    <?php endif; ?>
                    <div class="form-popup" id="librarian_form">
                        <textarea class="description_info" name="librarian_description" value="<?php echo e($student_id->librarian_description); ?>"><?php echo e($student_id->librarian_description); ?></textarea>
                        <button type="button" class="btn cancel" onclick="close_librarian_Form()">Close</button>  
                    </div>
            </div>
            <div class="column" >
                <h5 class="edit_student_column_header" style="border: 1px solid black; text-align:center; height:50px">Dean of Student Affair</h5>
                    <p class="table_content" style="border: 1px solid black; text-align:center">
                        <?php if($student_id->dean_of_student_affair == "IN-PROGRESS"): ?>
                        <select readonly tabindex="-1" name="dean_of_student_affair" style="color:blue">
                        <?php endif; ?>
                        <?php if($student_id->dean_of_student_affair == "COMPLY"): ?>
                        <select readonly tabindex="-1" name="dean_of_student_affair" style="color:orange">
                        <?php endif; ?>
                        <?php if($student_id->dean_of_student_affair == "REJECTED"): ?>
                        <select readonly tabindex="-1" name="dean_of_student_affair" style="color:red">
                        <?php endif; ?>
                        <?php if($student_id->dean_of_student_affair == "APPROVED"): ?>
                        <select readonly tabindex="-1" name="dean_of_student_affair" style="color:green">
                        <?php endif; ?>
                        <option style="border: 1px solid black; text-align:center" value="<?php echo e($student_id->dean_of_student_affair); ?>"><?php echo e($student_id->dean_of_student_affair); ?></option>
                    
                        
                        <?php if($student_id->dean_of_student_affair !== "IN-PROGRESS"): ?>
                        <option style="border: 1px solid black; text-align:center; color: blue"value="IN-PROGRESS">IN-PROGRESS</option>
                        <?php endif; ?>
                        <?php if($student_id->dean_of_student_affair !== "COMPLY"): ?>
                        <option style="border: 1px solid black; text-align:center; color: orange"value="COMPLY">COMPLY</option>
                        <?php endif; ?>
                        <?php if($student_id->dean_of_student_affair !== "APPROVED"): ?>
                        <option style="border: 1px solid black; text-align:center; color:green;"value="APPROVED">APPROVED</option>
                        <?php endif; ?>
                        <?php if($student_id->dean_of_student_affair !== "REJECTED"): ?>
                        <option style="border: 1px solid black; text-align:center; color:red"value="REJECTED">REJECTED</option>
                        <?php endif; ?>
                        </select>
                    </p>
                    <?php if(($student_id->dean_of_student_affair == "REJECTED" || $student_id->dean_of_student_affair == "COMPLY") && ($student_id->dean_of_student_affair_description !== null || $student_id->dean_of_student_affair_description == null)): ?> 
                        <p class="table_content" style="border: 1px solid black; text-align:center;"><a onclick="open_studentaffair_Form()">View Detail</a></p>
                    <?php endif; ?>
                    <?php if(($student_id->dean_of_student_affair_description == null || $student_id->dean_of_student_affair_description !== null) && ($student_id->dean_of_student_affair == "IN-PROGRESS")): ?>  
                        <p class="table_content" style="border: 1px solid black; text-align:center;"><a onclick="open_studentaffair_Form()">Add Detail</a></p>
                    <?php endif; ?>
                        <div class="form-popup" id="studentaffair_form">
                        <textarea class="description_info" name="dean_of_student_affair_description" value="<?php echo e($student_id->dean_of_student_affair_description); ?>"><?php echo e($student_id->dean_of_student_affair_description); ?></textarea>
                        <button type="button" class="btn cancel" onclick="close_studentaffair_Form()">Close</button>  
                    </div>
            </div>
            <div class="column" >
                <h5 class="edit_student_column_header" style="border: 1px solid black; text-align:center; height:50px">Dean Principal</h5>
                    <p class="table_content" style="border: 1px solid black; text-align:center">
                        <?php if($student_id->dean_principal == "IN-PROGRESS"): ?>
                        <select readonly tabindex="-1" name="dean_principal" style="color:blue">
                        <?php endif; ?>
                        <?php if($student_id->dean_principal == "COMPLY"): ?>
                        <select readonly tabindex="-1" name="dean_principal" style="color:orange">
                        <?php endif; ?>
                        <?php if($student_id->dean_principal == "REJECTED"): ?>
                        <select readonly tabindex="-1" name="dean_principal" style="color:red">
                        <?php endif; ?>
                        <?php if($student_id->dean_principal == "APPROVED"): ?>
                        <select readonly tabindex="-1" name="dean_principal" style="color:green">
                        <?php endif; ?>
                        <option style="border: 1px solid black; text-align:center" value="<?php echo e($student_id->dean_principal); ?>"><?php echo e($student_id->dean_principal); ?></option>
                    
                        
                        <?php if($student_id->dean_principal !== "IN-PROGRESS"): ?>
                        <option style="border: 1px solid black; text-align:center; color: blue"value="IN-PROGRESS">IN-PROGRESS</option>
                        <?php endif; ?>
                        <?php if($student_id->dean_principal !== "COMPLY"): ?>
                        <option style="border: 1px solid black; text-align:center; color: orange"value="COMPLY">COMPLY</option>
                        <?php endif; ?>
                        <?php if($student_id->dean_principal !== "APPROVED"): ?>
                        <option style="border: 1px solid black; text-align:center; color:green;"value="APPROVED">APPROVED</option>
                        <?php endif; ?>
                        <?php if($student_id->dean_principal !== "REJECTED"): ?>
                        <option style="border: 1px solid black; text-align:center; color:red"value="REJECTED">REJECTED</option>
                        <?php endif; ?>
                        </select> 
                    </p>
                    <?php if(($student_id->dean_principal == "REJECTED" || $student_id->dean_principal == "COMPLY") && ($student_id->dean_principal_description !== null || $student_id->dean_principal_description == null)): ?> 
                    <p class="table_content" style="border: 1px solid black; text-align:center;"><a onclick="open_deanprincipal_Form()">View Detail</a></p>
                    <?php endif; ?>
                    <?php if(($student_id->dean_principal_description == null || $student_id->dean_principal_description !== null) && ($student_id->dean_principal == "IN-PROGRESS")): ?>  
                        <p class="table_content" style="border: 1px solid black; text-align:center;"><a onclick="open_deanprincipal_Form()">Add Detail</a></p>
                    <?php endif; ?>
                    <div class="form-popup" id="deanprincipal_form">
                    <textarea class="description_info" name="dean_principal_description" value="<?php echo e($student_id->dean_principal_description); ?>"><?php echo e($student_id->dean_principal_description); ?></textarea>
                    <button type="button" class="btn cancel" onclick="close_deanprincipal_Form()">Close</button>  
                </div>
            </div>
            <div class="column" >
                <h5 class="edit_student_column_header" style="border: 1px solid black; text-align:center; height:50px">Registrar</h5>
                    <p class="table_content" style="border: 1px solid black; text-align:center">
                        <?php if($student_id->registrar == "IN-PROGRESS"): ?>
                        <select readonly tabindex="-1" name="registrar" style="color:blue">
                        <?php endif; ?>
                        <?php if($student_id->registrar == "COMPLY"): ?>
                        <select readonly tabindex="-1" name="registrar" style="color:orange">
                        <?php endif; ?>
                        <?php if($student_id->registrar == "REJECTED"): ?>
                        <select readonly tabindex="-1" name="registrar" style="color:red">
                        <?php endif; ?>
                        <?php if($student_id->registrar == "APPROVED"): ?>
                        <select readonly tabindex="-1" name="registrar" style="color:green">
                        <?php endif; ?>
                        <option style="border: 1px solid black; text-align:center" value="<?php echo e($student_id->registrar); ?>"><?php echo e($student_id->registrar); ?></option>
                    
                        
                        <?php if($student_id->registrar !== "IN-PROGRESS"): ?>
                        <option style="border: 1px solid black; text-align:center; color: blue"value="IN-PROGRESS">IN-PROGRESS</option>
                        <?php endif; ?>
                        <?php if($student_id->registrar !== "COMPLY"): ?>
                        <option style="border: 1px solid black; text-align:center; color: orange"value="COMPLY">COMPLY</option>
                        <?php endif; ?>
                        <?php if($student_id->registrar !== "APPROVED"): ?>
                        <option style="border: 1px solid black; text-align:center; color:green;"value="APPROVED">APPROVED</option>
                        <?php endif; ?>
                        <?php if($student_id->registrar !== "REJECTED"): ?>
                        <option style="border: 1px solid black; text-align:center; color:red"value="REJECTED">REJECTED</option>
                        <?php endif; ?>
                        </select>
                    </p>
                    <?php if(($student_id->registrar == "REJECTED" || $student_id->registrar == "COMPLY") && ($student_id->registrar_description !== null || $student_id->registrar_description == null)): ?> 
                        <p class="table_content" style="border: 1px solid black; text-align:center;"><a onclick="open_registrar_Form()">View Detail</a></p>
                    <?php endif; ?>
                    <?php if(($student_id->registrar_description == null || $student_id->registrar_description !== null) && ($student_id->registrar == "IN-PROGRESS")): ?>  
                        <p class="table_content" style="border: 1px solid black; text-align:center;"><a onclick="open_registrar_Form()">Add Detail</a></p>
                    <?php endif; ?>
                    <div class="form-popup" id="registrar_form">
                        <textarea class="description_info" name="registrar_description" value="<?php echo e($student_id->registrar_description); ?>"><?php echo e($student_id->registrar_description); ?></textarea>
                        <button type="button" class="btn cancel" onclick="close_registrar_Form()">Close</button>  
                    </div>
            </div>
            <div class="column" >
                <h5 class="edit_student_column_header" style="border: 1px solid black; text-align:center; height:50px">Accounting Assessment</h5>
                    <p class="table_content" style="border: 1px solid black; text-align:center">
                        <?php if($student_id->accounting_assessment == "IN-PROGRESS"): ?>
                        <select readonly tabindex="-1" name="accounting_assessment" style="color:blue">
                        <?php endif; ?>
                        <?php if($student_id->accounting_assessment == "COMPLY"): ?>
                        <select readonly tabindex="-1" name="accounting_assessment" style="color:orange">
                        <?php endif; ?>
                        <?php if($student_id->accounting_assessment == "REJECTED"): ?>
                        <select readonly tabindex="-1" name="accounting_assessment" style="color:red">
                        <?php endif; ?>
                        <?php if($student_id->accounting_assessment == "APPROVED"): ?>
                        <select readonly tabindex="-1" name="accounting_assessment" style="color:green">
                        <?php endif; ?>
                        <option style="border: 1px solid black; text-align:center" value="<?php echo e($student_id->accounting_assessment); ?>"><?php echo e($student_id->accounting_assessment); ?></option>
                    
                        
                        <?php if($student_id->accounting_assessment !== "IN-PROGRESS"): ?>
                        <option style="border: 1px solid black; text-align:center; color: blue"value="IN-PROGRESS">IN-PROGRESS</option>
                        <?php endif; ?>
                        <?php if($student_id->accounting_assessment !== "COMPLY"): ?>
                        <option style="border: 1px solid black; text-align:center; color: orange"value="COMPLY">COMPLY</option>
                        <?php endif; ?>
                        <?php if($student_id->accounting_assessment !== "APPROVED"): ?>
                        <option style="border: 1px solid black; text-align:center; color:green;"value="APPROVED">APPROVED</option>
                        <?php endif; ?>
                        <?php if($student_id->accounting_assessment !== "REJECTED"): ?>
                        <option style="border: 1px solid black; text-align:center; color:red"value="REJECTED">REJECTED</option>
                        <?php endif; ?>
                        </select>
                    </p>
                        <?php if(($student_id->accounting_assessment == "REJECTED" || $student_id->accounting_assessment == "COMPLY") && ($student_id->accounting_assessment_description !== null || $student_id->accounting_assessment_description == null)): ?>  
                            <p class="table_content" style="border: 1px solid black; text-align:center;"><a onclick="open_assessment_Form()">View Detail</a></p>
                        <?php endif; ?>
                        <?php if(($student_id->accounting_assessment_description == null || $student_id->accounting_assessment_description !== null) && ($student_id->accounting_assessment == "IN-PROGRESS")): ?>  
                            <p class="table_content" style="border: 1px solid black; text-align:center;"><a onclick="open_assessment_Form()">Add Detail</a></p>
                        <?php endif; ?>
                        <div class="form-popup" id="assessment_form">
                            <textarea class="description_info" name="accounting_assessment_description" value="<?php echo e($student_id->accounting_assessment_description); ?>"><?php echo e($student_id->accounting_assessment_description); ?></textarea>
                            <button type="button" class="btn cancel" onclick="close_assessment_Form()">Close</button>  
                        </div>
            </div>
    </div>
        <div>
            <button type="submit" class="btn btn-primary" style="margin-left: 560px; margin-top: 5px;margin-bottom: 0px">Update User</button>
        </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<br>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Clearance-System\resources\views/admin/edit-student.blade.php ENDPATH**/ ?>