

<?php $__env->startSection('content'); ?>
<style>
.restore:hover{
width: 36px;
height: 36px;
}
img{
width: 34px;
height: 34px; 
}
.btn{
    width: 140px;
    color: white;
    text-align: left;
}
.no_button:hover {
    
    text-decoration: none;
    background-color: rgb(0, 216, 0);
}
.no_button{
    
    background-color: green;
}
.temporary_button:hover {
    color:#fff !important;
    text-decoration: none;
    background-color: rgb(255, 46, 46);
}
.temporary_button{
    margin-right: 10px;
    background-color: rgb(178, 1, 1);
}

</style>
    <div class="clearance_body_admin">
        <div class="card" style="width:100%; border: 2px solid black">
            <div class="card-header">
                <h4>Trashed List</h4>
            </div>
            <div class="card-body">
    
                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>
                <table class="table table-bordered" style="width:900px; border: 1px solid black">
                    <div class="restore_all" align="left">
                    <button class="btn btn-success" href="/admin/restore-all"><img src="/img/restore.png" alt="Italian Trulli">Restore all</button>
                    </div>
                   <thead >
                    
                        <tr >  
                            <th>ID</th>
                            <th>Department Name</th>
                            <th>Restore</th>
                        </tr>
                    </thead>
                    <tbody >
                        <?php $__currentLoopData = $trashed_department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->id); ?></td>
                            <td><?php echo e($item->dept_name); ?></td>                               
                            <td>
                                <a  href="<?php echo e(url ('admin/restore-department/'.$item->id)); ?>" ><img class="restore"  src="/img/recycle.png" alt="Italian Trulli"></a>
                              
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                
                <table class="table table-bordered" style="width:900px; border: 1px solid black">
                    <div class="restore_all" align="left">
                    <button class="btn btn-success" href="/admin/restore-all"><img src="/img/restore.png" alt="Italian Trulli">Restore all</button>
                    </div>
                   <thead >
                    
                        <tr >  
                            <th>ID</th>
                            <th>Course Name</th>
                            <th>Restore</th>
                        </tr>
                    </thead>
                    <tbody >
                        <?php $__currentLoopData = $trashed_course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delete_course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($delete_course->id); ?></td>
                            <td><?php echo e($delete_course->course_name); ?></td>                               
                            <td>
                                <a  href="<?php echo e(url ('admin/restore-department/'.$delete_course->id)); ?>" ><img class="restore"  src="/img/recycle.png" alt="Italian Trulli"></a>
                              
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>       
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Clearance-System\resources\views/admin/trash-department.blade.php ENDPATH**/ ?>