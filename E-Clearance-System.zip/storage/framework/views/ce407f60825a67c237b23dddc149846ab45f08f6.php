
<style>
.view_signee{
    padding-top:39px;
}
.page-item.active .page-link{
    z-index: 1 !important;
}
</style>
<?php $__env->startSection('content'); ?>
    <div class="view_signee">
        <div class="card" style="width:100%; border: 2px solid black">
            <div class="card-header">
                <div class="container">
                    <div class="error">
                        <?php if(count($errors) > 0): ?>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="alert alert-danger" style="text-align: center">
                                    <?php echo e($error); ?>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                
                        <?php if(session('success')): ?>
                            <div class="alert alert-success" style="text-align: center">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>
                
                        <?php if(session('error')): ?>
                            <div class="alert alert-danger" style="text-align: center">
                                <?php echo e(session('error')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <h4 style="text-align: center;font-weight: bold"> Signee List</h4>
            </div>
            <div class="card-body">
                <table class="table table-bordered" style="border: 1px solid black">
                    <thead > 
                        <tr >
                            
                            <div  class="col-md-4" style="padding-left: 0px; margin-right: 0px">
                                <input type="search" class="form-control"  name="search" id="admin-signee-search" placeholder="Search by: Name or School ID"/>                                              
                            </div>
                            <th>ID</th>
                            <th>name</th>
                            <th>email</th>
                            <th>School ID</th>
                            <th>Role</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody id="Admin-Signee-Content">
                        <?php $__currentLoopData = $user_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->id); ?></td>
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->email); ?></td>
                                <td><?php echo e($item->school_id); ?></td>
                                <td>                                   
                                    <?php echo e($item->role_as); ?>

                                </td>                              
                                <td>
                                    <a href="<?php echo e(url ('admin/edit-signee/'.$item->id)); ?>"><img class="edit" src="<?php echo e(asset('/img/edit.png')); ?>" alt="Italian Trulli"></a>
                                </td>
                                <td>
                                    <a onclick="document.getElementById(<?php echo e($item->id); ?>).style.display='block'" ><img class="edit" src="<?php echo e(asset('/img/delete.png')); ?>" alt="Italian Trulli"></a>
                                </td>
                            </tr>
                            <div id="<?php echo e($item->id); ?>" class="w3-modal" >
                                <div class="w3-modal-content" style="width:30%;">
                                    <header class="warning_header">
                                        <span onclick="document.getElementById(<?php echo e($item->id); ?>).style.display='none'"
                                        class="ekis_button w3-display-topright"><b>&times;</b></span>
                                        <h2 style="color: rgb(248, 50, 50)"><b>WARNING!</b></h2>
                                    </header>
                                    <div class="w3-container">
                                        <p style="text-align: left">
                                            Are you sure you want to delete<br>
                                            ID:<b><?php echo e($item->id); ?></b><br>
                                            Signee Name:<b><?php echo e($item->name); ?></b><br>
                                            School ID:<b><?php echo e($item->school_id); ?></b><br>
                                            Role:<b><?php echo e($item->role_as); ?></b><br>
                                            Department ID:<b><?php echo e($item->dept_id); ?></b><br>
                                            Created At:<b><?php echo e($item->created_at); ?></b><br>
                                            Updated At:<b><?php echo e($item->updated_at); ?> ?</b>
                                        </p>
                                    </div>
                                    <footer class="footer_line">
                                        <p class="button_option">
                                            <b>
                                                <a class="temporary_button" href="<?php echo e(url ('admin/delete-signee/'.$item->id)); ?>" >Temporarily!</a>
                                                <a class="temporary_button" href="<?php echo e(url ('admin/permanent-delete-signee/'.$item->id)); ?>" >Permanently!</a>
                                                <a class="no_button" style="cursor: pointer" onclick="document.getElementById(<?php echo e($item->id); ?>).style.display='none'">NO!</a>
                                            </b>
                                        </p>
                                    </footer>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($user_table->links()); ?>

            </div>
        </div>       
    </div>
<?php echo $__env->make('admin.user-activity', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Clearance-System\resources\views/admin/view-signee-user.blade.php ENDPATH**/ ?>