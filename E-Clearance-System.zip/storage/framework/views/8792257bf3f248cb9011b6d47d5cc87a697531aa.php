
<style>
.add_signee{
    padding-top: 39px;
}
.page-item.active .page-link{
    z-index: 1;
}
.form-control{
    background-color: #e9ecef;
}
.add_signee_column{
    width: 50%;
    float: left;
    padding-right: 10px;
    padding-left: 10px;
}
.add_signe_btn{
 padding-top: 275px;
 margin-left: 570px;
}
.add_signee_row{
border: 3px solid black;
}
.add_signee_label{
margin-left: 270px;
font-weight: bold;
}
</style>
<?php $__env->startSection('content'); ?>
<div class="add_signee">
    <div class="card" style="border: 2px solid black; ">      
        <div class="card-header" style="background-color: white">
            <div class="container">
                <div class="error">
                    <?php if(count($errors) > 0): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-danger" style="text-align: center">
                                <?php echo e($error); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
            
                    <?php if(session('success')): ?>
                        <div class="alert alert-success" style="text-align: center">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
            
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger" style="text-align: center">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="add_signee_row">
                    <h3 style="color:blue;; font-weight: bold; text-align: center">Add New Signee</h3>
                    <div class="card-body" style="padding: 0px; margin: 0px; font-size: 12px" >
                        <?php echo Form::open(['action' => 'App\Http\Controllers\Admin\AdminController@store_signee', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                            <?php echo e(csrf_field()); ?>

                            <div class="add_signee_column">
                                <label class="add_signee_label"  style="color: black"><?php echo e(__('Name')); ?> </label>
                                <input style="text-align:center" id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus placeholder="Last Name, First Name, Middle Initial">
                                
                            </div>
                           
                           
                           
                            <div class="add_signee_column">
                                <label class="add_signee_label"  style="color: black"> 
                                    <?php echo e(__('Role')); ?>

                                </label>                   
                                    <select style="text-align:center" name="role_as" class="form-control">
                                        <option selected="true" disabled="true">--Choose Role--</option>
                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(strcasecmp($item->role_name,'Student') !== 0): ?>
                                                <option value="<?php echo e($item->role_name); ?>"><?php echo e($item->role_name); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                      
                                    </select>
                            </div>


                            <div class="add_signee_column">
                                <label class="add_signee_label" style="color: black"><?php echo e(__('Department')); ?></label>
                                    <select style="text-align:center" name="dept_id" class="form-control select-class from required">
                                        <option selected disabled>--Select Department--</option>
                                        <option value="0">Not Applicable</option>
                                        <?php $__currentLoopData = $dept_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($list->id); ?>"> <?php echo e($list->dept_name); ?></option>                   
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                            </div>



                            <div class="add_signee_column">
                                <label class="add_signee_label" for="school_id"  style="color: black">
                                    <?php echo e(__('User_ID')); ?>

                                </label>                   
                                    <input placeholder="Example ID: 11-23456" style="text-align:center" id="school_id" type="text"
                                        class="form-control<?php echo e($errors->has('school_id') ? ' is-invalid' : ''); ?>"
                                        name="school_id" value="<?php echo e(old('school_id')); ?>" required>
                            </div>

                           

                            <div class="add_signee_column">
                                <label class="add_signee_label" for="password"  style="color: black"><?php echo e(__('Password')); ?></label>
                                    <input style="text-align:center" id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password">
                                    <script>
                                        function myFunction() { 
                                          var x = document.getElementById("password");
                                          var y = document.getElementById("password-confirm");
                                          if (x.type == "password" || y.type == "password-confirm") {
                                            x.type = "text";
                                            y.type = "text";
                                          } else {
                                            x.type = "password";
                                            y.type = "password";
                                          }
                                        }
                                        </script>
                            </div>

                            <div class="add_signee_column">
                                <label class="add_signee_label" for="email"  style="color: black"><?php echo e(__('Email Address')); ?></label>
                                    <input style="text-align:center" id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">
                            </div>
                            <div class="add_signee_column">
                                <label class="add_signee_label" for="password-confirm" style="color: black"><?php echo e(__('Confirm Password')); ?></label>
                                    <input style="text-align:center" id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                                    <label style="color:black; margin-bottom:10px; padding-bottom:5px; font-size:12px; margin-left: 20px; float: left;"> <input class="form-check-input"  type="checkbox" onclick="myFunction()">Show Password</label>
                            </div>

                            
                            <div class="add_signe_btn">
                                <input type="submit" class="btn btn-primary"/>
                            </div>
                        
                        <?php echo Form::close(); ?>

                    </div>
            </div>   
                <div style="background-color:rgb(224, 224, 225);">
                    <h3 style="color:blue; text-align: center">Activity Logs</h3>
                    <table class="table table-bordered" style=" border: 1px solid black; font-size: 12px;">
                        <thead >
                            <tr > 
                                <th>Name</th>
                                <th>Email</th>
                                <th>Date Created</th>
                            </tr>
                        </thead>
                        <tbody >
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr  >
                                
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->email); ?></td>
                                <td><?php echo e(date('M,d,D,Y,g:i A',strtotime($item->created_at))); ?></td>
                                
                            </tr>
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>        
                    </table>                   
                    <?php echo e($users->links()); ?> 
                </div>                
             </div>            
         </div>          
    </div>   
<?php echo $__env->make('admin.user-activity', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>








<?php echo $__env->make('layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Clearance-System\resources\views/admin/add-signee.blade.php ENDPATH**/ ?>