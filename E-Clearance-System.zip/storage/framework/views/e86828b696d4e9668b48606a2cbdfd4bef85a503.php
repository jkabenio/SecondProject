<?php $__env->startSection('content'); ?>



<div class="clearance_body_admin">
    <div class="card">
        <div class="card-header">
            <h2 style="text-align: center"><b> Our Lady of Lourdes College Foundation</h2>
            <h5 style="text-align: center">Daet, Camarines Norte</h5>
            <h3 style="text-align: center">Instructor E-CLEARANCE</b>
                
            </h3>
            <div class="two_column">
                <label>Year</label>
                <p class="form-control">
                    2021-2022
                </p>
            </div>
            <div class="two_column">
                <label>Semester</label>
                <p class="form-control" style="font-size: 12px">
                    2nd
                </p>
            </div>
            <p class="p_certify">This is to certify that I have cleared of all material and financial accountabilities<br>
            as well as requirements(Academic / Clinical as evidential by the signature appearing below).
            </p>
        </div>
        <div class="card-body">
            <div class="first_row">
                <div class="two_column ">
                    <label>Full Name</label>
                    <p class="form-control" style="font-size: 12px">
                        John Kennedy Z. Abenio
                    </p>
                </div>
                <div class="two_column ">
                    <label>Course</label>
                    <p class="form-control">
                        Bachelor of Science in Information Technology
                    </p>
                </div>
            </div>
            <div class="second_row">
                <div class="four_column">
                    <label>SUBJECTS</label>
                    <p class="form-control">
                    </p>
                    
                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>
                </div>
            
                <div class="four_column">
                    <label>INSTRUCTOR</label>
                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>
                </div>
                <div class="four_column">
                    <label>APPROVAL STATUS</label>
                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>
                </div>
                <div class="four_column">
                    <label>DESCRIPTION</label>
                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>
                    
                </div>
                <div class="four_column">
                    <label>Student</label>
                    <p class="form-control">
                    </p>
                </div>
                <div class="four_column">
                    <label>Student Org. Treasurer</label>
                    <p class="form-control">
                    </p>
                </div>
                <div class="four_column">
                    <label>Librarian</label>
                    <p class="form-control">
                    </p>
                </div>
                <div class="four_column">
                    <label>Dean of Student affair</label>
                    <p class="form-control">
                    </p>
                </div>
                <div class="four_column">
                    <label>Dean Principal</label>
                    <p class="form-control">
                    </p>
                </div>
                <div class="four_column">
                    <label>Guidance Councilor</label>
                    <p class="form-control">
                    </p>
                </div>
                <div class="four_column">
                    <label>Registrar</label>
                    <p class="form-control">
                    </p> 
                </div>
                <div class="four_column">
                    <label>Accounting-Assessment</label>
                    <p class="form-control">
                    </p>
                </div>
            </div>
            <form action="" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="mb-3">
                    <label>Role as</label>
                    <select name="role_as" class="form-control">
                       
                    </select>
 
                </div>

                <div class="mb-3">
                    <button type="submit" class="btn btn-primary">Update User Role</button>
                </div>
            </form>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Clearance-System\resources\views//instructordashboard.blade.php ENDPATH**/ ?>