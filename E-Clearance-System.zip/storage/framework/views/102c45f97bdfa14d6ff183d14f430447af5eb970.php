

<?php $__env->startSection('content'); ?>
<style>
.add_subject_view{
    padding-top: 39px;
}
.add_subject_row{
    width: 100%;
}
.add_subject_column{
width: 33.33%;
float: left;
padding-left: 10px;
padding-right: 10px;
}
.add_subject_label{
    margin-left: 150px;
    font-weight: bold;
    margin-top: 10px;
}
.add_subject_submit{
    padding-top: 230px;
    padding-bottom: 10px;
    margin-left: 580px;
}
.page-item.active .page-link{
    z-index: 1;
}
.form-control{
 background-color: #e9ecef;
}
</style>
<div class="add_subject_view">
    <div class="card" style="border: 2px solid black; ">      
        <div class="card-header" style="background-color: white">
            <div class="container">
                <div class="error">
                    <?php if(count($errors) > 0): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-danger" style="text-align: center">
                                <?php echo e($error); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
            
                    <?php if(session('success')): ?>
                        <div class="alert alert-success" style="text-align: center">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
            
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger" style="text-align: center">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
    <div>
        <h3 style="color:blue; text-align:center; font-weight: bold">Add New Subject</h3>
        <div class="card-body" style="padding: 0px; margin: 0px; font-size: 12px" >
            <?php echo Form::open(['action' => 'App\Http\Controllers\Admin\AdminController@store_subject', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                <?php echo e(csrf_field()); ?>

            <div class="add_subject_row">
                <div class="add_subject_column">
                    <label class="add_subject_label" style="color: black">Code</label>
                    <input  style="text-align:center" type="text" class="form-control <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="code" value="<?php echo e(old('code')); ?>" required>
                    <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="add_subject_column">
                    <label class="add_subject_label" style="color: black">Subject Code</label>
                    <input  style="text-align:center" type="text" class="form-control <?php $__errorArgs = ['subj_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="subj_code" value="<?php echo e(old('subj_code')); ?>" required>
                    <?php $__errorArgs = ['subj_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="add_subject_column">
                    <label class="add_subject_label" style="color: black">Subject Name</label>
                    <input  style="text-align:center" type="text" class="form-control <?php $__errorArgs = ['subj_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="subj_name" value="<?php echo e(old('subj_name')); ?>" required>
                    <?php $__errorArgs = ['subj_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="add_subject_column">
                    <label class="add_subject_label" style="color: black">Unit</label>
                    <input  style="text-align:center" type="text" class="form-control <?php $__errorArgs = ['unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="unit" value="<?php echo e(old('unit')); ?>" required>
                    <?php $__errorArgs = ['unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="add_subject_column">
                    <label class="add_subject_label" style="color: black">Year Level</label>
                    <select  style="text-align:center" name="year_level" class="form-control">
                        <option selected="true" disabled="true">--Select Year Level--</option>
                        <option value="1st Year">1st Year</option>
                        <option value="2nd Year">2nd Year</option>
                        <option value="3rd Year">3rd Year</option>
                        <option value="4th Year">4th Year</option>
                    </select> 
                        <?php $__errorArgs = ['year_level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="add_subject_column">
                    <label class="add_subject_label" style="color: black">Semester</label>
                    <select  style="text-align:center" name="semester" class="form-control">
                        <option selected="true" disabled="true">--Select Semester--</option>
                        <option value="1st Semester">1st Semester</option>
                        <option value="2nd Semester">2nd Semester</option>
                        <option value="Summer Class">Summer Class</option>
                    </select>
                </div>

                <div class="add_subject_column">
                    <label class="add_subject_label" style="color: black">Course</label>
                    <select  style="text-align:center" name="course_id" class="form-control">
                        <option selected="true" disabled="true">--Select Course--</option>
                        <?php $__currentLoopData = $course_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($list->id); ?>"> <?php echo e($list->course_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                
                <div class="add_subject_column">
                    <label class="add_subject_label" style="color: black">Section</label>
                    <select  style="text-align:center" name="section" class="form-control">
                        <option selected="true" disabled="true">--Select Section--</option>
                        <option value="Block A">Block A</option>
                        <option value="Block B">Block B</option>
                        <option value="Block C">Block C</option>
                        <option value="Block D">Block D</option>
                    </select>
                </div>
                <div class="add_subject_column">
                    <label class="add_subject_label" style="color: black">Assigned Signee</label>
                    <select  style="text-align:center" name="signee_names" class="form-control">
                        <option selected="true" disabled="true">--Choose One Signee--</option>
                        <?php $__currentLoopData = $signeelist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($list->name); ?>"><?php echo e($list->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="add_subject_submit">
                    <input type="submit" class="btn btn-primary"/>
                </div>
            </div>
            <?php echo Form::close(); ?>

            </div>
        </div> 
    </div>
</div>

<div style="background-color:rgb(224, 224, 225);">
    <h3 style="color:blue; text-align:center">Activity Logs</h3>
    <table class="table table-bordered" style=" border: 1px solid black; font-size: 12px;">
        <thead >
            <tr > 
                <th>Subject Name</th>
                <th>Date Created</th>
                <th>Date Updated</th>
                <th>Date Deleted</th>
            </tr>
        </thead>
        <tbody >
            <?php $__currentLoopData = $subject_log; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr  >
                <td><?php echo e($item->subj_name); ?></td>
                <td><?php echo e(date('M,d,D,Y,g:i A',strtotime($item->created_at))); ?></td>
                <td><?php echo e(date('M,d,D,Y,g:i A',strtotime($item->updated_at))); ?></td>
                <td><?php echo e(date('M,d,D,Y,g:i A',strtotime($item->deleted_at))); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>        
    </table>                   
        <?php echo e($subject_log->links()); ?> 
    </div>

<?php echo $__env->make('admin.user-activity', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Clearance-System\resources\views/admin/add-subject.blade.php ENDPATH**/ ?>