<?php $__env->startSection('content'); ?>


<div class="clearance_body_student">
    <div class="card_student" >
        <div class="card-header">
            <h2 style="text-align: center"><b> Our Lady of Lourdes College Foundation</h2>
            <h5 style="text-align: center">Daet, Camarines Norte</h5>
            <h3 style="text-align: center">E-CLEARANCE</b>
                
            </h3>
            <div class="two_column">
                <label>Year</label>
                <p class="form-control"> 
                    2021-2022
                </p>
            </div>
            <div class="two_column">
                <label>Semester</label>
                <p class="form-control" style="font-size: 12px">
                    2nd
                </p>
            </div>
            <p class="p_certify">This is to certify that I have cleared of all material and financial accountabilities<br>
            as well as requirements(Academic / Clinical as evidential by the signature appearing below).
            </p>
        </div>
        <div class="card-body">
            <div class="first_row">
                <div class="two_column ">
                    
                    <div class="form-control" style="font-size: 12px">
                        <?php if(auth()->guard()->guest()): ?>
                        <?php if(Route::has('login')): ?>
                                <button class="login_style"><a  href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a></button>
                        <?php endif; ?>
                        <br>
                        <?php if(Route::has('register')): ?>
                                <button class="login_style"><a  href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a></button>
                        <?php endif; ?>
                        <?php else: ?>
                        <a>
                            <a id="navbarDropdown" class="nav-link_name dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                               <?php echo e(Auth::user()->name); ?> </a>
                        </a>
                        
                        <div  class="dropdown-menu dropdown-menu-center" aria-labelledby="navbarDropdown" >
                            <a  class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>   
                                </a>
                            <form  id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                            </div>
                        </a>
                    <?php endif; ?>
                    </div>
                </div>
                <div class="two_column ">
                    
                    <p class="form-control">
                        Bachelor of Science in Information Technology
                    </p>
                </div>
            </div>
            <div class="second_row">
                <div class="four_column">
                    <label>SUBJECTS</label>
                    <p class="form-control">
                    </p>
                    
                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>
                </div>
            
                <div class="four_column">
                    <label>INSTRUCTOR</label>
                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>
                </div>
                <div class="four_column">
                    <label>APPROVAL</label>
                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>
                </div>
                <div class="four_column">
                    <label>DESCRIPTION</label>
                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>

                    <p class="form-control">
                    </p>
                    
                </div>
                <div class="four_column">
                    <label>Student</label>
                    <p class="form-control">
                    </p>
                </div>
                <div class="four_column">
                    <label>Student Org. Treasurer</label>
                    <p class="form-control">
                    </p>
                </div>
                <div class="four_column">
                    <label>Librarian</label>
                    <p class="form-control">
                    </p>
                </div>
                <div class="four_column">
                    <label>Dean of Student affair</label>
                    <p class="form-control">
                    </p>
                </div>
                <div class="four_column">
                    <label>Dean Principal</label>
                    <p class="form-control">
                    </p>
                </div>
                <div class="four_column">
                    <label>Guidance Councilor</label>
                    <p class="form-control">
                    </p>
                </div>
                <div class="four_column">
                    <label>Registrar</label>
                    <p class="form-control">
                    </p> 
                </div>
                <div class="four_column">
                    <label>Accounting-Assessment</label>
                    <p class="form-control">
                    </p>
                </div>
                
            </div>
            

       

        </div>

    </div>
    
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Clearance-System\resources\views//studentdashboard.blade.php ENDPATH**/ ?>