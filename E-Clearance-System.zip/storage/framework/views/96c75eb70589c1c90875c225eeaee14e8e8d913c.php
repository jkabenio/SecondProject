

<?php $__env->startSection('content'); ?>
<style>
    
/* Create three equal columns that floats next to each other */
.column {
    float: left;
    width: 20%;
    height: auto;
}

/* Clear floats after the columns */
/* .clearance_row:after {
    content: "";
    display: table;
    clear: both;
} */
    .clearance_row{
        float:right;
        margin-right: 1px;
        border: 2px solid;
        height: auto;
        margin-bottom: 20px;
        width: 100% !important;
    }
    p{
        white-space: nowrap; 
        width: auto;
        height: auto; 
        overflow: hidden;
        text-overflow: clip;
        text-align: center;
        background-color: #e9ecef;
    }
.form-popup {
    display: none;
    position: fixed;
    bottom: 300px;
    right: 250px;
    border: 3px solid #0800ff;
    z-index: 9;
    background-color: rgb(212, 212, 212);
    width: 500px;
    margin-bottom: auto;
    }
    
    /* Add styles to the form container */
    .form-container-activity {
    
    margin: auto !important;
    width: 300px !important;
    height: 300px !important;
    overflow: auto !important;
    /* way to prevent an element from scrolling its parent. */
    overscroll-behavior: contain;
    }
    
    /* Set a style for the submit/login button */
    .form-container-activity .btn_cancel {
    background-color: #04AA6D;
    color: white;
    padding: 16px 20px;
    border: none;
    cursor: pointer;
    width: 100%;
    margin-bottom:10px;
    opacity: 0.8;
    }
    
    /* Add a red background color to the cancel button */
    .form-container-activity .cancel {
    background-color: red;
    width: 50px;
    font-size: 12px;
    height: 24px;
    padding-top: 2px;
    margin-top: 0px;
    margin-bottom: 0px;
    border-radius: 0px;
    margin-left: 250px;
    /* position: fixed; */
    }
    /* Add some hover effects to buttons */
    .form-container-activity .btn_cancel:hover, .open-button:hover{
    opacity: 1;
    } 
    .btn.cancel{
    background-color: red;
    color: white;
    }
    .description_info{
    height: 155px;
    width: 490px;
    }
    .clearance_body{
        padding-top: 30px;
        width:100%;
    }
    select[readonly]
{
    pointer-events: none;
}
/* irrelevent styling */
*[readonly]
{

}

    .scroll_div{
    margin-right: 0px;
        margin-top: 10px;
        margin-bottom: 10px;
        width: 100% !important;
        height: 500px;
        overflow-x: hidden;
        overflow-y: auto;
        text-align: center;
         border: solid rgb(0, 0, 0) 3px;
    }
    .admin_pending_update_btn{
        float: left !important;
        margin-top: 8px;
        border-radius: 5px !important;
    }
    
      .pending_counts_column{
        width: 12.5%;
        float: left;
        font-size: 12px;
       padding: 0px;
        border-radius: 1px;
        height: 40px;
    }
    .pending_counts_row{
        width:100%;
        height: 3px;
        /* margin-left: 10px; */
        /* padding-right: 15px !important; */
    }
    .count-signee_style{
        background-color: rgb(220, 213, 2);
        border: solid rgb(0, 0, 0) 1px;
    }
    .filter_div{
        margin-top: 10px;
        margin-left: 20px;
    }
    .filter_div_column{
        width: 20%;
        padding-right: 10px;
        float: right !important;
    }
    .filter_div_column_btn{
        float: right !important;
        padding-right: 10px;
    }
    .update_btn{
        height: 38px;
        border-radius: 0px !important;
    }
    </style>
   
 
<div class="clearance_body">
    <h3 style="text-align:center; color:white; background-color: rgb(3, 3, 142); width: 100%"><b>All Pending Request</b></h3>
    <?php if(session('success')): ?>
        <div style="text-align:center" class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div style="text-align:center" class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>
    <form action="<?php echo e(route('admin.view-pending-request')); ?>" method="GET">
        <?php echo e(csrf_field()); ?>

        <?php
            $result = "";
            $id_val = 0;
        ?>
        <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(Request::get('course') == $item->id): ?>
            <?php
            $result = $item->course_acronym;
            $id_val =  $item->id;
        ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="row filter_div">
            <div  class="filter_div_column_btn">
                <button type="submit" class="btn btn-primary form-control" style="width:100px">Filter</button>
            </div>
            <div class="filter_div_column">
                <select name="course" class="form-control">
                    <?php if(Request::get('course') == null): ?>
                        <option value="">All Course</option>
                    <?php endif; ?>
                    <?php if(Request::get('course') !== null): ?>
                        <option value="<?php echo e($id_val); ?>" <?php echo e(Request::get('course')); ?>><?php echo e($result); ?></option>
                    <?php endif; ?>
                    <?php if(Request::get('course') !== null): ?>
                    <option value="">All Course</option>
                <?php endif; ?>
                    <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->id !== $id_val): ?>
                            <option  value="<?php echo e($item->id); ?>" <?php echo e(Request::get('course') == 'course' ? 'selected':''); ?>><?php echo e($item->course_acronym); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="filter_div_column">
                <select name="year_lvl"  class="form-control">
                    <option value="">All Level</option>
                    <option value="1st Year" <?php echo e(Request::get('year_lvl') == '1st Year' ? 'selected':''); ?>>1st Year</option>
                    <option value="2nd Year" <?php echo e(Request::get('year_lvl') == '2nd Year' ? 'selected':''); ?>>2nd Year</option>
                    <option value="3rd Year" <?php echo e(Request::get('year_lvl') == '3rd Year' ? 'selected':''); ?>>3rd Year</option>
                    <option value="4th Year" <?php echo e(Request::get('year_lvl') == '4th Year' ? 'selected':''); ?>>4th Year</option>
                </select>
            </div>
            
        </div>
    </form>
    
        <br>    
        <div class="pending_counts_row">
            
            <div class="pending_counts_column">
                <p class="count-signee_style">Instructor<br>(<?php echo e($signee); ?>)</p>
            </div>
            <div class="pending_counts_column">
                <p class="count-signee_style">Guidance Counselor<br>(<?php echo e($counselor); ?>)</p>
            </div>
            <div class="pending_counts_column">
                <p class="count-signee_style">Student Org. treasurer<br>(<?php echo e($treasurer); ?>)</p>
            </div>
            <div class="pending_counts_column">
                <p class="count-signee_style">Librarian<br>(<?php echo e($librarian); ?>)</p>
            </div>
            <div class="pending_counts_column">
                <p class="count-signee_style">Dean of Student Affair<br>(<?php echo e($affair); ?>)</p>
            </div>
            <div class="pending_counts_column">
                <p class="count-signee_style">Dean Principal<br>(<?php echo e($dean); ?>)</p>
            </div>
            <div class="pending_counts_column">
                <p class="count-signee_style">Registrar<br>(<?php echo e($registrar); ?>)</p>
            </div>
            <div class="pending_counts_column">
                <p class="count-signee_style">Accounting Assessment<br>(<?php echo e($assessment); ?>)</p>
            </div>
            
        </div>
        
        <div class="scroll_div">
            <?php $__currentLoopData = $users_pending_request; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index_count => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $approve_count = 0;
                        $status_total = 0;
                    ?>
                    <?php $__currentLoopData = $user->status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instructor_status_count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($instructor_status_count == "APPROVED"): ?>
                            <?php
                                $approve_count++;
                            ?>
                        <?php endif; ?>
                        <?php if($instructor_status_count !== "APPROVED" || $instructor_status_count == "APPROVED"): ?>
                            <?php
                                $status_total++;
                            ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    if($user->guidance_councilor == "APPROVED"){
                        $approve_count++;
                    }
                    if($user->student_org_treasurer == "APPROVED"){
                        $approve_count++;
                    }
                    if($user->librarian == "APPROVED"){
                        $approve_count++;
                    }
                    if($user->dean_of_student_affair == "APPROVED"){
                        $approve_count++;
                    }
                    if($user->dean_principal == "APPROVED"){
                        $approve_count++;
                    }
                    if($user->registrar == "APPROVED"){
                        $approve_count++;
                    }
                    if($user->accounting_assessment == "APPROVED"){
                        $approve_count++;
                    }
                    //
                    if($user->guidance_councilor == "APPROVED" || $user->guidance_councilor !== "APPROVED"){
                        $status_total++;
                    }
                    if($user->student_org_treasurer == "APPROVED" || $user->student_org_treasurer !== "APPROVED"){
                        $status_total++;
                    }
                    if($user->librarian == "APPROVED" || $user->librarian !== "APPROVED"){
                        $status_total++;
                    }
                    if($user->dean_of_student_affair == "APPROVED" || $user->dean_of_student_affair !== "APPROVED"){
                        $status_total++;
                    }
                    if($user->dean_principal == "APPROVED" || $user->dean_principal !== "APPROVED"){
                        $status_total++;
                    }
                    if($user->registrar == "APPROVED" || $user->registrar !== "APPROVED"){
                        $status_total++;
                    }
                    if($user->accounting_assessment == "APPROVED" || $user->accounting_assessment !== "APPROVED"){
                        $status_total++;
                    }
                        $pass_approved_total_value =  $approve_count;
                        $pass_status__total_value = $status_total;
                    // echo $pass_total_value;
                    // echo $pass_status_value;
                    ?>
                     <?php if($pass_approved_total_value !== $pass_status__total_value): ?>
                        <div class="clearance_row">
                            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($user->course == $list->id): ?>
                            <h5 style="text-align:center; background-color: blue; color:white"><b><?php echo e($user->name); ?> (<?php echo e($user->year_lvl); ?>-<?php echo e($list->course_acronym); ?>)&nbsp;E-Clearance </b></h5>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            <div class="column" >
                                <h6 style="border: 1px solid #dee2e6; text-align:center;"><b>Instructor</b></h6>     
                                    <?php $__currentLoopData = $user->student_signee_names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $signee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div style="border: 1px solid #dee2e6">
                                            <p><?php echo e($signee); ?></p>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                            </div>
                            <div class="column">
                                <h6 style="border: 1px solid #dee2e6; text-align:center;"><b>Subject</b></h6>
                                
                                    <?php $__currentLoopData = $user->subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div style="border: 1px solid #dee2e6"> 
                                            <p><?php echo e($subject_list); ?></p>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="column" >
                                <h6 style="border: 1px solid #dee2e6; text-align:center;"><b>Section</b></h6>
                                <?php $__currentLoopData = $user->student_section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div style="border: 1px solid #dee2e6"> 
                                        <p style="text-align:center;"><?php echo e($section_list); ?></p>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="column" >
                                <h6 style="border: 1px solid #dee2e6; text-align:center;"><b>Status</b></h6>
                                    <?php $__currentLoopData = $user->status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <div style="border: 1px solid #dee2e6">  
                                        <p style="text-align:center">
                                            <?php if($status_list == "IN-PROGRESS"): ?>
                                            <select style="color:blue" readonly tabindex="-1">
                                            <?php endif; ?>
                                            <?php if($status_list == "COMPLY"): ?>
                                            <select style="color:orange" readonly tabindex="-1">
                                            <?php endif; ?>
                                            <?php if($status_list == "REJECTED"): ?>
                                            <select  style="color:red" readonly tabindex="-1">
                                            <?php endif; ?>
                                            <?php if($status_list == "APPROVED"): ?>
                                            <select style="color:green" readonly tabindex="-1">
                                            <?php endif; ?>

                                                <option style="text-align:center" value="<?php echo e($status_list); ?>"><?php echo e($status_list); ?></option>
 
                                            <?php if($status_list !== "IN-PROGRESS"): ?>
                                                <option style="text-align:center; color: blue"value="IN-PROGRESS">IN-PROGRESS</option>
                                            <?php endif; ?>
                                            <?php if($status_list !== "COMPLY"): ?>
                                                <option style="text-align:center; color: orange"value="COMPLY">COMPLY</option>
                                            <?php endif; ?>
                                            <?php if($status_list !== "APPROVED"): ?>
                                                <option style="text-align:center; color:green;"value="APPROVED">APPROVED</option>
                                            <?php endif; ?>
                                            <?php if($status_list !== "REJECTED"): ?>
                                                <option style="text-align:center; color:red"value="REJECTED">REJECTED</option>
                                            <?php endif; ?>
                                            </select>
                                        </p>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>  
                            <div class="column" >
                                <h6 style="border: 1px solid #dee2e6; text-align:center;"><b>Description</b></h6>
                                    <?php $__currentLoopData = $user->description; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $description_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div style="border: 1px solid #dee2e6;">
                                        <?php if($description_list !== null): ?>  
                                            <p style="text-align:center;"><a onclick="open_signee_pending_Form(<?php echo e($index); ?>,<?php echo e($user->id); ?>)">View Detail</a></p>
                                        <?php endif; ?>
                                        <?php if($description_list == null): ?>  
                                            <p style="text-align:center;"><a onclick="open_signee_pending_Form(<?php echo e($index); ?>,<?php echo e($user->id); ?>)">Add Detail</a></p>
                                        <?php endif; ?>
                                        </div>
                                        <div class="form-popup" id="signee_pending_Form-<?php echo e($index); ?>-<?php echo e($user->id); ?>">
                                            <textarea class="description_info" readonly onchange="OnChangeHandler(<?php echo e($user->id); ?>)" value="<?php echo e($description_list); ?>"><?php echo e($description_list); ?></textarea>
                                            <button type="button" class="btn cancel" onclick="close_signee_pending_Form(<?php echo e($index); ?>,<?php echo e($user->id); ?>)">Close</button>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
                            </div>
                            <div class="column" >
                                <h6 style="border: 1px solid #dee2e6; text-align:center;"><b>Guidance Counselor</b></h6>
                                    <div style="border: 1px solid #dee2e6">  
                                        <p style="text-align:center">
                                            <?php if($user->guidance_councilor == "IN-PROGRESS"): ?>
                                            <select  style="color:blue" readonly tabindex="-1">
                                            <?php endif; ?>
                                            <?php if($user->guidance_councilor == "COMPLY"): ?>
                                            <select  style="color:orange" readonly tabindex="-1">
                                            <?php endif; ?>
                                            <?php if($user->guidance_councilor == "REJECTED"): ?>
                                            <select  style="color:red" readonly tabindex="-1">
                                            <?php endif; ?>
                                            <?php if($user->guidance_councilor == "APPROVED"): ?>
                                            <select  style="color:green" readonly tabindex="-1">
                                            <?php endif; ?>

                                                <option style="text-align:center" value="<?php echo e($user->guidance_councilor); ?>"><?php echo e($user->guidance_councilor); ?></option>
                                            
                                            <?php if($user->guidance_councilor !== "IN-PROGRESS"): ?>
                                                <option style="text-align:center; color: blue"value="IN-PROGRESS">IN-PROGRESS</option>
                                            <?php endif; ?>
                                            <?php if($user->guidance_councilor !== "COMPLY"): ?>
                                                <option style="text-align:center; color: orange"value="COMPLY">COMPLY</option>
                                            <?php endif; ?>
                                            <?php if($user->guidance_councilor!== "APPROVED"): ?>
                                                <option style="text-align:center; color:green;"value="APPROVED">APPROVED</option>
                                            <?php endif; ?>
                                            <?php if($user->guidance_councilor !== "REJECTED"): ?>
                                                <option style="text-align:center; color:red"value="REJECTED">REJECTED</option>
                                            <?php endif; ?>
                                            </select>
                                        </p>
                                    </div>
                                <h6 style="border: 1px solid #dee2e6; text-align:center;"><b>Description</b></h6>
                                <div style="border: 1px solid #dee2e6;">
                                    <?php if($user->guidance_councilor_description !== null): ?>  
                                        <p style="text-align:center;"><a onclick="open_guidance_councilor_pending_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">View Detail</a></p>
                                    <?php endif; ?>
                                    <?php if($user->guidance_councilor_description == null): ?>  
                                        <p style="text-align:center;"><a onclick="open_guidance_councilor_pending_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">Add Detail</a></p>
                                    <?php endif; ?>
                                </div>
                                <div class="form-popup" id="guidance_councilor_pending_Form-<?php echo e($index_count); ?>-<?php echo e($user->id); ?>">
                                    <textarea class="description_info" readonly value="<?php echo e($user->guidance_councilor_description); ?>"><?php echo e($user->guidance_councilor_description); ?></textarea>
                                    <button type="button" class="btn cancel" onclick="close_guidance_councilor_pending_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">Close</button>
                                </div> 
                            </div>
                            <div class="column" >
                                <h6 style="border: 1px solid #dee2e6; text-align:center;"><b>Student Org. Treasurer</b></h6>
                                    <div style="border: 1px solid #dee2e6">  
                                        <p style="text-align:center">
                                            <?php if($user->student_org_treasurer == "IN-PROGRESS"): ?>
                                            <select readonly tabindex="-1" style="color:blue">
                                            <?php endif; ?>
                                            <?php if($user->student_org_treasurer == "COMPLY"): ?>
                                            <select readonly tabindex="-1" style="color:orange">
                                            <?php endif; ?>
                                            <?php if($user->student_org_treasurer == "REJECTED"): ?>
                                            <select readonly tabindex="-1" style="color:red">
                                            <?php endif; ?>
                                            <?php if($user->student_org_treasurer == "APPROVED"): ?>
                                            <select readonly tabindex="-1" style="color:green">
                                            <?php endif; ?>
                                            <option style="text-align:center" value="<?php echo e($user->student_org_treasurer); ?>"><?php echo e($user->student_org_treasurer); ?></option>

                                            <?php if($user->student_org_treasurer !== "IN-PROGRESS"): ?>
                                                <option style="text-align:center; color: blue"value="IN-PROGRESS">IN-PROGRESS</option>
                                            <?php endif; ?>
                                            <?php if($user->student_org_treasurer !== "COMPLY"): ?>
                                                <option style="text-align:center; color: orange"value="COMPLY">COMPLY</option>
                                            <?php endif; ?>
                                            <?php if($user->student_org_treasurer!== "APPROVED"): ?>
                                                <option style="text-align:center; color:green;"value="APPROVED">APPROVED</option>
                                            <?php endif; ?>
                                            <?php if($user->student_org_treasurer !== "REJECTED"): ?>
                                                <option style="text-align:center; color:red"value="REJECTED">REJECTED</option>
                                            <?php endif; ?>
                                            </select>
                                        </p>
                                    </div>
                                <h6 style="border: 1px solid #dee2e6; text-align:center;"><b>Description</b></h6>
                                <div style="border: 1px solid #dee2e6;">
                                    <?php if($user->student_org_description !== null): ?>  
                                        <p style="text-align:center;"><a onclick="open_student_org_pending_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">View Detail</a></p>
                                    <?php endif; ?>
                                    <?php if($user->student_org_description == null): ?>  
                                        <p style="text-align:center;"><a onclick="open_student_org_pending_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">Add Detail</a></p>
                                    <?php endif; ?>
                                </div>
                                <div class="form-popup" id="student_org_pending_Form-<?php echo e($index_count); ?>-<?php echo e($user->id); ?>">
                                    <textarea class="description_info" readonly value="<?php echo e($user->student_org_description); ?>"><?php echo e($user->student_org_description); ?></textarea>
                                    <button type="button" class="btn cancel" onclick="close_student_org_pending_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">Close</button>
                                </div> 
                            </div>
                            <div class="column" >
                                <h6 style="border: 1px solid #dee2e6; text-align:center;"><b>Librarian</b></h6>
                                    <div style="border: 1px solid #dee2e6">  
                                        <p style="text-align:center">
                                            <?php if($user->librarian == "IN-PROGRESS"): ?>
                                            <select readonly tabindex="-1" style="color:blue">
                                            <?php endif; ?>
                                            <?php if($user->librarian == "COMPLY"): ?>
                                            <select readonly tabindex="-1" style="color:orange">
                                            <?php endif; ?>
                                            <?php if($user->librarian == "REJECTED"): ?>
                                            <select readonly tabindex="-1" style="color:red">
                                            <?php endif; ?>
                                            <?php if($user->librarian == "APPROVED"): ?>
                                            <select readonly tabindex="-1" style="color:green">
                                            <?php endif; ?>
                                            <option style="text-align:center" value="<?php echo e($user->librarian); ?>"><?php echo e($user->librarian); ?></option>

                                            <?php if($user->librarian !== "IN-PROGRESS"): ?>
                                                <option style="text-align:center; color: blue"value="IN-PROGRESS">IN-PROGRESS</option>
                                            <?php endif; ?>
                                            <?php if($user->librarian !== "COMPLY"): ?>
                                                <option style="text-align:center; color: orange"value="COMPLY">COMPLY</option>
                                            <?php endif; ?>
                                            <?php if($user->librarian!== "APPROVED"): ?>
                                                <option style="text-align:center; color:green;"value="APPROVED">APPROVED</option>
                                            <?php endif; ?>
                                            <?php if($user->librarian !== "REJECTED"): ?>
                                                <option style="text-align:center; color:red"value="REJECTED">REJECTED</option>
                                            <?php endif; ?>
                                            </select>
                                        </p>
                                    </div>
                                <h6 style="border: 1px solid #dee2e6; text-align:center;"><b>Description</b></h6>
                                <div style="border: 1px solid #dee2e6;">
                                    <?php if($user->librarian_description !== null): ?>  
                                        <p style="text-align:center;"><a onclick="open_librarian_pending_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">View Detail</a></p>
                                    <?php endif; ?>
                                    <?php if($user->librarian_description == null): ?>  
                                        <p style="text-align:center;"><a onclick="open_librarian_pending_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">Add Detail</a></p>
                                    <?php endif; ?>
                                </div>
                                <div class="form-popup" id="librarian_pending_Form-<?php echo e($index_count); ?>-<?php echo e($user->id); ?>">
                                    <textarea class="description_info" readonly value="<?php echo e($user->librarian_description); ?>"><?php echo e($user->librarian_description); ?></textarea>
                                    <button type="button" class="btn cancel" onclick="close_librarian_pending_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">Close</button>
                                </div> 
                            </div>
                            <div class="column" >
                                <h6 style="border: 1px solid #dee2e6; text-align:center;"><b>Dean of student Affair</b></h6>
                                    <div style="border: 1px solid #dee2e6">  
                                        <p style="text-align:center">
                                            <?php if($user->dean_of_student_affair == "IN-PROGRESS"): ?>
                                            <select readonly tabindex="-1" style="color:blue">
                                            <?php endif; ?>
                                            <?php if($user->dean_of_student_affair == "COMPLY"): ?>
                                            <select readonly tabindex="-1" style="color:orange">
                                            <?php endif; ?>
                                            <?php if($user->dean_of_student_affair == "REJECTED"): ?>
                                            <select readonly tabindex="-1" style="color:red">
                                            <?php endif; ?>
                                            <?php if($user->dean_of_student_affair == "APPROVED"): ?>
                                            <select readonly tabindex="-1" style="color:green">
                                            <?php endif; ?>
                                            <option style="text-align:center" value="<?php echo e($user->dean_of_student_affair); ?>"><?php echo e($user->dean_of_student_affair); ?></option>

                                            <?php if($user->dean_of_student_affair !== "IN-PROGRESS"): ?>
                                                <option style="text-align:center; color: blue"value="IN-PROGRESS">IN-PROGRESS</option>
                                            <?php endif; ?>
                                            <?php if($user->dean_of_student_affair !== "COMPLY"): ?>
                                                <option style="text-align:center; color: orange"value="COMPLY">COMPLY</option>
                                            <?php endif; ?>
                                            <?php if($user->dean_of_student_affair!== "APPROVED"): ?>
                                                <option style="text-align:center; color:green;"value="APPROVED">APPROVED</option>
                                            <?php endif; ?>
                                            <?php if($user->dean_of_student_affair !== "REJECTED"): ?>
                                                <option style="text-align:center; color:red"value="REJECTED">REJECTED</option>
                                            <?php endif; ?>
                                            </select>
                                        </p>
                                    </div>
                                <h6 style="border: 1px solid #dee2e6; text-align:center;"><b>Description</b></h6>
                                    <div style="border: 1px solid #dee2e6;">
                                        <?php if($user->dean_of_student_affair_description !== null): ?>  
                                            <p style="text-align:center;"><a onclick="open_student_affair_pending_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">View Detail</a></p>
                                        <?php endif; ?>
                                        <?php if($user->dean_of_student_affair_description == null): ?>  
                                            <p style="text-align:center;"><a onclick="open_student_affair_pending_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">Add Detail</a></p>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-popup" id="student_affair_pending_Form-<?php echo e($index_count); ?>-<?php echo e($user->id); ?>">
                                        <textarea class="description_info" readonly value="<?php echo e($user->dean_of_student_affair_description); ?>"><?php echo e($user->dean_of_student_affair_description); ?></textarea>
                                        <button type="button" class="btn cancel" onclick="close_student_affair_pending_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">Close</button>
                                    </div> 
                            </div>
                            <div class="column" >
                                <h6 style="border: 1px solid #dee2e6; text-align:center;"><b>Dean Principal</b></h6>
                                    <div style="border: 1px solid #dee2e6">  
                                        <p style="text-align:center">
                                            <?php if($user->dean_principal == "IN-PROGRESS"): ?>
                                            <select readonly tabindex="-1" style="color:blue">
                                            <?php endif; ?>
                                            <?php if($user->dean_principal == "COMPLY"): ?>
                                            <select readonly tabindex="-1" style="color:orange">
                                            <?php endif; ?>
                                            <?php if($user->dean_principal == "REJECTED"): ?>
                                            <select readonly tabindex="-1" style="color:red">
                                            <?php endif; ?>
                                            <?php if($user->dean_principal == "APPROVED"): ?>
                                            <select readonly tabindex="-1" style="color:green">
                                            <?php endif; ?>
                                            <option style="text-align:center" value="<?php echo e($user->dean_principal); ?>"><?php echo e($user->dean_principal); ?></option>

                                            <?php if($user->dean_principal !== "IN-PROGRESS"): ?>
                                                <option style="text-align:center; color: blue"value="IN-PROGRESS">IN-PROGRESS</option>
                                            <?php endif; ?>
                                            <?php if($user->dean_principal !== "COMPLY"): ?>
                                                <option style="text-align:center; color: orange"value="COMPLY">COMPLY</option>
                                            <?php endif; ?>
                                            <?php if($user->dean_principal!== "APPROVED"): ?>
                                                <option style="text-align:center; color:green;"value="APPROVED">APPROVED</option>
                                            <?php endif; ?>
                                            <?php if($user->dean_principal !== "REJECTED"): ?>
                                                <option style="text-align:center; color:red"value="REJECTED">REJECTED</option>
                                            <?php endif; ?>
                                            </select>
                                        </p>
                                    </div>
                                <h6 style="border: 1px solid #dee2e6; text-align:center;"><b>Description</b></h6>
                                <div style="border: 1px solid #dee2e6;">
                                    <?php if($user->dean_principal_description !== null): ?>  
                                        <p style="text-align:center;"><a onclick="open_dean_principal_pending_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">View Detail</a></p>
                                    <?php endif; ?>
                                    <?php if($user->dean_principal_description == null): ?>  
                                        <p style="text-align:center;"><a onclick="open_dean_principal_pending_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">Add Detail</a></p>
                                    <?php endif; ?>
                                </div>
                                <div class="form-popup" id="dean_principal_pending_Form-<?php echo e($index_count); ?>-<?php echo e($user->id); ?>">
                                    <textarea class="description_info" readonly value="<?php echo e($user->dean_principal_description); ?>"><?php echo e($user->dean_principal_description); ?></textarea>
                                    <button type="button" class="btn cancel" onclick="close_dean_principal_pending_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">Close</button>
                                </div> 
                            </div>
                            <div class="column" >
                                <h6 style="border: 1px solid #dee2e6; text-align:center;"><b>Registrar</b></h6>
                                    <div style="border: 1px solid #dee2e6">  
                                        <p style="text-align:center">
                                            <?php if($user->registrar == "IN-PROGRESS"): ?>
                                            <select readonly tabindex="-1" style="color:blue">
                                            <?php endif; ?>
                                            <?php if($user->registrar == "COMPLY"): ?>
                                            <select readonly tabindex="-1" style="color:orange">
                                            <?php endif; ?>
                                            <?php if($user->registrar == "REJECTED"): ?>
                                            <select readonly tabindex="-1" style="color:red">
                                            <?php endif; ?>
                                            <?php if($user->registrar == "APPROVED"): ?>
                                            <select readonly tabindex="-1" style="color:green">
                                            <?php endif; ?>
                                            <option style="text-align:center" value="<?php echo e($user->registrar); ?>"><?php echo e($user->registrar); ?></option>

                                            <?php if($user->registrar !== "IN-PROGRESS"): ?>
                                            <option style="text-align:center; color: blue"value="IN-PROGRESS">IN-PROGRESS</option>
                                            <?php endif; ?>
                                            <?php if($user->registrar !== "COMPLY"): ?>
                                            <option style="text-align:center; color: orange"value="COMPLY">COMPLY</option>
                                            <?php endif; ?>
                                            <?php if($user->registrar !== "APPROVED"): ?>
                                            <option style="text-align:center; color:green;"value="APPROVED">APPROVED</option>
                                            <?php endif; ?>
                                            <?php if($user->registrar !== "REJECTED"): ?>
                                            <option style="text-align:center; color:red"value="REJECTED">REJECTED</option>
                                            <?php endif; ?>
                                            </select>
                                        </p>
                                    </div>
                                <h6 style="border: 1px solid #dee2e6; text-align:center;"><b>Description</b></h6>
                                <div style="border: 1px solid #dee2e6;">
                                    <?php if($user->registrar_description !== null): ?>  
                                        <p style="text-align:center;"><a onclick="open_registrar_pending_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">View Detail</a></p>
                                    <?php endif; ?>
                                    <?php if($user->registrar_description == null): ?>  
                                        <p style="text-align:center;"><a onclick="open_registrar_pending_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">Add Detail</a></p>
                                    <?php endif; ?>
                                </div>
                                <div class="form-popup" id="registrar_pending_Form-<?php echo e($index_count); ?>-<?php echo e($user->id); ?>">
                                    <textarea class="description_info" readonly value="<?php echo e($user->registrar_description); ?>"><?php echo e($user->registrar_description); ?></textarea>
                                    <button type="button" class="btn cancel" onclick="close_registrar_pending_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">Close</button>
                                </div> 
                            </div>
                            <div class="column" >
                                <h6 style="border: 1px solid #dee2e6; text-align:center;"><b>Accounting Assessment</b></h6>
                                    <div style="border: 1px solid #dee2e6">  
                                        <p style="text-align:center">
                                            <?php if($user->accounting_assessment == "IN-PROGRESS"): ?>
                                            <select readonly tabindex="-1" style="color:blue">
                                            <?php endif; ?>
                                            <?php if($user->accounting_assessment == "COMPLY"): ?>
                                            <select readonly tabindex="-1" style="color:orange">
                                            <?php endif; ?>
                                            <?php if($user->accounting_assessment == "REJECTED"): ?>
                                            <select readonly tabindex="-1" style="color:red">
                                            <?php endif; ?>
                                            <?php if($user->accounting_assessment == "APPROVED"): ?>
                                            <select readonly tabindex="-1" style="color:green">
                                            <?php endif; ?>
                                            <option style="text-align:center" value="<?php echo e($user->accounting_assessment); ?>"><?php echo e($user->accounting_assessment); ?></option>

                                            <?php if($user->accounting_assessment !== "IN-PROGRESS"): ?>
                                            <option style="text-align:center; color: blue"value="IN-PROGRESS">IN-PROGRESS</option>
                                            <?php endif; ?>
                                            <?php if($user->accounting_assessment !== "COMPLY"): ?>
                                            <option style="text-align:center; color: orange"value="COMPLY">COMPLY</option>
                                            <?php endif; ?>
                                            <?php if($user->accounting_assessment !== "APPROVED"): ?>
                                            <option style="text-align:center; color:green;"value="APPROVED">APPROVED</option>
                                            <?php endif; ?>
                                            <?php if($user->accounting_assessment !== "REJECTED"): ?>
                                            <option style="text-align:center; color:red"value="REJECTED">REJECTED</option>
                                            <?php endif; ?>
                                            </select>
                                        </p>
                                    </div>
                                <h6 style="border: 1px solid #dee2e6; text-align:center;"><b>Description</b></h6>
                                <div style="border: 1px solid #dee2e6;">
                                    <?php if($user->accounting_assessment_description !== null): ?>  
                                        <p style="text-align:center;"><a onclick="open_assessment_pending_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">View Detail</a></p>
                                    <?php endif; ?>
                                    <?php if($user->accounting_assessment_description == null): ?>  
                                        <p style="text-align:center;"><a onclick="open_assessment_pending_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">Add Detail</a></p>
                                    <?php endif; ?>
                                </div>
                                <div class="form-popup" id="assessment_pending_Form-<?php echo e($index_count); ?>-<?php echo e($user->id); ?>">
                                    <textarea class="description_info" readonly value="<?php echo e($user->accounting_assessment_description); ?>"><?php echo e($user->accounting_assessment_description); ?></textarea>
                                    <button type="button" class="btn cancel" onclick="close_assessment_pending_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">Close</button>
                                </div> 
                            </div>
                        </div>     
                    <?php endif; ?>     
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        
        
    <?php $__env->stopSection(); ?>
</div>
<script>
    function OnChangeHandler(userId) {
        document.getElementById(`id[${userId}]`).checked = true;
    }
</script>

<?php echo $__env->make('layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Clearance-System\resources\views/admin/view-pending-request.blade.php ENDPATH**/ ?>