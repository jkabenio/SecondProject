

<?php $__env->startSection('content'); ?>
 <style>
label{
    
    float: left;
    text-align: left;
}
p{
    text-align:left;
}
.edit_subject_view{
padding-top: 39px;
}
.edit_subject_row{
width: 100%;
padding-top: 30px;
}
.edit_subject_column{
    width: 33.33%;
    float: left;
    padding-left: 10px;
    padding-right: 10px;
   
}
.edit_view_label{
    margin-left: 180px;
    font-weight: bold;
}
.edit_subject_btn{
    margin-left: 550px;
    margin-top: 260px;
}
.form-control{
 background-color: #e9ecef;
}
</style>
<div class="edit_subject_view">
    <div class="card" style="border: 2px solid black; margin-left: 0.3px;">
        <div class="card-header">
            <div class="container">
                <div class="error">
                    <?php if(count($errors) > 0): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-danger" style="text-align: center">
                                <?php echo e($error); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
            
                    <?php if(session('success')): ?>
                        <div class="alert alert-success" style="text-align: center">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
            
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger" style="text-align: center">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <h4 style="text-align:center; font-weight: bold;"><b>Edit Subject</b>
                <a href="<?php echo e(url('/admin/view-subject')); ?>" class="btn btn-danger float-end">BACK</a>
            </h4>
        </div>
        <?php echo Form::open(['action' => ['App\Http\Controllers\Admin\AdminController@update_subject',$subject_id->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

        <div class="edit_subject_row">
            <?php echo csrf_field(); ?> 
            <?php echo method_field('PUT'); ?>
           
            
            <div class="edit_subject_column">
                <label class="edit_view_label">Code</label>
                <input style="text-align: center"  type="text" name="code" value="<?php echo e($subject_id->code); ?>" class="form-control">
            </div>

            <div class="edit_subject_column">
                <label class="edit_view_label">Subject Code</label>
                <input style="text-align: center" type="text" name="subj_code" value="<?php echo e($subject_id->subj_code); ?>" class="form-control">
            </div>

            <div class="edit_subject_column">
                <label class="edit_view_label">Subject Name</label>
                <input style="text-align: center" type="text" name="subj_name" value="<?php echo e($subject_id->subj_name); ?>" class="form-control">
            </div> 

            <div class="edit_subject_column">
                <label class="edit_view_label">Unit</label>
                <input style="text-align: center" type="text" name="unit" value="<?php echo e($subject_id->unit); ?>" class="form-control">
            </div> 
 
            <div class="edit_subject_column">
                <label class="edit_view_label">Semester</label>
                <select style="text-align: center" name="semester" class="form-control">
                    <option value="<?php echo e($subject_id->semester); ?>"><?php echo e($subject_id->semester); ?></option>
                    <?php if($subject_id->semester !== "1st semeter"): ?>
                        <option value="1st semeter">1st semeter</option>
                    <?php endif; ?>
                    <?php if($subject_id->semester !== "2st semeter"): ?>
                        <option value="2nd semeter">2nd semeter</option>
                    <?php endif; ?>
                    <?php if($subject_id->semester !== "summer semeter"): ?>
                        <option value="summer class">summer class</option>
                    <?php endif; ?>
                </select> 
            </div>

            <div class="edit_subject_column">
                <label class="edit_view_label">Course</label>
                <select style="text-align: center" name="course_id" class="form-control">
                    <?php $__currentLoopData = $course_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                       
                        <?php if($item->id == $subject_id->course_id): ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->course_name); ?> </option>
                        <?php endif; ?>                                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $course_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($list->id !== $subject_id->course_id): ?>
                    <option value="<?php echo e($list->id); ?>"> <?php echo e($list->course_name); ?></option>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select> 
            </div>

            <div class="edit_subject_column">
                <label class="edit_view_label">Signee</label>
                <select style="text-align: center" name="signee_names" class="form-control">
                    <option value="<?php echo e($subject_id->signee_names); ?>"><?php echo e($subject_id->signee_names); ?></option>
                    <?php $__currentLoopData = $signees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $signee_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($signee_list->name !== $subject_id->signee_names): ?>
                            <option value="<?php echo e($signee_list->name); ?>"><?php echo e($signee_list->name); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select> 
            </div>

            <div class="edit_subject_column">
                <label class="edit_view_label">Section</label>
                <select style="text-align: center" name="section" class="form-control">
                    <option value="<?php echo e($subject_id->section); ?>"><?php echo e($subject_id->section); ?></option>
                    <?php if($subject_id->section !== "Block A"): ?>
                        <option value="Block A">Block A</option>
                    <?php endif; ?>
                    <?php if($subject_id->section !== "Block B"): ?>
                        <option value="Block B">Block B</option>
                    <?php endif; ?>
                    <?php if($subject_id->section !== "Block C"): ?>
                        <option value="Block C">Block C</option>
                    <?php endif; ?>
                    <?php if($subject_id->section !== "Block D"): ?>
                        <option value="Block D">Block D</option>
                    <?php endif; ?>
                </select> 
            </div>
                
                <div class="edit_subject_column">
                    <label class="edit_view_label">Created At</label>
                    <p style="text-align: center" class="form-control">
                        <?php echo e(date('M,d,D,Y,g:i A',strtotime($subject_id->created_at))); ?></p>
                </div>
                <div class="edit_subject_column">
                    <label class="edit_view_label">Updated At</label>
                    <p style="text-align: center" class="form-control">
                        <?php echo e(date('M,d,D,Y,g:i A',strtotime($subject_id->updated_at))); ?></p>
                </div> 
        </div>
        <div class="edit_subject_btn">
            <button type="submit" class="btn btn-primary">Update Subject</button>
        </div>
<?php echo Form::close(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Clearance-System\resources\views/admin/edit-subject.blade.php ENDPATH**/ ?>