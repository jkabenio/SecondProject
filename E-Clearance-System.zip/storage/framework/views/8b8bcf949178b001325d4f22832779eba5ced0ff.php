

<?php $__env->startSection('content'); ?>
<style>
    
/* Create three equal columns that floats next to each other */
.column {
    float: left;
    width: 20%;
    height: auto;
}

/* Clear floats after the columns */
/* .clearance_row:after {
    content: "";
    display: table;
    clear: both;
} */
    .clearance_row{
        float:right;
        margin-right: 1px;
        border: 2px solid;
        height: auto;
        margin-bottom: 20px;
        width: 100% !important;
    }
    p{
        white-space: nowrap; 
        width: auto;
        height: auto; 
        overflow: hidden;
        text-overflow: clip;
        text-align: center;
        background-color: #e9ecef;
    }
.form-popup {
    display: none;
    position: fixed;
    bottom: 300px;
    right: 250px;
    border: 3px solid #0800ff;
    z-index: 9;
    background-color: rgb(212, 212, 212);
    width: 500px;
    margin-bottom: auto;
    }
    
    /* Add styles to the form container */
    .form-container-activity {
    
    margin: auto !important;
    width: 300px !important;
    height: 300px !important;
    overflow: auto !important;
    /* way to prevent an element from scrolling its parent. */
    overscroll-behavior: contain;
    }
    
    /* Set a style for the submit/login button */
    .form-container-activity .btn_cancel {
    background-color: #04AA6D;
    color: white;
    padding: 16px 20px;
    border: none;
    cursor: pointer;
    width: 100%;
    margin-bottom:10px;
    opacity: 0.8;
    }
    
    /* Add a red background color to the cancel button */
    .form-container-activity .cancel {
    background-color: red;
    width: 50px;
    font-size: 12px;
    height: 24px;
    padding-top: 2px;
    margin-top: 0px;
    margin-bottom: 0px;
    border-radius: 0px;
    margin-left: 250px;
    /* position: fixed; */
    }
    /* Add some hover effects to buttons */
    .form-container-activity .btn_cancel:hover, .open-button:hover{
    opacity: 1;
    } 
    .btn.cancel{
    background-color: red;
    color: white;
    }
    .description_info{
    height: 155px;
    width: 490px;
    }
    .clearance_body{
        padding-top: 30px;
        width:100%;
    }
    select[readonly]
{
    pointer-events: none;
}
/* irrelevent styling */
*[readonly]
{

}

    .scroll_div{
    margin-right: 0px;
        margin-top: 10px;
        margin-bottom: 10px;
        width: 100% !important;
        height: 500px;
        overflow-x: hidden;
        overflow-y: auto;
        text-align: center;
         border: solid rgb(0, 0, 0) 3px;
    }
    .admin_pending_update_btn{
        float: left !important;
        margin-top: 8px;
        border-radius: 5px !important;
    }
    
      .pending_counts_column{
        width: 12.5%;
        float: left;
        font-size: 12px;
       padding: 0px;
        border-radius: 1px;
        height: 40px;
    }
    .pending_counts_row{
        width:100%;
        height: 3px;
        /* margin-left: 10px; */
        /* padding-right: 15px !important; */
    }
    .count-signee_style{
        background-color: rgb(220, 213, 2);
        border: solid rgb(0, 0, 0) 1px;
    }
    .filter_div{
        margin-top: 10px;
        margin-left: 20px;
    }
    .filter_div_column{
        width: 20%;
        padding-right: 10px;
        float: right !important;
    }
    .filter_div_column_btn{
        float: right !important;
        padding-right: 10px;
    }
    .update_btn{
        height: 38px;
        border-radius: 0px !important;
    }
    table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  text-align: center;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #D6EEEE;
}
    </style>
            <div class="clearance_body">
                <div  class="card" style=" border: 2px solid black">
                    <div class="card-header">
                        <div class="container">
                            <div class="error">
                                <?php if(count($errors) > 0): ?>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="alert alert-danger" style="text-align: center">
                                            <?php echo e($error); ?>

                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                        
                                <?php if(session('success')): ?>
                                    <div class="alert alert-success" style="text-align: center">
                                        <?php echo e(session('success')); ?>

                                    </div>
                                <?php endif; ?>
                        
                                <?php if(session('error')): ?>
                                    <div class="alert alert-danger" style="text-align: center">
                                        <?php echo e(session('error')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <h4 style="text-align:center;font-weight: bold;">Student List</h4>
                    </div>
                    <div  class="card-body">
                        <table class="table table-bordered" style="border: 1px solid black">
                            <thead >
                                <tr >
                                    
                                    <th>No.</th>
                                    <th>Name</th>
                                    <th>Course</th>
                                    <th>Year Level</th>
                                    <th>Semester</th>
                                    <th>School ID</th>
                                    <th>Clearance</th>
                                </tr>
                            </thead> 
                            <tbody>
                                <?php
                                    $index_count = 1;
                                ?> 
                                <?php $__currentLoopData = $complete_request; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $approve_count = 0;
                                        $status_total = 0;
                                    ?> 
                                    <?php $__currentLoopData = $user->status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instructor_status_count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($instructor_status_count == "APPROVED"): ?>
                                            <?php
                                                $approve_count++;
                                            ?>
                                        <?php endif; ?>
                                        <?php if($instructor_status_count !== "APPROVED" || $instructor_status_count == "APPROVED"): ?>
                                            <?php
                                                $status_total++;
                                            ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                    if($user->guidance_councilor == "APPROVED"){
                                        $approve_count++;
                                    }
                                    if($user->student_org_treasurer == "APPROVED"){
                                        $approve_count++;
                                    }
                                    if($user->librarian == "APPROVED"){
                                        $approve_count++;
                                    }
                                    if($user->dean_of_student_affair == "APPROVED"){
                                        $approve_count++;
                                    }
                                    if($user->dean_principal == "APPROVED"){
                                        $approve_count++;
                                    }
                                    if($user->registrar == "APPROVED"){
                                        $approve_count++;
                                    }
                                    if($user->accounting_assessment == "APPROVED"){
                                        $approve_count++;
                                    }
                                    //
                                    if($user->guidance_councilor == "APPROVED" || $user->guidance_councilor !== "APPROVED"){
                                        $status_total++;
                                    }
                                    if($user->student_org_treasurer == "APPROVED" || $user->student_org_treasurer !== "APPROVED"){
                                        $status_total++;
                                    }
                                    if($user->librarian == "APPROVED" || $user->librarian !== "APPROVED"){
                                        $status_total++;
                                    }
                                    if($user->dean_of_student_affair == "APPROVED" || $user->dean_of_student_affair !== "APPROVED"){
                                        $status_total++;
                                    }
                                    if($user->dean_principal == "APPROVED" || $user->dean_principal !== "APPROVED"){
                                        $status_total++;
                                    }
                                    if($user->registrar == "APPROVED" || $user->registrar !== "APPROVED"){
                                        $status_total++;
                                    }
                                    if($user->accounting_assessment == "APPROVED" || $user->accounting_assessment !== "APPROVED"){
                                        $status_total++;
                                    }
                                        $pass_approved_total_value =  $approve_count;
                                        $pass_status__total_value = $status_total;
                                    ?>
                                    <?php if($pass_approved_total_value == $pass_status__total_value): ?>
                                        <tr>
                                            
                                            <td><?php echo e($index_count++); ?></td>
                                            <td><?php echo e($user->name); ?></td>
                                                <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($course_id->id == $user->course): ?>
                                                        <td><?php echo e($course_id->course_acronym); ?></td>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <td><?php echo e($user->year_lvl); ?></td>
                                            <td><?php echo e($user->semester); ?></td>
                                            <td><?php echo e($user->school_id); ?></td>
                                            <td style="color: green"><b>Completed</b></td>          
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                <a href="<?php echo e(url ('admin/view-generate-pdf')); ?>" class="btn btn-success" style="float: right"><i class="fa fa-print"></i> Generate PDF</a>
                        </tbody>
                    </table>
                </div>  
            </div>
        </div>
        <div class="clearance_body">
            <div  class="card" style=" border: 2px solid black">
                <div class="card-header">
                    <div class="container">
                        <div class="error">
                            <?php if(count($errors) > 0): ?>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="alert alert-danger" style="text-align: center">
                                        <?php echo e($error); ?>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                    
                            <?php if(session('success')): ?>
                                <div class="alert alert-success" style="text-align: center">
                                    <?php echo e(session('success')); ?>

                                </div>
                            <?php endif; ?>
                    
                            <?php if(session('error')): ?>
                                <div class="alert alert-danger" style="text-align: center">
                                    <?php echo e(session('error')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <h4 style="text-align:center;font-weight: bold;">Student List</h4>
                </div>
                <div  class="card-body">
                    <table class="table table-bordered" style="border: 1px solid black">
                        <thead >
                            <tr >
                                <th>No.</th>
                                <th>Name</th>
                                <th>Course</th>
                                <th>Year Level</th>
                                <th>Semester</th>
                                <th>School ID</th>
                                <th>Clearance</th>
                            </tr>
                        </thead> 
                        <tbody>
                            <?php
                                $index_count = 1;
                            ?> 
                            <?php $__currentLoopData = $complete_request; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $approve_count = 0;
                                    $status_total = 0;
                                ?> 
                                <?php $__currentLoopData = $user->status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instructor_status_count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($instructor_status_count == "APPROVED"): ?>
                                        <?php
                                            $approve_count++;
                                        ?>
                                    <?php endif; ?>
                                    <?php if($instructor_status_count !== "APPROVED" || $instructor_status_count == "APPROVED"): ?>
                                        <?php
                                            $status_total++;
                                        ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                if($user->guidance_councilor == "APPROVED"){
                                    $approve_count++;
                                }
                                if($user->student_org_treasurer == "APPROVED"){
                                    $approve_count++;
                                }
                                if($user->librarian == "APPROVED"){
                                    $approve_count++;
                                }
                                if($user->dean_of_student_affair == "APPROVED"){
                                    $approve_count++;
                                }
                                if($user->dean_principal == "APPROVED"){
                                    $approve_count++;
                                }
                                if($user->registrar == "APPROVED"){
                                    $approve_count++;
                                }
                                if($user->accounting_assessment == "APPROVED"){
                                    $approve_count++;
                                }
                                //
                                if($user->guidance_councilor == "APPROVED" || $user->guidance_councilor !== "APPROVED"){
                                    $status_total++;
                                }
                                if($user->student_org_treasurer == "APPROVED" || $user->student_org_treasurer !== "APPROVED"){
                                    $status_total++;
                                }
                                if($user->librarian == "APPROVED" || $user->librarian !== "APPROVED"){
                                    $status_total++;
                                }
                                if($user->dean_of_student_affair == "APPROVED" || $user->dean_of_student_affair !== "APPROVED"){
                                    $status_total++;
                                }
                                if($user->dean_principal == "APPROVED" || $user->dean_principal !== "APPROVED"){
                                    $status_total++;
                                }
                                if($user->registrar == "APPROVED" || $user->registrar !== "APPROVED"){
                                    $status_total++;
                                }
                                if($user->accounting_assessment == "APPROVED" || $user->accounting_assessment !== "APPROVED"){
                                    $status_total++;
                                }
                                    $pass_approved_total_value =  $approve_count;
                                    $pass_status__total_value = $status_total;
                                ?>
                                <?php if($pass_approved_total_value !== $pass_status__total_value): ?>
                                    <tr>
                                        
                                        <td><?php echo e($index_count++); ?></td>
                                        <td><?php echo e($user->name); ?></td>
                                            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($course_id->id == $user->course): ?>
                                                    <td><?php echo e($course_id->course_acronym); ?></td>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <td><?php echo e($user->year_lvl); ?></td>
                                        <td><?php echo e($user->semester); ?></td>
                                        <td><?php echo e($user->school_id); ?></td>
                                        <td style="color: red"><b>Incomplete</b></td>          
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </tbody>
                </table>
            </div>  
        </div>
    </div>  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Clearance-System\resources\views/admin/print-student-clearance.blade.php ENDPATH**/ ?>