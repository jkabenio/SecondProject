

<?php $__env->startSection('content'); ?>

<style>
    .student_view{
        padding-top: 39px;
    }
    .page-item.active .page-link{
    z-index: 1;
}
</style> 
    <div class="student_view">
        <div  class="card" style=" border: 2px solid black">
            <div class="card-header">
                <div class="container">
                    <div class="error">
                        <?php if(count($errors) > 0): ?>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="alert alert-danger" style="text-align: center">
                                    <?php echo e($error); ?>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                
                        <?php if(session('success')): ?>
                            <div class="alert alert-success" style="text-align: center">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>
                
                        <?php if(session('error')): ?>
                            <div class="alert alert-danger" style="text-align: center">
                                <?php echo e(session('error')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <h4 style="text-align:center;font-weight: bold;">Student List</h4>
            </div>
            <div  class="card-body">
                <table class="table table-bordered" style="border: 1px solid black">
                    <thead >
                        <tr > 
                            
                            <form action="<?php echo e(route('admin.view-student-user')); ?>" method="GET">
                                <?php echo e(csrf_field()); ?>

                                
                                <?php
                                    $result = "";
                                    $id_val = 0;
                                ?>
                                <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(Request::get('course') == $item->id): ?>
                                    <?php
                                    $result = $item->course_acronym;
                                    $id_val =  $item->id;
                                ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="row">
                                    <div class="col-md-2 col-3">
                                        <select name="course" class="form-control">
                                            <?php if(Request::get('course') == null): ?>
                                                <option value="">All Course</option>
                                            <?php endif; ?>
                                            <?php if(Request::get('course') !== null): ?>
                                                <option value="<?php echo e($id_val); ?>" <?php echo e(Request::get('course')); ?>><?php echo e($result); ?></option>
                                            <?php endif; ?>
                                            <?php if(Request::get('course') !== null): ?>
                                            <option value="">All Course</option>
                                        <?php endif; ?>
                                            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($item->id !== $id_val): ?>
                                                    <option  value="<?php echo e($item->id); ?>" <?php echo e(Request::get('course') == 'course' ? 'selected':''); ?>><?php echo e($item->course_acronym); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-2 col-3">
                                        <select name="year_lvl"  class="form-control">
                                            <option value="">All Level</option>
                                            <option value="1st Year" <?php echo e(Request::get('year_lvl') == '1st Year' ? 'selected':''); ?>>1st Year</option>
                                            <option value="2nd Year" <?php echo e(Request::get('year_lvl') == '2nd Year' ? 'selected':''); ?>>2nd Year</option>
                                            <option value="3rd Year" <?php echo e(Request::get('year_lvl') == '3rd Year' ? 'selected':''); ?>>3rd Year</option>
                                            <option value="4th Year" <?php echo e(Request::get('year_lvl') == '4th Year' ? 'selected':''); ?>>4th Year</option>
                                        </select>
                                    </div>
                                    <div style="margin-left: 57.55%">
                                        <button style="width: 100px" type="submit" class="btn btn-primary">Filter</button>
                                    </div>
                                </div>
                            </form>
                            <div  class="col-md-4" style="padding-left: 0px; margin-right: 0px">
                                <input type="search" class="form-control"  name="search" id="admin-student-search" placeholder="Search by: Name or School ID"/>                                              
                            </div>
                            <th>Name</th>
                            <th>Course</th>
                            <th>Year Level</th>
                            <th>School ID</th> 
                            <th>Edit</th>
                            <th>Delete</th>
                        </tr>
                    </thead> 
                    <tbody id="Admin-Student-Content">
                        <?php if(count($student_user)>0): ?>
                            <?php $__currentLoopData = $student_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count_data => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr> 
                                    <td><?php echo e($item->name); ?></td>
                                        <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($course_id->id == $item->course): ?>
                                                <td><?php echo e($course_id->course_acronym); ?></td>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($item->year_lvl); ?></td>
                                    <td><?php echo e($item->school_id); ?></td>
                                    <td>
                                        <a href="<?php echo e(url ('admin/edit-student/'.$item->id)); ?>" ><img class="edit" src="<?php echo e(asset('/img/edit.png')); ?>" alt="Italian Trulli"></a>
                                    </td>
                                    <td>
                                        <a onclick="document.getElementById(<?php echo e($item->id); ?>).style.display='block'" ><img class="edit" src="<?php echo e(asset('/img/delete.png')); ?>" alt="Italian Trulli"></a>
                                    </td>
                                </tr>
                                <div id="<?php echo e($item->id); ?>" class="w3-modal" >
                                    <div class="w3-modal-content" style="width:30%;">
                                        <header class="warning_header">
                                            <span onclick="document.getElementById(<?php echo e($item->id); ?>).style.display='none'"
                                                class="ekis_button w3-display-topright"><b>&times;</b>
                                            </span>
                                            <h2 style="color: rgb(248, 50, 50)"><b>WARNING!</b></h2>
                                        </header> 
                                        <div class="w3-container">
                                            <p style="text-align: left">
                                                Are you sure you want to delete<br>
                                                ID:<b><?php echo e($item->id); ?></b><br>
                                                Student Name:<b><?php echo e($item->name); ?></b><br>
                                                Course ID:<b><?php echo e($item->course); ?></b><br>
                                                Year level:<b><?php echo e($item->year_lvl); ?></b><br>
                                                School ID:<b><?php echo e($item->school_id); ?> ?</b>
                                            </p>
                                        </div>
                                        <footer class="footer_line">
                                            <p class="button_option">
                                                <b>
                                                    <a class="temporary_button" href="<?php echo e(url ('admin/delete-student/'.$item->id)); ?>" >Temporarily!</a>
                                                    <a class="temporary_button" href="<?php echo e(url ('admin/permanent-delete-student/'.$item->id)); ?>" >Permanently!</a>
                                                    <a class="no_button" style="cursor: pointer" onclick="document.getElementById(<?php echo e($item->id); ?>).style.display='none'">NO!</a>      
                                                </b>
                                                </p>       
                                        </footer>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        
                    </tbody>
                </table>
            </div>  
        </div>
    </div>       
    <?php echo $__env->make('admin.user-activity', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Clearance-System\resources\views/admin/view-student-user.blade.php ENDPATH**/ ?>