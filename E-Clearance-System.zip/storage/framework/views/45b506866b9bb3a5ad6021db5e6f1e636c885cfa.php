

<?php $__env->startSection('content'); ?>



<style>

  
    * {
        box-sizing: border-box;
    }
    
    /* Create three equal columns that floats next to each other */
    .column {
        float: left;
        width: 20%;
        height: auto;
        background-color: #e9ecef;
       
    }
    .general_signee_column {
        float: left;
        width: 50%;
        height: auto;
        background-color: #e9ecef;
    }
    
    /* Clear floats after the columns */
    /* .clearance_row:after {
        content: "";
        display: table;
        clear: both;
    } */
    .clearance_row{
        float:right;
        margin-right: 1px;
        height: auto;
        margin-bottom: 20px;
        width: 100% !important;
    }
    p{
        white-space: nowrap; 
        width: auto;
        height: auto; 
        overflow: hidden;
        text-overflow: clip;
        text-align: center;
 
    }
    .signee-description-form-popup {
        display: none;
        position: fixed;
        bottom: 50%;
        right:25%;
        left: 25%;
        border: 3px solid #0800ff;
        z-index: 9;
        background-color: rgb(212, 212, 212);
        width: 50%;
        height: 20%;
        margin-bottom: auto;
      }
      
      /* Add styles to the form container */
      .form-container-activity {
        
        margin: auto !important;
      width: 300px !important;
      height: 300px !important;
      overflow: auto !important;
      /* way to prevent an element from scrolling its parent. */
      overscroll-behavior: contain;
      }
      
      /* Set a style for the submit/login button */
      .form-container-activity .btn_cancel {
        background-color: #04AA6D;
        color: white;
        padding: 16px 20px;
        border: none;
        cursor: pointer;
        width: 100%;
        margin-bottom:10px;
        opacity: 0.8;
      }
      
      /* Add a red background color to the cancel button */
      .form-container-activity .cancel {
        background-color: red;
        width: 50px;
        font-size: 12px;
        height: 24px;
        padding-top: 2px;
        margin-top: 0px;
        margin-bottom: 0px;
        border-radius: 0px;
        margin-left: 250px;
        /* position: fixed; */
      }
    .signee_close_btn{
        float: right;
        background-color: red;
        color: white;
    }
      /* Add some hover effects to buttons */
    .form-container-activity .btn_cancel:hover, .open-button:hover {
        opacity: 1;
    } 
      .btn.cancel{
        background-color: red;
        color: white;
      }
      .signee_description_info{
        height: 100%;
        width: 100%;
      }
select[readonly]
{
    pointer-events: none;
}
/* irrelevent styling */
*[readonly]
{

}
.signee_quick_view_title{
    background-color: rgb(4, 4, 181);
     color: white;
     text-align: center;
     margin-top: 1px;
     padding-top: 10px;
     height: 50px;
     /* border:solid 3px black; */
}
.scroll_div {
        margin-top: 10px;
        margin-bottom: 10px;
        width: 100%;
        height: 400px;
        overflow-x: hidden;
        overflow-y: auto;
        text-align: center;
         border: solid rgb(4, 4, 181) 3px;
      }
</style>


 
 

<h4 class="signee_quick_view_title"><b>Student List</b></h4>
<?php if(session('success')): ?>
    <div style="text-align:center"  class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div style="text-align:center"  class="alert alert-danger"><?php echo e(session('error')); ?></div>
<?php endif; ?>
<form action="<?php echo e(route('signee.quick-view-request')); ?>" method="GET">
    <?php echo e(csrf_field()); ?>

    <?php
        $result = "";
        $id_val = 0;
    ?>
    <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(Request::get('course') == $item->id): ?>
        <?php
        $result = $item->course_acronym;
        $id_val =  $item->id;
    ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
        <div class="col-md-2 col-3">
            <select name="course" class="form-control">
                <?php if(Request::get('course') == null): ?>
                    <option value="">All Course</option>
                <?php endif; ?>
                <?php if(Request::get('course') !== null): ?>
                    <option value="<?php echo e($id_val); ?>" <?php echo e(Request::get('course')); ?>><?php echo e($result); ?></option>
                <?php endif; ?>
                <?php if(Request::get('course') !== null): ?>
                <option value="">All Course</option>
            <?php endif; ?>
                <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->id !== $id_val): ?>
                        <option  value="<?php echo e($item->id); ?>" <?php echo e(Request::get('course') == 'course' ? 'selected':''); ?>><?php echo e($item->course_acronym); ?></option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-2 col-3">
            <select name="year_lvl"  class="form-control">
                <option value="">All Level</option>
                <option value="1st Year" <?php echo e(Request::get('year_lvl') == '1st Year' ? 'selected':''); ?>>1st Year</option>
                <option value="2nd Year" <?php echo e(Request::get('year_lvl') == '2nd Year' ? 'selected':''); ?>>2nd Year</option>
                <option value="3rd Year" <?php echo e(Request::get('year_lvl') == '3rd Year' ? 'selected':''); ?>>3rd Year</option>
                <option value="4th Year" <?php echo e(Request::get('year_lvl') == '4th Year' ? 'selected':''); ?>>4th Year</option>
            </select>
        </div>
        <div>
            <button type="submit" class="btn btn-success quick_signee_filter_btn">Filter</button>
        </div>
    </div>
</form>
<form action="<?php echo e(route('signee.update-multiple-student')); ?>" method="POST">
    <button type="submit" class="btn btn-primary quick_signee_update_btn">Update User</button>
    <?php echo e(csrf_field()); ?>

    <?php echo method_field('PUT'); ?>
    <div class="scroll_div">  
        <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index_count => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php
        $approve_count = 0;
        $approve_total = 0;
       
        foreach($user->status as $status_count)
        {
            if($status_count == "APPROVED")
            {
                $approve_count++;
            }
            if($status_count !== "APPROVED" || $status_count == "APPROVED")
            {
                $approve_total++;
            }
           
        }
            $pass_total_value =  $approve_count;
            $pass_status_value = $approve_total;
            // print_r ($pass_total_value);
    ?>
            <?php if(strcasecmp(Auth::user()->role_as, "Instructor") == 0): ?>
                <?php
                    $stats_count = 0;
                    $total_stats = 0;
                    $total_approved = 0;
                    $passed_names = array();
                    $passed_status = array();
                    
                    foreach ($user->student_signee_names as $signee_list){
                        $value = $signee_list; 
                        array_push($passed_names, $value);
                    }
                    
                    foreach ($user->status as $status_list){
                        $value = $status_list; 
                        array_push($passed_status, $value);
                        $stats_count++;
                    }
                    foreach ($user->status as $loop => $status_list){
                    
                        if(Auth::user()->name == $passed_names[$loop])
                        {
                            if("APPROVED" == $passed_status[$loop])
                            {
                                $total_approved++;
                            }
                        }
                        if(Auth::user()->name == $passed_names[$loop])
                        {
                            if(($passed_status[$loop] == "APPROVED") || ("IN-PROGRESS" == $passed_status[$loop]) || ("COMPLY" == $passed_status[$loop]) || ("REJECTED" == $passed_status[$loop]))
                            {
                                $total_stats++;
                            }
                        }
                        // else{
                        //     $total_stats--;
                        // }
                    }
                    // print_r ($total_approved);
                    // print_r ($total_stats);
                ?>
                <?php if($total_approved !== $total_stats): ?> 
                    
                        <div class="clearance_body"> 
                            <div class="clearance_row">
                                <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($user->course == $course_list->id): ?>
                                    <h5 class="quick_view_table_content_header" style="text-align:center; background-color: blue; color:white"><b><?php echo e($user->name); ?> (<?php echo e($course_list->course_acronym); ?>-<?php echo e($user->year_lvl); ?>) E-Clearance</b></h5>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <p  style="margin: 0px; padding:0px;text-align: left"><input type="checkbox" id="id[<?php echo e($user->id); ?>]" name="id[<?php echo e($user->id); ?>]" value="<?php echo e($user->id); ?>" ></p>
                                <div class="column" >
                                    <h5 class="table_content_header" style="border: 1px solid #000000; text-align:center;"><b>Instructor</b></h5>     
                                        <?php $__currentLoopData = $user->student_signee_names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $signee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div style="border: 1px solid #000000">
                                                <p class="table_content"><?php echo e($signee); ?></p>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                                </div>
                                <div class="column">
                                    <h5 class="table_content_header" style="border: 1px solid #000000; text-align:center;"><b>Subject</b></h5>
                                    
                                        <?php $__currentLoopData = $user->subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div style="border: 1px solid #000000"> 
                                                <p class="table_content"><?php echo e($subject_list); ?></p>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="column" >
                                    <h5 class="table_content_header" style="border: 1px solid #000000; text-align:center;"><b>Section</b></h5>
                                    
                                        <?php $__currentLoopData = $user->student_section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div style="border: 1px solid #000000"> 
                                                <p class="table_content" style="text-align:center;"><?php echo e($section_list); ?></p>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="column" >
                                    <h5 class="table_content_header" style="border: 1px solid #000000; text-align:center;"><b>Status</b></h5>
                                    <?php $__currentLoopData = $user->status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count_data => $status_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                        <div style="border: 1px solid #000000">  
                                            <p  class="table_content" style="text-align:center">
                                                <?php if($status_list == "IN-PROGRESS" && Auth::user()->name == $passed_names[$count_data]): ?>
                                                    <select class="table_content_select" name="status[<?php echo e($user->id); ?>][]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" style="color:blue">
                                                <?php endif; ?>
                                                <?php if($status_list == "COMPLY" && Auth::user()->name == $passed_names[$count_data]): ?>
                                                    <select class="table_content_select" name="status[<?php echo e($user->id); ?>][]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" style="color:orange">
                                                <?php endif; ?>
                                                <?php if($status_list == "REJECTED" && Auth::user()->name == $passed_names[$count_data]): ?>
                                                    <select class="table_content_select" name="status[<?php echo e($user->id); ?>][]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" style="color:red">
                                                <?php endif; ?>
                                                <?php if($status_list == "APPROVED" && Auth::user()->name == $passed_names[$count_data]): ?>
                                                    <select class="table_content_select" name="status[<?php echo e($user->id); ?>][]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" style="color:green">
                                                <?php endif; ?>

                                                <?php if($status_list == "IN-PROGRESS" &&  Auth::user()->name !== $passed_names[$count_data]): ?>
                                                <select class="table_content_select" name="status[<?php echo e($user->id); ?>][]" style="color:blue" readonly tabindex="-1">
                                                <?php endif; ?>
                                                <?php if($status_list == "COMPLY" &&  Auth::user()->name !== $passed_names[$count_data]): ?>
                                                    <select class="table_content_select" name="status[<?php echo e($user->id); ?>][]" style="color:orange" readonly tabindex="-1">
                                                <?php endif; ?>
                                                <?php if($status_list == "REJECTED" &&  Auth::user()->name !== $passed_names[$count_data]): ?>
                                                    <select class="table_content_select" name="status[<?php echo e($user->id); ?>][]" style="color:red" readonly tabindex="-1">
                                                <?php endif; ?>
                                                <?php if($status_list == "APPROVED" &&  Auth::user()->name !== $passed_names[$count_data]): ?> 
                                                    <select class="table_content_select" name="status[<?php echo e($user->id); ?>][]" style="color:green" readonly tabindex="-1">
                                                <?php endif; ?>
                                            
                                                <option style="text-align:center" value="<?php echo e($status_list); ?>"><?php echo e($status_list); ?></option>

                                                <?php if($status_list !== "IN-PROGRESS"): ?>
                                                    <option style="text-align:center; color: blue"value="IN-PROGRESS">IN-PROGRESS</option>
                                                <?php endif; ?>
                                                <?php if($status_list !== "COMPLY"): ?>
                                                    <option style="text-align:center; color: orange"value="COMPLY">COMPLY</option>
                                                <?php endif; ?>
                                                <?php if($status_list !== "APPROVED"): ?>
                                                    <option style="text-align:center; color:green;"value="APPROVED">APPROVED</option>
                                                <?php endif; ?>
                                                <?php if($status_list !== "REJECTED"): ?>
                                                    <option style="text-align:center; color:red"value="REJECTED">REJECTED</option>
                                                <?php endif; ?>
                                                </select>
                                            </p>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="column" >
                                    <h5 class="table_content_header" style="border: 1px solid #000000; text-align:center;"><b>Description</b></h5>
                                        <?php $__currentLoopData = $user->description; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $description_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div style="border: 1px solid #000000;">
                                                <?php if(Auth::user()->name !== $passed_names[$index]): ?>
                                                    <p class="table_content" style="text-align:center;"><a style="color:red">Restricted!</a></p>
                                                <?php endif; ?>
                                                <?php if((Auth::user()->name == $passed_names[$index]) && ($description_list == null)): ?>
                                                    <p class="table_content" style= "text-align:center;"><a onclick="opensigneeForm(<?php echo e($index); ?>,<?php echo e($user->id); ?>)">Add Detail</a></p>
                                                <?php endif; ?>
                                                <?php if((Auth::user()->name == $passed_names[$index]) && ($description_list !== null)): ?>
                                                    <p class="table_content" style="text-align:center;"><a onclick="opensigneeForm(<?php echo e($index); ?>,<?php echo e($user->id); ?>)">View Detail</a></p>
                                                <?php endif; ?>  
                                            </div>
                                            <div class="signee-description-form-popup" id="signeeForm-<?php echo e($index); ?>-<?php echo e($user->id); ?>">
                                                <textarea class="signee_description_info" name="description[<?php echo e($user->id); ?>][]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" value="<?php echo e($description_list); ?>"><?php echo e($description_list); ?></textarea>
                                                <button type="button" class="btn cancel" onclick="closesigneeForm(<?php echo e($index); ?>,<?php echo e($user->id); ?>)">Close</button>  
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
                                </div>
                            </div> 
                        </div>
                    
                <?php endif; ?>
            <?php endif; ?>
            <?php if(strcasecmp(Auth::user()->role_as, "Guidance Counselor") == 0): ?>
                <?php if($user->guidance_councilor !== "APPROVED"): ?>
                    <div class="clearance_body"> 
                        <div class="clearance_row">
                            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($user->course == $course_list->id): ?>
                                <h5 class="quick_view_table_content_header" style="text-align:center; background-color: blue; color:white"><b><?php echo e($user->name); ?> (<?php echo e($course_list->course_acronym); ?>-<?php echo e($user->year_lvl); ?>) E-Clearance</b></h5>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <p  style="margin: 0px; padding:0px;text-align: left"><input type="checkbox" id="id[<?php echo e($user->id); ?>]" name="id[<?php echo e($user->id); ?>]" value="<?php echo e($user->id); ?>" ></p>
                            <div class="general_signee_column" >
                                <h5 class="table_content_header" style="border: 1px solid #000000; text-align:center;"><b>Status</b></h5>
                                    <div style="border: 1px solid #000000">  
                                        <p  class="table_content" style="text-align:center">
                                            <?php if($user->guidance_councilor == "IN-PROGRESS"): ?>
                                                <select class="table_content_select" name="guidance_councilor[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" style="color:blue">
                                            <?php endif; ?>
                                            <?php if($user->guidance_councilor == "COMPLY"): ?>
                                                <select class="table_content_select" name="guidance_councilor[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" style="color:orange">
                                            <?php endif; ?>
                                            <?php if($user->guidance_councilor == "REJECTED"): ?>
                                                <select class="table_content_select" name="guidance_councilor[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" style="color:red">
                                            <?php endif; ?>
                                            <?php if($user->guidance_councilor == "APPROVED"): ?>
                                                <select class="table_content_select" name="guidance_councilor[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" style="color:green">
                                            <?php endif; ?>
                                        
                                                <option style="text-align:center" value="<?php echo e($user->guidance_councilor); ?>"><?php echo e($user->guidance_councilor); ?></option>

                                                <?php if($user->guidance_councilor !== "IN-PROGRESS"): ?>
                                                    <option style="text-align:center; color: blue"value="IN-PROGRESS">IN-PROGRESS</option>
                                                <?php endif; ?>
                                                <?php if($user->guidance_councilor !== "COMPLY"): ?>
                                                    <option style="text-align:center; color: orange"value="COMPLY">COMPLY</option>
                                                <?php endif; ?>
                                                <?php if($user->guidance_councilor !== "APPROVED"): ?>
                                                    <option style="text-align:center; color:green;"value="APPROVED">APPROVED</option>
                                                <?php endif; ?>
                                                <?php if($user->guidance_councilor !== "REJECTED"): ?>
                                                    <option style="text-align:center; color:red"value="REJECTED">REJECTED</option>
                                                <?php endif; ?>
                                            </select>
                                        </p> 
                                    </div>
                            </div>
                            <div class="general_signee_column" >
                                <h5 class="table_content_header" style="border: 1px solid #000000; text-align:center;"><b>Description</b></h5>
                                <div style="border: 1px solid #000000;">
                                    <?php if($user->guidance_councilor_description == null): ?>
                                        <p class="table_content" style= "text-align:center;"><a onclick="open_guidance_councilor_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">Add Details</a></p>
                                    <?php endif; ?>
                                    <?php if($user->guidance_councilor_description == !null): ?>
                                    <p class="table_content" style= "text-align:center;"><a onclick="open_guidance_councilor_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">View Details</a></p>
                                <?php endif; ?> 
                                </div>
                                <div class="signee-description-form-popup" id="guidance_councilor_form-<?php echo e($index_count); ?>-<?php echo e($user->id); ?>">
                                    <textarea class="signee_description_info" name="guidance_councilor_description[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" value="<?php echo e($user->guidance_councilor_description); ?>"><?php echo e($user->guidance_councilor_description); ?></textarea>
                                    <button type="button" class="btn cancel" onclick="close_guidance_councilor_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">Close</button>  
                                </div>   
                            </div>
                        </div> 
                    </div>
                <?php endif; ?>
            <?php endif; ?>
            <?php if(strcasecmp(Auth::user()->role_as, "Student Org. Treasurer") == 0): ?>
                <?php if($user->student_org_treasurer !== "APPROVED"): ?>
                    <?php if(Auth::user()->dept_id == $user->dept_id): ?>
                        <div class="clearance_body"> 
                            <div class="clearance_row">
                                <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($user->course == $course_list->id): ?>
                                    <h5 class="quick_view_table_content_header" style="text-align:center; background-color: blue; color:white"><b><?php echo e($user->name); ?> (<?php echo e($course_list->course_acronym); ?>-<?php echo e($user->year_lvl); ?>) E-Clearance</b></h5>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <p  style="margin: 0px; padding:0px;text-align: left"><input type="checkbox" id="id[<?php echo e($user->id); ?>]" name="id[<?php echo e($user->id); ?>]" value="<?php echo e($user->id); ?>" ></p>
                                <div class="general_signee_column" >
                                    <h5 class="table_content_header" style="border: 1px solid #000000; text-align:center;"><b>Status</b></h5>
                                        <div style="border: 1px solid #000000">  
                                            <p  class="table_content" style="text-align:center">
                                                <?php if($user->student_org_treasurer == "IN-PROGRESS"): ?>
                                                    <select class="table_content_select" name="student_org_treasurer[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" style="color:blue">
                                                <?php endif; ?>
                                                <?php if($user->student_org_treasurer == "COMPLY"): ?>
                                                    <select class="table_content_select" name="student_org_treasurer[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" style="color:orange">
                                                <?php endif; ?>
                                                <?php if($user->student_org_treasurer == "REJECTED"): ?>
                                                    <select class="table_content_select" name="student_org_treasurer[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" style="color:red">
                                                <?php endif; ?>
                                                <?php if($user->student_org_treasurer == "APPROVED"): ?>
                                                    <select class="table_content_select" name="student_org_treasurer[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" style="color:green">
                                                <?php endif; ?>
                                             
                                                    <option style="text-align:center" value="<?php echo e($user->student_org_treasurer); ?>"><?php echo e($user->student_org_treasurer); ?></option>

                                                    <?php if($user->student_org_treasurer !== "IN-PROGRESS"): ?>
                                                        <option style="text-align:center; color: blue"value="IN-PROGRESS">IN-PROGRESS</option>
                                                    <?php endif; ?>
                                                    <?php if($user->student_org_treasurer !== "COMPLY"): ?>
                                                        <option style="text-align:center; color: orange"value="COMPLY">COMPLY</option>
                                                    <?php endif; ?>
                                                    <?php if($user->student_org_treasurer !== "APPROVED"): ?>
                                                        <option style="text-align:center; color:green;"value="APPROVED">APPROVED</option>
                                                    <?php endif; ?>
                                                    <?php if($user->student_org_treasurer !== "REJECTED"): ?>
                                                        <option style="text-align:center; color:red"value="REJECTED">REJECTED</option>
                                                    <?php endif; ?>
                                                </select>
                                            </p> 
                                        </div>
                                </div>
                                <div class="general_signee_column" >
                                    <h5 class="table_content_header" style="border: 1px solid #000000; text-align:center;"><b>Description</b></h5>
                                    <div style="border: 1px solid #000000;">
                                        <?php if($user->student_org_description == null): ?>
                                            <p class="table_content" style= "text-align:center;"><a onclick="open_treasurer_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">Add Details</a></p>
                                        <?php endif; ?>
                                        <?php if($user->student_org_description == !null): ?>
                                        <p class="table_content" style= "text-align:center;"><a onclick="open_treasurer_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">View Details</a></p>
                                    <?php endif; ?> 
                                    </div>
                                    <div class="signee-description-form-popup" id="student_org-<?php echo e($index_count); ?>-<?php echo e($user->id); ?>">
                                        <textarea class="signee_description_info" name="student_org_description[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" value="<?php echo e($user->student_org_description); ?>"><?php echo e($user->student_org_description); ?></textarea>
                                        <button type="button" class="btn cancel" onclick="close_treasurer_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">Close</button>  
                                    </div>   
                                </div>
                            </div> 
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
            <?php if(strcasecmp(Auth::user()->role_as, "Librarian") == 0): ?>
                <?php if($user->librarian !== "APPROVED"&&
                $user->student_org_treasurer == "APPROVED" &&
                $user->guidance_councilor == "APPROVED" &&
                $pass_total_value == $pass_status_value): ?>
                    <div class="clearance_body"> 
                        <div class="clearance_row">
                            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($user->course == $course_list->id): ?>
                                <h5 class="quick_view_table_content_header" style="text-align:center; background-color: blue; color:white"><b><?php echo e($user->name); ?> (<?php echo e($course_list->course_acronym); ?>-<?php echo e($user->year_lvl); ?>) E-Clearance</b></h5>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <p  style="margin: 0px; padding:0px;text-align: left"><input type="checkbox" id="id[<?php echo e($user->id); ?>]" name="id[<?php echo e($user->id); ?>]" value="<?php echo e($user->id); ?>" ></p>
                            <div class="general_signee_column" >
                                <h5 class="table_content_header" style="border: 1px solid #000000; text-align:center;"><b>Status</b></h5>
                                    <div style="border: 1px solid #000000">  
                                        <p  class="table_content" style="text-align:center">
                                            <?php if($user->librarian == "IN-PROGRESS"): ?>
                                                <select class="table_content_select" name="librarian[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" style="color:blue">
                                            <?php endif; ?>
                                            <?php if($user->librarian == "COMPLY"): ?>
                                                <select class="table_content_select" name="librarian[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" style="color:orange">
                                            <?php endif; ?>
                                            <?php if($user->librarian == "REJECTED"): ?>
                                                <select class="table_content_select" name="librarian[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" style="color:red">
                                            <?php endif; ?>
                                            <?php if($user->librarian == "APPROVED"): ?>
                                                <select class="table_content_select" name="librarian[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" style="color:green">
                                            <?php endif; ?>
                                        
                                                <option style="text-align:center" value="<?php echo e($user->librarian); ?>"><?php echo e($user->librarian); ?></option>

                                                <?php if($user->librarian !== "IN-PROGRESS"): ?>
                                                    <option style="text-align:center; color: blue"value="IN-PROGRESS">IN-PROGRESS</option>
                                                <?php endif; ?>
                                                <?php if($user->librarian !== "COMPLY"): ?>
                                                    <option style="text-align:center; color: orange"value="COMPLY">COMPLY</option>
                                                <?php endif; ?>
                                                <?php if($user->librarian !== "APPROVED"): ?>
                                                    <option style="text-align:center; color:green;"value="APPROVED">APPROVED</option>
                                                <?php endif; ?>
                                                <?php if($user->librarian !== "REJECTED"): ?>
                                                    <option style="text-align:center; color:red"value="REJECTED">REJECTED</option>
                                                <?php endif; ?>
                                            </select>
                                        </p> 
                                    </div>
                            </div>
                            <div class="general_signee_column" >
                                <h5 class="table_content_header" style="border: 1px solid #000000; text-align:center;"><b>Description</b></h5>
                                <div style="border: 1px solid #000000;">
                                    <?php if($user->librarian_description == null): ?>
                                        <p class="table_content" style= "text-align:center;"><a onclick="open_librarian_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">Add Details</a></p>
                                    <?php endif; ?>
                                    <?php if($user->librarian_description == !null): ?>
                                    <p class="table_content" style= "text-align:center;"><a onclick="open_librarian_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">View Details</a></p>
                                <?php endif; ?> 
                                </div>
                                <div class="signee-description-form-popup" id="librarian_form-<?php echo e($index_count); ?>-<?php echo e($user->id); ?>">
                                    <textarea class="signee_description_info" name="librarian_description[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" value="<?php echo e($user->librarian_description); ?>"><?php echo e($user->librarian_description); ?></textarea>
                                    <button type="button" class="btn cancel" onclick="close_librarian_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">Close</button>  
                                </div>   
                            </div>
                        </div> 
                    </div>
                <?php endif; ?>
            <?php endif; ?>
            <?php if(strcasecmp(Auth::user()->role_as, "Dean of Student Affair") == 0): ?>
                <?php if($user->dean_of_student_affair !== "APPROVED"&&
                $user->librarian == "APPROVED" &&
                $user->student_org_treasurer == "APPROVED" &&
                $user->guidance_councilor == "APPROVED" &&
                $pass_total_value == $pass_status_value): ?>
                    <div class="clearance_body"> 
                        <div class="clearance_row">
                            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($user->course == $course_list->id): ?>
                                <h5 class="quick_view_table_content_header" style="text-align:center; background-color: blue; color:white"><b><?php echo e($user->name); ?> (<?php echo e($course_list->course_acronym); ?>-<?php echo e($user->year_lvl); ?>) E-Clearance</b></h5>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <p  style="margin: 0px; padding:0px;text-align: left"><input type="checkbox" id="id[<?php echo e($user->id); ?>]" name="id[<?php echo e($user->id); ?>]" value="<?php echo e($user->id); ?>" ></p>
                            <div class="general_signee_column" >
                                <h5 class="table_content_header" style="border: 1px solid #000000; text-align:center;"><b>Status</b></h5>
                                    <div style="border: 1px solid #000000">  
                                        <p  class="table_content" style="text-align:center">
                                            <?php if($user->dean_of_student_affair == "IN-PROGRESS"): ?>
                                                <select class="table_content_select" name="dean_of_student_affair[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" style="color:blue">
                                            <?php endif; ?>
                                            <?php if($user->dean_of_student_affair == "COMPLY"): ?>
                                                <select class="table_content_select" name="dean_of_student_affair[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" style="color:orange">
                                            <?php endif; ?>
                                            <?php if($user->dean_of_student_affair == "REJECTED"): ?>
                                                <select class="table_content_select" name="dean_of_student_affair[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" style="color:red">
                                            <?php endif; ?>
                                            <?php if($user->dean_of_student_affair == "APPROVED"): ?>
                                                <select class="table_content_select" name="dean_of_student_affair[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" style="color:green">
                                            <?php endif; ?>
                                        
                                                <option style="text-align:center" value="<?php echo e($user->dean_of_student_affair); ?>"><?php echo e($user->dean_of_student_affair); ?></option>

                                                <?php if($user->dean_of_student_affair !== "IN-PROGRESS"): ?>
                                                    <option style="text-align:center; color: blue"value="IN-PROGRESS">IN-PROGRESS</option>
                                                <?php endif; ?>
                                                <?php if($user->dean_of_student_affair !== "COMPLY"): ?>
                                                    <option style="text-align:center; color: orange"value="COMPLY">COMPLY</option>
                                                <?php endif; ?>
                                                <?php if($user->dean_of_student_affair !== "APPROVED"): ?>
                                                    <option style="text-align:center; color:green;"value="APPROVED">APPROVED</option>
                                                <?php endif; ?>
                                                <?php if($user->dean_of_student_affair !== "REJECTED"): ?>
                                                    <option style="text-align:center; color:red"value="REJECTED">REJECTED</option>
                                                <?php endif; ?>
                                            </select>
                                        </p> 
                                    </div>
                            </div>
                            <div class="general_signee_column" >
                                <h5 class="table_content_header" style="border: 1px solid #000000; text-align:center;"><b>Description</b></h5>
                                <div style="border: 1px solid #000000;">
                                    <?php if($user->dean_of_student_affair_description == null): ?>
                                        <p class="table_content" style= "text-align:center;"><a onclick="open_studentaffair_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">Add Details</a></p>
                                    <?php endif; ?>
                                    <?php if($user->dean_of_student_affair_description == !null): ?>
                                    <p class="table_content" style= "text-align:center;"><a onclick="open_studentaffair_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">View Details</a></p>
                                <?php endif; ?> 
                                </div>
                                <div class="signee-description-form-popup" id="studentaffair_form-<?php echo e($index_count); ?>-<?php echo e($user->id); ?>">
                                    <textarea class="signee_description_info" name="dean_of_student_affair_description[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" value="<?php echo e($user->dean_of_student_affair_description); ?>"><?php echo e($user->dean_of_student_affair_description); ?></textarea>
                                    <button type="button" class="btn cancel" onclick="close_studentaffair_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">Close</button>  
                                </div>   
                            </div>
                        </div> 
                    </div>
                <?php endif; ?>
            <?php endif; ?>
            <?php if(strcasecmp(Auth::user()->role_as, "Dean Principal") == 0): ?>
                <?php if($user->dean_principal !== "APPROVED" &&
                $user->dean_of_student_affair == "APPROVED" &&
                $user->librarian == "APPROVED" &&
                $user->student_org_treasurer == "APPROVED" &&
                $user->guidance_councilor == "APPROVED" &&
                $pass_total_value == $pass_status_value): ?>
                    <?php if(Auth::user()->dept_id == $user->dept_id): ?>
                        <div class="clearance_body"> 
                            <div class="clearance_row">
                                <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($user->course == $course_list->id): ?>
                                    <h5 class="quick_view_table_content_header" style="text-align:center; background-color: blue; color:white"><b><?php echo e($user->name); ?> (<?php echo e($course_list->course_acronym); ?>-<?php echo e($user->year_lvl); ?>) E-Clearance</b></h5>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <p  style="margin: 0px; padding:0px;text-align: left"><input type="checkbox" id="id[<?php echo e($user->id); ?>]" name="id[<?php echo e($user->id); ?>]" value="<?php echo e($user->id); ?>" ></p>
                                <div class="general_signee_column" >
                                    <h5 class="table_content_header" style="border: 1px solid #000000; text-align:center;"><b>Status</b></h5>
                                        <div style="border: 1px solid #000000">  
                                            <p  class="table_content" style="text-align:center">
                                                <?php if($user->dean_principal == "IN-PROGRESS"): ?>
                                                    <select class="table_content_select" name="dean_principal[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" style="color:blue">
                                                <?php endif; ?>
                                                <?php if($user->dean_principal == "COMPLY"): ?>
                                                    <select class="table_content_select" name="dean_principal[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" style="color:orange">
                                                <?php endif; ?>
                                                <?php if($user->dean_principal == "REJECTED"): ?>
                                                    <select class="table_content_select" name="dean_principal[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" style="color:red">
                                                <?php endif; ?>
                                                <?php if($user->dean_principal == "APPROVED"): ?>
                                                    <select class="table_content_select" name="dean_principal[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" style="color:green">
                                                <?php endif; ?>
                                            
                                                    <option style="text-align:center" value="<?php echo e($user->dean_principal); ?>"><?php echo e($user->dean_principal); ?></option>

                                                    <?php if($user->dean_principal !== "IN-PROGRESS"): ?>
                                                        <option style="text-align:center; color: blue"value="IN-PROGRESS">IN-PROGRESS</option>
                                                    <?php endif; ?>
                                                    <?php if($user->dean_principal !== "COMPLY"): ?>
                                                        <option style="text-align:center; color: orange"value="COMPLY">COMPLY</option>
                                                    <?php endif; ?>
                                                    <?php if($user->dean_principal !== "APPROVED"): ?>
                                                        <option style="text-align:center; color:green;"value="APPROVED">APPROVED</option>
                                                    <?php endif; ?>
                                                    <?php if($user->dean_principal !== "REJECTED"): ?>
                                                        <option style="text-align:center; color:red"value="REJECTED">REJECTED</option>
                                                    <?php endif; ?>
                                                </select>
                                            </p> 
                                        </div>
                                </div>
                                <div class="general_signee_column" >
                                    <h5 class="table_content_header" style="border: 1px solid #000000; text-align:center;"><b>Description</b></h5>
                                    <div style="border: 1px solid #000000;">
                                        <?php if($user->dean_principal_description == null): ?>
                                            <p class="table_content" style= "text-align:center;"><a onclick="open_deanprincipal_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">Add Details</a></p>
                                        <?php endif; ?>
                                        <?php if($user->dean_principal_description == !null): ?>
                                        <p class="table_content" style= "text-align:center;"><a onclick="open_deanprincipal_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">View Details</a></p>
                                    <?php endif; ?> 
                                    </div>
                                    <div class="signee-description-form-popup" id="deanprincipal_form-<?php echo e($index_count); ?>-<?php echo e($user->id); ?>">
                                        <textarea class="signee_description_info" name="dean_principal_description[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" value="<?php echo e($user->dean_principal_description); ?>"><?php echo e($user->dean_principal_description); ?></textarea>
                                        <button type="button" class="btn cancel" onclick="close_deanprincipal_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">Close</button>  
                                    </div>   
                                </div>
                            </div> 
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>
            <?php if(strcasecmp(Auth::user()->role_as, "Registrar") == 0): ?>
                <?php if($user->registrar !== "APPROVED" &&
                $user->dean_principal == "APPROVED" &&
                $user->dean_of_student_affair == "APPROVED" &&
                $user->librarian == "APPROVED" &&
                $user->student_org_treasurer == "APPROVED" &&
                $user->guidance_councilor == "APPROVED" &&
                $pass_total_value == $pass_status_value): ?>
                    <div class="clearance_body"> 
                        <div class="clearance_row">
                            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($user->course == $course_list->id): ?>
                                <h5 class="quick_view_table_content_header" style="text-align:center; background-color: blue; color:white"><b><?php echo e($user->name); ?> (<?php echo e($course_list->course_acronym); ?>-<?php echo e($user->year_lvl); ?>) E-Clearance</b></h5>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <p  style="margin: 0px; padding:0px;text-align: left"><input type="checkbox" id="id[<?php echo e($user->id); ?>]" name="id[<?php echo e($user->id); ?>]" value="<?php echo e($user->id); ?>" ></p>
                            <div class="general_signee_column" >
                                <h5 class="table_content_header" style="border: 1px solid #000000; text-align:center;"><b>Status</b></h5>
                                    <div style="border: 1px solid #000000">  
                                        <p  class="table_content" style="text-align:center">
                                            <?php if($user->registrar == "IN-PROGRESS"): ?>
                                                <select class="table_content_select" name="registrar[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" style="color:blue">
                                            <?php endif; ?>
                                            <?php if($user->registrar == "COMPLY"): ?>
                                                <select class="table_content_select" name="registrar[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" style="color:orange">
                                            <?php endif; ?>
                                            <?php if($user->registrar == "REJECTED"): ?>
                                                <select class="table_content_select" name="registrar[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" style="color:red">
                                            <?php endif; ?>
                                            <?php if($user->registrar == "APPROVED"): ?>
                                                <select class="table_content_select" name="registrar[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" style="color:green">
                                            <?php endif; ?>
                                        
                                                <option style="text-align:center" value="<?php echo e($user->registrar); ?>"><?php echo e($user->registrar); ?></option>

                                                <?php if($user->registrar !== "IN-PROGRESS"): ?>
                                                    <option style="text-align:center; color: blue"value="IN-PROGRESS">IN-PROGRESS</option>
                                                <?php endif; ?>
                                                <?php if($user->registrar !== "COMPLY"): ?>
                                                    <option style="text-align:center; color: orange"value="COMPLY">COMPLY</option>
                                                <?php endif; ?>
                                                <?php if($user->registrar !== "APPROVED"): ?>
                                                    <option style="text-align:center; color:green;"value="APPROVED">APPROVED</option>
                                                <?php endif; ?>
                                                <?php if($user->registrar !== "REJECTED"): ?>
                                                    <option style="text-align:center; color:red"value="REJECTED">REJECTED</option>
                                                <?php endif; ?>
                                            </select>
                                        </p> 
                                    </div>
                            </div>
                            <div class="general_signee_column" >
                                <h5 class="table_content_header" style="border: 1px solid #000000; text-align:center;"><b>Description</b></h5>
                                <div style="border: 1px solid #000000;">
                                    <?php if($user->registrar_description == null): ?>
                                        <p class="table_content" style= "text-align:center;"><a onclick="open_registrar_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">Add Details</a></p>
                                    <?php endif; ?>
                                    <?php if($user->registrar_description == !null): ?>
                                    <p class="table_content" style= "text-align:center;"><a onclick="open_registrar_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">View Details</a></p>
                                <?php endif; ?> 
                                </div>
                                <div class="signee-description-form-popup" id="registrar_form-<?php echo e($index_count); ?>-<?php echo e($user->id); ?>">
                                    <textarea class="signee_description_info" name="registrar_description[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" value="<?php echo e($user->registrar_description); ?>"><?php echo e($user->registrar_description); ?></textarea>
                                    <button type="button" class="btn cancel" onclick="close_registrar_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">Close</button>  
                                </div>   
                            </div>
                        </div> 
                    </div>
                <?php endif; ?>
            <?php endif; ?>
            <?php if(strcasecmp(Auth::user()->role_as, "Accounting Assessment") == 0): ?>
                <?php if(
                    $user->accounting_assessment !== "APPROVED" &&
                    $user->registrar == "APPROVED" &&
                    $user->dean_principal == "APPROVED" &&
                    $user->dean_of_student_affair == "APPROVED" &&
                    $user->librarian == "APPROVED" &&
                    $user->student_org_treasurer == "APPROVED" &&
                    $user->guidance_councilor == "APPROVED" &&
                    $pass_total_value == $pass_status_value): ?>
                    <div class="clearance_body"> 
                        <div class="clearance_row">
                            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($user->course == $course_list->id): ?>
                                <h5 class="quick_view_table_content_header" style="text-align:center; background-color: blue; color:white"><b><?php echo e($user->name); ?> (<?php echo e($course_list->course_acronym); ?>-<?php echo e($user->year_lvl); ?>) E-Clearance</b></h5>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            <p  style="margin: 0px; padding:0px;text-align: left"><input type="checkbox" id="id[<?php echo e($user->id); ?>]" name="id[<?php echo e($user->id); ?>]" value="<?php echo e($user->id); ?>" ></p>
                            <div class="general_signee_column" >
                                <h5 class="table_content_header" style="border: 1px solid #000000; text-align:center;"><b>Status</b></h5>
                                    <div style="border: 1px solid #000000">  
                                        <p  class="table_content" style="text-align:center">
                                            <?php if($user->accounting_assessment == "IN-PROGRESS"): ?>
                                                <select class="table_content_select" name="accounting_assessment[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" style="color:blue">
                                            <?php endif; ?>
                                            <?php if($user->accounting_assessment == "COMPLY"): ?>
                                                <select class="table_content_select" name="accounting_assessment[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" style="color:orange">
                                            <?php endif; ?>
                                            <?php if($user->accounting_assessment == "REJECTED"): ?>
                                                <select class="table_content_select" name="accounting_assessment[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" style="color:red">
                                            <?php endif; ?>
                                            <?php if($user->accounting_assessment == "APPROVED"): ?>
                                                <select class="table_content_select" name="accounting_assessment[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" style="color:green">
                                            <?php endif; ?>
                                        
                                                <option style="text-align:center" value="<?php echo e($user->accounting_assessment); ?>"><?php echo e($user->accounting_assessment); ?></option>

                                                <?php if($user->accounting_assessment !== "IN-PROGRESS"): ?>
                                                    <option style="text-align:center; color: blue"value="IN-PROGRESS">IN-PROGRESS</option>
                                                <?php endif; ?>
                                                <?php if($user->accounting_assessment !== "COMPLY"): ?>
                                                    <option style="text-align:center; color: orange"value="COMPLY">COMPLY</option>
                                                <?php endif; ?>
                                                <?php if($user->accounting_assessment !== "APPROVED"): ?>
                                                    <option style="text-align:center; color:green;"value="APPROVED">APPROVED</option>
                                                <?php endif; ?>
                                                <?php if($user->accounting_assessment !== "REJECTED"): ?>
                                                    <option style="text-align:center; color:red"value="REJECTED">REJECTED</option>
                                                <?php endif; ?>
                                            </select>
                                        </p> 
                                    </div>
                            </div>
                            <div class="general_signee_column" >
                                <h5 class="table_content_header" style="border: 1px solid #000000; text-align:center;"><b>Description</b></h5>
                                <div style="border: 1px solid #000000;">
                                    <?php if($user->accounting_assessment_description == null): ?>
                                        <p class="table_content" style= "text-align:center;"><a onclick="open_assessment_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">Add Details</a></p>
                                    <?php endif; ?>
                                    <?php if($user->accounting_assessment_description == !null): ?>
                                    <p class="table_content" style= "text-align:center;"><a onclick="open_assessment_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">View Details</a></p>
                                <?php endif; ?> 
                                </div>
                                <div class="signee-description-form-popup" id="assessment_form-<?php echo e($index_count); ?>-<?php echo e($user->id); ?>">
                                    <textarea class="signee_description_info" name="accounting_assessment_description[<?php echo e($user->id); ?>]" onchange="OnChangeHandler(<?php echo e($user->id); ?>)" value="<?php echo e($user->accounting_assessment_description); ?>"><?php echo e($user->accounting_assessment_description); ?></textarea>
                                    <button type="button" class="btn cancel" onclick="close_assessment_Form(<?php echo e($index_count); ?>,<?php echo e($user->id); ?>)">Close</button>  
                                </div>   
                            </div>
                        </div> 
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</form>
<script>
    function OnChangeHandler(userId) {
        document.getElementById(`id[${userId}]`).checked = true;
    }
    </script> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.signee-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Clearance-System\resources\views/signee/quick-view-request.blade.php ENDPATH**/ ?>