

<?php $__env->startSection('content'); ?>
<style>
    label{
        
        float: left;
        text-align: left;
    }
    p{
        text-align:left;
    }
    td{
        white-space:nowrap;
        text-overflow:ellipsis; 
        overflow:hidden;
        
    }
    * {
        box-sizing: border-box;
    }
    
    /* Create three equal columns that floats next to each other */
    .column {
        float: left;
        width: 195px;
    }
    
    /* Clear floats after the columns */
    .clearance_row:after {
        content: "";
        display: table;
        clear: both;
    }
    .clearance_row{
        float:right;
        margin-right: 1px;
        border: 2px solid;
        height: auto;
        margin-bottom: 20px;
    }
    p{
        white-space: nowrap; 
        width: 186px;
        height: 60px; 
        overflow: hidden;
        text-overflow: clip;
        text-align: center;
        padding-top: 20px; 
    }
    h3{
        margin: 0px;
    }
    
    </style>



<style>
    .form-popup {
        display: none;
        position: fixed;
        bottom: 300px;
        right: 250px;
        border: 3px solid #0800ff;
        z-index: 9;
        background-color: rgb(212, 212, 212);
        width: 500px;
        margin-bottom: auto;
      }
      
      /* Add styles to the form container */
      .form-container-activity {
        
        margin: auto !important;
      width: 300px !important;
      height: 300px !important;
      overflow: auto !important;
      /* way to prevent an element from scrolling its parent. */
      overscroll-behavior: contain;
      }
      
      /* Set a style for the submit/login button */
      .form-container-activity .btn_cancel {
        background-color: #04AA6D;
        color: white;
        padding: 16px 20px;
        border: none;
        cursor: pointer;
        width: 100%;
        margin-bottom:10px;
        opacity: 0.8;
      } 
      
      /* Add a red background color to the cancel button */
      .form-container-activity .cancel {
        background-color: red;
        width: 50px;
        font-size: 12px;
        height: 24px;
        padding-top: 2px;
        margin-top: 0px;
        margin-bottom: 0px;
        border-radius: 0px;
        margin-left: 250px;
        /* position: fixed; */
      }
      
      /* Add some hover effects to buttons */
      .form-container-activity .btn_cancel:hover, .open-button:hover {
        opacity: 1;
      } 
       /* Remove scrollbar space */
        /* Optional: just make scrollbar invisible */
  
      .btn.cancel{
      
        background-color: red;
        color: white;
      }
      .description_info{
        height: 155px;
        width: 490px;
      }
    </style>

<?php if(strcasecmp(Auth::user()->role_as, "Instructor") == 0): ?>
    <div   class="clearance_body_admin">
        <div  class="card" style="width:99%; border: 2px solid black">
            <div class="card-header">
                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                <?php endif; ?>
                <h4>Student List</h4>
            </div>
            <div  class="card-body" >
                <table  style=" border: 1px solid black; overflow-x:auto;">
                    <thead >
                        <tr >
                            <?php echo Form::open(['action' => 'App\Http\Controllers\Signee\SearchController@index', 'method' => 'GET', 'enctype' => 'multipart/form-data']); ?>

                                <?php echo e(csrf_field()); ?>

                                <div  class="col-md-4" style="padding-left: 0px; margin-right: 0px">
                                    <input type="text" class="form-control"value="" name="query" id="query" placeholder="Search by: Name or School ID"/>                                
                                </div>
                            
                            <?php echo Form::close(); ?>                  
                                <th >Name</th>
                                <th >Course</th>
                                <th >Year Level</th>                              
                                <th >Edit</th>
                        </tr>
                    </thead> 
                    <tbody id="tbody">
                        <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(Auth::user()->dept_id == $item->dept_id): ?>
                                <?php $__currentLoopData = $item->student_signee_names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <?php if($name_list == Auth::user()->name ): ?> 
                                            <td><?php echo e($item->name); ?></td>
                                            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($course_list->id == $item->course): ?>
                                                    <td><?php echo e($course_list->course_acronym); ?></td>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <td><?php echo e($item->year_lvl); ?></td>
                                            <td>
                                                <a href="<?php echo e(url ('signee/edit-student/'.$item->id)); ?>" ><img class="edit" src="/img/edit.png" alt="Italian Trulli"></a>
                                            </td>
                                            <?php break; ?>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>     
        </div>
    </div>    
<?php endif; ?>


<?php if(strcasecmp(Auth::user()->role_as,'Student Org. Treasurer') == 0): ?>
    <div   class="clearance_body_admin">
        <div  class="card" style="width:99%; border: 2px solid black">
            <div class="card-header">
                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                <?php endif; ?>
                <h4>Student List</h4>
            </div>
            <div  class="card-body">
                <table class="table table-bordered" style="width:900px; border: 1px solid black">
                    <thead >
                        <tr width="50%">
                            <?php echo Form::open(['action' => 'App\Http\Controllers\Signee\SearchController@index', 'method' => 'GET', 'enctype' => 'multipart/form-data']); ?>

                                <?php echo e(csrf_field()); ?>

                                <div  class="col-md-4" style="padding-left: 0px; margin-right: 0px">
                                    <input type="text" class="form-control"value="" name="query" id="query" placeholder="Search by: Name or School ID"/>                                
                                </div>
                            
                            <?php echo Form::close(); ?> 
                            <th width="5%">Name</th>
                            <th width="4%">Course</th>
                            <th width="3%">Year Level</th>                              
                            <th width="2%">Edit</th>
                        </tr>
                    </thead> 
                    <tbody id="tbody">
                        
                        <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(Auth::user()->dept_id == $item->dept_id): ?>
                                <?php
                                    $approve_count = 0;
                                    $approve_total = 0;
                                 ?>
                                <?php $__currentLoopData = $item->status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status_count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($status_count == "APPROVED"): ?>
                                        <?php
                                            $approve_count++;
                                        ?>
                                    <?php endif; ?>
                                    <?php if($status_count !== "APPROVED" || $status_count == "APPROVED"): ?>
                                        <?php
                                            $approve_total++;
                                        ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $pass_total_value =  $approve_count;
                                    $pass_status_value = $approve_total;
                                ?>
                                <?php if($pass_total_value == $pass_status_value): ?>
                                        <?php if($item->student_org_treasurer !== "APPROVED"): ?>
                                        <tr> 
                                            <td><?php echo e($item->name); ?></td>
                                            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($course_list->id == $item->course): ?>
                                                    <td><?php echo e($course_list->course_acronym); ?></td>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <td><?php echo e($item->year_lvl); ?></td>
                                                <td> 
                                                    <a href="<?php echo e(url ('signee/edit-student/'.$item->id)); ?>" ><img class="edit" src="/img/edit.png" alt="Italian Trulli"></a>
                                                </td>
                                        <?php endif; ?> 
                                        </tr>
                                    <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>     
        </div>
    </div>    
<?php endif; ?>


<?php if(strcasecmp(Auth::user()->role_as,'Dean Principal') == 0): ?>
    <div   class="clearance_body_admin">
        <div  class="card" style="width:99%; border: 2px solid black">
            <div class="card-header">
                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                <?php endif; ?>
                <h4>Student List</h4>
            </div>
            <div  class="card-body">
                <table class="table table-bordered" style="width:900px; border: 1px solid black">
                    <thead >
                        <tr >
                            <?php echo Form::open(['action' => 'App\Http\Controllers\Signee\SearchController@index', 'method' => 'GET', 'enctype' => 'multipart/form-data']); ?>

                                <?php echo e(csrf_field()); ?>

                                <div  class="col-md-4" style="padding-left: 0px; margin-right: 0px">
                                    <input type="text" class="form-control"value="" name="query" id="query" placeholder="Search by: Name or School ID"/>                                
                                </div>
                            
                            <?php echo Form::close(); ?> 
                            <th>Name</th>
                            <th>Course</th>
                            <th>Year Level</th>                              
                            <th>Edit</th>
                        </tr>
                    </thead> 
                    <tbody id="tbody">
                        
                        <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(Auth::user()->dept_id == $item->dept_id): ?>
                                <?php
                                    $approve_count = 0;
                                    $approve_total = 0;
                                 ?>
                                <?php $__currentLoopData = $item->status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status_count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($status_count == "APPROVED"): ?>
                                        <?php
                                            $approve_count++;
                                        ?>
                                    <?php endif; ?>
                                    <?php if($status_count !== "APPROVED" || $status_count == "APPROVED"): ?>
                                        <?php
                                            $approve_total++;
                                        ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $pass_total_value =  $approve_count;
                                    $pass_status_value = $approve_total;
                                ?>
                                <?php if($pass_total_value == $pass_status_value): ?>
                                        <?php if($item->student_org_treasurer == "APPROVED" && $item->dean_principal !== "APPROVED" && $item->librarian == "APPROVED" && $item->guidance_councilor == "APPROVED" && $item->dean_of_student_affair == "APPROVED"): ?>
                                        <tr> 
                                            <td><?php echo e($item->name); ?></td>
                                            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($course_list->id == $item->course): ?>
                                                    <td><?php echo e($course_list->course_acronym); ?></td>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <td><?php echo e($item->year_lvl); ?></td>
                                                <td> 
                                                    <a href="<?php echo e(url ('signee/edit-student/'.$item->id)); ?>" ><img class="edit" src="/img/edit.png" alt="Italian Trulli"></a>
                                                </td>
                                        <?php endif; ?> 
                                        </tr>
                                    <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>     
        </div>
    </div>    
<?php endif; ?>
<?php if(strcasecmp(Auth::user()->role_as,'Guidance Counselor') == 0): ?>
    <div   class="clearance_body_admin">
        <div  class="card" style="width:99%; border: 2px solid black">
            <div class="card-header">
                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                <?php endif; ?>
                <h4>Student List</h4>
            </div>
            <div  class="card-body">
                <table class="table table-bordered" style="width:900px; border: 1px solid black">
                    <thead >
                        <tr >
                            <?php echo Form::open(['action' => 'App\Http\Controllers\Signee\SearchController@index', 'method' => 'GET', 'enctype' => 'multipart/form-data']); ?>

                                <?php echo e(csrf_field()); ?>

                                <div  class="col-md-4" style="padding-left: 0px; margin-right: 0px">
                                    <input type="text" class="form-control"value="" name="query" id="query" placeholder="Search by: Name or School ID"/>                                
                                </div>
                            
                            <?php echo Form::close(); ?> 
                            <th>Name</th>
                            <th>Course</th>
                            <th>Year Level</th>                              
                            <th>Edit</th>
                        </tr>
                    </thead> 
                    <tbody id="tbody">
                        
                        <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item->guidance_councilor !== "APPROVED"): ?>    
                                <tr> 
                                    <td><?php echo e($item->name); ?></td>
                                    <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($course_list->id == $item->course): ?>
                                            <td><?php echo e($course_list->course_acronym); ?></td>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <td><?php echo e($item->year_lvl); ?></td>
                                        <td> 
                                            <a href="<?php echo e(url ('signee/edit-student/'.$item->id)); ?>" ><img class="edit" src="/img/edit.png" alt="Italian Trulli"></a>   
                                        </td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>     
        </div>
    </div>    
<?php endif; ?>

<?php if(strcasecmp(Auth::user()->role_as,'Dean of Student Affair') == 0): ?>
    <div   class="clearance_body_admin">
        <div  class="card" style="width:99%; border: 2px solid black">
            <div class="card-header">
                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                <?php endif; ?>
                <h4>Student List</h4>
            </div>
            <div  class="card-body">
                <table class="table table-bordered" style="width:900px; border: 1px solid black">
                    <thead >
                        <tr >
                            <?php echo Form::open(['action' => 'App\Http\Controllers\Signee\SearchController@index', 'method' => 'GET', 'enctype' => 'multipart/form-data']); ?>

                                <?php echo e(csrf_field()); ?>

                                <div  class="col-md-4" style="padding-left: 0px; margin-right: 0px">
                                    <input type="text" class="form-control"value="" name="query" id="query" placeholder="Search by: Name or School ID"/>                                
                                </div>
                            
                            <?php echo Form::close(); ?> 
                            <th>Name</th>
                            <th>Course</th>
                            <th>Year Level</th>                              
                            <th>Edit</th>
                        </tr>
                    </thead> 
                    <tbody id="tbody">
                        
                        <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $approve_count = 0;
                                    $approve_total = 0;
                                 ?>
                                <?php $__currentLoopData = $item->status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status_count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($status_count == "APPROVED"): ?>
                                        <?php
                                            $approve_count++;
                                        ?>
                                    <?php endif; ?>
                                    <?php if($status_count !== "APPROVED" || $status_count == "APPROVED"): ?>
                                        <?php
                                            $approve_total++;
                                        ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $pass_total_value =  $approve_count;
                                    $pass_status_value = $approve_total;
                                ?>
                                <?php if($pass_total_value == $pass_status_value): ?>
                                    <?php if($item->student_org_treasurer == "APPROVED" && $item->dean_principal == "APPROVED" && $item->guidance_councilor == "APPROVED" && $item->librarian == "APPROVED" && $item->dean_of_student_affair !== "APPROVED"): ?>
                                        <tr> 
                                            <td><?php echo e($item->name); ?></td>
                                            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($course_list->id == $item->course): ?>
                                                    <td><?php echo e($course_list->course_acronym); ?></td>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <td><?php echo e($item->year_lvl); ?></td>
                                            <td> 
                                                <a href="<?php echo e(url ('signee/edit-student/'.$item->id)); ?>" ><img class="edit" src="/img/edit.png" alt="Italian Trulli"></a>
                                            </td>
                                        </tr>
                                    <?php endif; ?> 
                                 <?php endif; ?>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>     
        </div>
    </div>    
<?php endif; ?>
<?php if(strcasecmp(Auth::user()->role_as,'Registrar') == 0): ?>
    <div   class="clearance_body_admin">
        <div  class="card" style="width:99%; border: 2px solid black">
                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                <?php endif; ?>
            <div class="card-header">
                <h4>Student List</h4>
            </div>
            <div  class="card-body">
                <table class="table table-bordered" style="width:900px; border: 1px solid black">
                    <thead >
                        <tr >
                            <?php echo Form::open(['action' => 'App\Http\Controllers\Signee\SearchController@index', 'method' => 'GET', 'enctype' => 'multipart/form-data']); ?>

                                <?php echo e(csrf_field()); ?>

                                <div  class="col-md-4" style="padding-left: 0px; margin-right: 0px">
                                    <input type="text" class="form-control"value="" name="query" id="query" placeholder="Search by: Name or School ID"/>                                
                                </div>
                            
                            <?php echo Form::close(); ?> 
                            <th>Name</th>
                            <th>Course</th>
                            <th>Year Level</th>                              
                            <th>Edit</th>
                        </tr>
                    </thead> 
                    <tbody id="tbody">
                        
                        <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $approve_count = 0;
                                    $approve_total = 0;
                                 ?>
                                <?php $__currentLoopData = $item->status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status_count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($status_count == "APPROVED"): ?>
                                        <?php
                                            $approve_count++;
                                        ?>
                                    <?php endif; ?>
                                    <?php if($status_count !== "APPROVED" || $status_count == "APPROVED"): ?>
                                        <?php
                                            $approve_total++;
                                        ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $pass_total_value =  $approve_count;
                                    $pass_status_value = $approve_total;
                                ?>
                                <?php if($pass_total_value == $pass_status_value): ?>
                                    <?php if($item->student_org_treasurer == "APPROVED" && $item->dean_principal == "APPROVED" && $item->guidance_councilor == "APPROVED" && $item->librarian == "APPROVED" && $item->dean_of_student_affair == "APPROVED" && $item->registrar !== "APPROVED"): ?>
                                        <tr> 
                                            <td><?php echo e($item->name); ?></td>
                                            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($course_list->id == $item->course): ?>
                                                    <td><?php echo e($course_list->course_acronym); ?></td>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <td><?php echo e($item->year_lvl); ?></td>
                                            <td> 
                                                <a href="<?php echo e(url ('signee/edit-student/'.$item->id)); ?>" ><img class="edit" src="/img/edit.png" alt="Italian Trulli"></a>
                                            </td>
                                        </tr>
                                    <?php endif; ?> 
                                 <?php endif; ?>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>     
        </div>
    </div>    
<?php endif; ?>
<?php if(strcasecmp(Auth::user()->role_as,'Accounting Assessment') == 0): ?>
    <div   class="clearance_body_admin">
        <div  class="card" style="width:99%; border: 2px solid black">
            <div class="card-header">
                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                <?php endif; ?>
                <h4>Student List</h4>
            </div>
            <div  class="card-body">
                <table class="table table-bordered" style="width:900px; border: 1px solid black">
                    <thead >
                        <tr >
                            <?php echo Form::open(['action' => 'App\Http\Controllers\Signee\SearchController@index', 'method' => 'GET', 'enctype' => 'multipart/form-data']); ?>

                                <?php echo e(csrf_field()); ?>

                                <div  class="col-md-4" style="padding-left: 0px; margin-right: 0px">
                                    <input type="text" class="form-control"value="" name="query" id="query" placeholder="Search by: Name or School ID"/>                                
                                </div>
                            
                            <?php echo Form::close(); ?> 
                            <th>Name</th>
                            <th>Course</th>
                            <th>Year Level</th>                              
                            <th>Edit</th>
                        </tr>
                    </thead> 
                    <tbody id="tbody">
                        
                        <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $approve_count = 0;
                                    $approve_total = 0;
                                 ?>
                                <?php $__currentLoopData = $item->status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status_count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($status_count == "APPROVED"): ?>
                                        <?php
                                            $approve_count++;
                                        ?>
                                    <?php endif; ?>
                                    <?php if($status_count !== "APPROVED" || $status_count == "APPROVED"): ?>
                                        <?php
                                            $approve_total++;
                                        ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $pass_total_value =  $approve_count;
                                    $pass_status_value = $approve_total;
                                ?>
                                <?php if($pass_total_value == $pass_status_value): ?>
                                    <?php if($item->student_org_treasurer == "APPROVED" && $item->dean_principal == "APPROVED" && $item->guidance_councilor == "APPROVED" && $item->librarian == "APPROVED" && $item->dean_of_student_affair == "APPROVED" && $item->registrar == "APPROVED" && $item->accounting_assessment !== "APPROVED"): ?>
                                        <tr> 
                                            <td><?php echo e($item->name); ?></td>
                                            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($course_list->id == $item->course): ?>
                                                    <td><?php echo e($course_list->course_acronym); ?></td>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <td><?php echo e($item->year_lvl); ?></td>
                                            <td> 
                                                <a href="<?php echo e(url ('signee/edit-student/'.$item->id)); ?>" ><img class="edit" src="/img/edit.png" alt="Italian Trulli"></a>
                                            </td>
                                        </tr>
                                    <?php endif; ?> 
                                 <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>     
        </div>
    </div>
<?php endif; ?>   
    <?php if(strcasecmp(Auth::user()->role_as,'Librarian') == 0): ?>
    <div   class="clearance_body_admin">
        <div  class="card" style="width:99%; border: 2px solid black">
            <div class="card-header">
                <h4>Student List</h4>
            </div>
            <div  class="card-body">
                <table class="table table-bordered" style="width:900px; border: 1px solid black">
                    <thead >
                        <tr >
                            <?php echo Form::open(['action' => 'App\Http\Controllers\Signee\SearchController@index', 'method' => 'GET', 'enctype' => 'multipart/form-data']); ?>

                                <?php echo e(csrf_field()); ?>

                                <div  class="col-md-4" style="padding-left: 0px; margin-right: 0px">
                                    <input type="text" class="form-control"value="" name="query" id="query" placeholder="Search by: Name or School ID"/>                                
                                </div>
                            
                            <?php echo Form::close(); ?> 
                            <th>Name</th>
                            <th>Course

                            </th>
                            <th>Year Level</th>                              
                            <th>Status</th>
                            <th>Description</th>
                        </tr>
                    </thead> 
                    <tbody id="tbody">
                        
                        <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $approve_count = 0;
                                    $approve_total = 0;
                                 ?>
                                <?php $__currentLoopData = $item->status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status_count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($status_count == "APPROVED"): ?>
                                        <?php
                                            $approve_count++;
                                        ?>
                                    <?php endif; ?>
                                    <?php if($status_count !== "APPROVED" || $status_count == "APPROVED"): ?>
                                        <?php
                                            $approve_total++;
                                        ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $pass_total_value =  $approve_count;
                                    $pass_status_value = $approve_total;
                                ?>
                                <?php if($pass_total_value == $pass_status_value): ?>
                                    <?php if($item->student_org_treasurer == "APPROVED"  && $item->guidance_councilor == "APPROVED" && $item->librarian !== "APPROVED"): ?>
                                        <tr> 
                                            <td><?php echo e($item->name); ?></td>
                                            <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($course_list->id == $item->course): ?>
                                                    <td><?php echo e($course_list->course_acronym); ?></td>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <td><?php echo e($item->year_lvl); ?></td>

                                            <td> <?php if($item->librarian == "IN-PROGRESS"): ?>
                                                <select name="accounting_assessment" style="color:blue">
                                                <?php endif; ?>
                                                <?php if($item->librarian == "COMPLY"): ?>
                                                <select name="accounting_assessment" style="color:orange">
                                                <?php endif; ?>
                                                <?php if($item->librarian == "REJECTED"): ?>
                                                <select name="accounting_assessment" style="color:red">
                                                <?php endif; ?>
                                                <?php if($item->librarian == "APPROVED"): ?>
                                                <select name="accounting_assessment" style="color:green">
                                                <?php endif; ?>
                                                <option style="text-align:center" value="<?php echo e($item->accounting_assessment); ?>"><?php echo e($item->accounting_assessment); ?></option>

                                                <?php if($item->librarian !== "IN-PROGRESS"): ?>
                                                <option style="text-align:center; color: blue"value="IN-PROGRESS">IN-PROGRESS</option>
                                                <?php endif; ?>
                                                <?php if($item->librarian !== "COMPLY"): ?>
                                                <option style="text-align:center; color: orange"value="COMPLY">COMPLY</option>
                                                <?php endif; ?>
                                                <?php if($item->librarian !== "APPROVED"): ?>
                                                <option style="text-align:center; color:green;"value="APPROVED">APPROVED</option>
                                                <?php endif; ?>
                                                <?php if($item->librarian !== "REJECTED"): ?>
                                                <option style="text-align:center; color:red"value="REJECTED">REJECTED</option>
                                                <?php endif; ?>
                                                </select>
                                            
                                            </td>
                                            <td> 
                                                <?php if($item->librarian_description !== null): ?>  
                                                    <a onclick="openForm()">View Detail</a>
                                                <?php endif; ?>
                                                <?php if($item->librarian_description == null): ?>  
                                                    <a onclick="openForm()">Add Detail</a>
                                                <?php endif; ?>
                                                <div class="form-popup" id="myForm">
                                                    <textarea class="description_info" name="librarian_description" value="<?php echo e($item->librarian_description); ?>"><?php echo e($item->librarian_description); ?></textarea>                                               
                                                    <button type="submit" class="btn cancel" style="background-color: #0800ff">Update User</button>
                                                    <button type="button" class="btn cancel" onclick="closeForm()">Close</button>                           
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endif; ?> 
                                <?php endif; ?>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>     
        </div>
    </div>  
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.signee-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Clearance-System\resources\views/signee/view-pending-request.blade.php ENDPATH**/ ?>