<?php $__env->startSection('content'); ?>

<div class="dashboard_view">
    <div class="card" >
        <div class="card-header" style="text-align: center"><b>ADMIN DASHBOARD</b></div>
        <div class="container">
            <div class="error">
                <?php if(count($errors) > 0): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger" style="text-align: center">
                            <?php echo e($error); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
         
                <?php if(session('success')): ?>
                    <div class="alert alert-success" style="text-align: center">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
        
                <?php if(session('error')): ?>
                    <div class="alert alert-danger" style="text-align: center">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?> 
            </div>
        </div> 
        <div class="first_row" style="margin-top: 5%;z-index: 0"> 
            <div class="two_column">
                <div class="card bg-primary text-white mb-4" >                       
                        <div class="cards_logo"><img class="image_design" src="<?php echo e(asset('/img/people.png')); ?>" alt="Italian Trulli"></div>
                        <p class="users_count"><b><?php echo e($total_users); ?>&nbsp;Users</b></p>
                        <p class="description">You have <?php echo e($total_users); ?> users in the database.<br>
                                this are the sum of all student, signee, and admin user.</p>
                    <div class="card-footer d-flex align-items-center justify-content-between">
                        <a class="small text-white" href="#"></a>
                        <div class="small text-white"><i class="fa fa-caret-down"></i></div>
                    </div>
                </div>
            </div>
           <style>
            .view_details:hover{
                color:rgb(3, 3, 201) !important;
                background-color:rgba(0, 0, 255, 0);
            }
            .view_details{
                font-size: 80%;
                color:white;
            }
           </style>
            <div class="two_column">
                <div class="card  text-white mb-4" style="background-color: brown">
                    <div class="cards_logo"><img class="image_design" src="<?php echo e(asset('/img/students.png')); ?>" alt="Italian Trulli" style="width: 75px; height: 75px; padding-top: 10px;"></div>
                    <p class="users_count"><b><?php echo e($student); ?>&nbsp;Students</b></p>
                    <p class="description">You have <?php echo e($student); ?> students in the database.<br>
                    Click the link below to view all the students.</p>
                    <div class="card-footer d-flex align-items-center justify-content-between">
                        <a class="view_details" href="<?php echo e(url('/admin/view-student-user')); ?>">View Details</a>
                        <div class="small text-white"><i class="fa fa-caret-down"></i></div>
                    </div>
                </div>
            </div>
 
            <div class="two_column">
                <div class="card text-white mb-4" style="background-color: rgb(86, 5, 124)">
                    <div class="cards_logo"><img class="image_design" src="<?php echo e(asset('/img/signature.png')); ?>" alt="Italian Trulli"></div>
                        <p class="users_count"><b><?php echo e($signee); ?>&nbsp;Signee</b></p>
                        <p class="description">You have <?php echo e($signee); ?> signees in the database.<br>
                         Click the link below to view all the signee.</p>
                    <div class="card-footer d-flex align-items-center justify-content-between">
                        <a class="view_details" href="<?php echo e(url('/admin/view-signee-user')); ?>">View Details</a>
                        <div class="small text-white"><i class="fa fa-caret-down"></i></div>
                    </div>
                </div>
            </div>
 
            <div class="two_column">
                <div class="card bg-warning text-white mb-4">
                    <div class="cards_logo"><img class="image_design" src="<?php echo e(asset('/img/request.png')); ?>" alt="Italian Trulli" style="width: 65px; height: 65px; padding-top: 15px; margin-left: 10px;"></div>
                        <p class="users_count"><b><?php echo e($results); ?>&nbsp;Request</b></p>
                        <p class="description">There are <?php echo e($results); ?> request.<br>
                         Click the link below to view all the pending request.</p>
                    <div class="card-footer d-flex align-items-center justify-content-between">
                        <a class="view_details" href="<?php echo e(url('/admin/view-pending-request')); ?>">View Details</a>
                        <div class="small text-white"><i class="fa fa-caret-down"></i></div>
                    </div>
                </div>
            </div>
            <div class="two_column">
                <div class="card bg-success text-white mb-4">
                    <div class="cards_logo"><img class="ollcf_logo_css" src="<?php echo e(asset('/img/school.png')); ?>" alt="Italian Trulli" style="width: 60px; height: 50px; margin-top: 12px"></div>
                        <p class="users_count"><b><?php echo e($department); ?>&nbsp;Department</b></p>
                        <p class="description">You have <?php echo e($department); ?> department in the database.<br>
                         Click the link below to view all the department.</p>                
                        <div class="card-footer d-flex align-items-center justify-content-between">
                        <a class="view_details" href="<?php echo e(url('/admin/view-department')); ?>">View Details</a>
                        <div class="small text-white"><i class="fa fa-caret-down"></i></div>
                    </div>
                </div>
            </div>
            <div class="two_column">
                <div class="card bg-danger text-white mb-4">
                    <div class="cards_logo"><img class="ollcf_logo_css" src="<?php echo e(asset('/img/education.png')); ?>" alt="Italian Trulli" style="width: 60px; height: 50px; margin-top: 12px"></div>
                        <p class="users_count"><b><?php echo e($course); ?>&nbsp;Course</b></p>
                        <p class="description">You have <?php echo e($course); ?> course in the database.<br>
                         Click the link below to view all the courses.</p>    
                        <div class="card-footer d-flex align-items-center justify-content-between">
                        <a class="view_details" href="<?php echo e(url('/admin/view-course')); ?>">View Details</a>
                        <div class="small text-white"><i class="fa fa-caret-down"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<style>
    .description{
        font-size: 10px;
        text-align: center;
    }
    .users_count{
    margin-left: auto;
    margin-right: auto;
    margin-bottom: 0px; 
    margin-top: 0px;
    }
    .image_design{
        width: 75px;
        height: 75px;
        padding:5px;
    }
    .cards_logo{
    width: 85px;
    height: 85px;
    border: solid;
    border-radius: 100px;
    border-color: black;
    margin-left: auto;
    margin-right: auto;
    margin-top: 15px;          
    background-color: rgba(226, 223, 223, 0.605);
    }
    .dashboard_view{
padding-top: 40px;
    }
    </style> 







 

<?php echo $__env->make('admin.user-activity', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Clearance-System\resources\views/admin/admindashboard.blade.php ENDPATH**/ ?>